package com.example.book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
