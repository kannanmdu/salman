import 'package:flutter/material.dart';

class MenuGrid {
  final String headText;
  final String text;
  final String icon;
  final Color color;
  final Color textColor;

  MenuGrid({
    required this.headText,
    required this.text,
    required this.icon,
    required this.color,
    required this.textColor,
  });
}

class SearchList {
  final String text;
  final SearchGrid searchGrid;

  SearchList({required this.text, required this.searchGrid});
}

class SearchGrid {
  final List<String> image;

  SearchGrid({required this.image});
}
