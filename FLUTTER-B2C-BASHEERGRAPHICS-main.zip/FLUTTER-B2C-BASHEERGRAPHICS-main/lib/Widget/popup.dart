import 'package:flutter/material.dart';

import '../Const/assets.dart';
import '../Const/color.dart';
import '../Const/fonts.dart';

class PopUp extends StatefulWidget {
  final String text;
  const PopUp({super.key, required this.text});

  @override
  State<PopUp> createState() => _PopUpState();
}

class _PopUpState extends State<PopUp> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      iconPadding: EdgeInsets.zero,
      backgroundColor: MyColors.bars,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      title: Text(
        widget.text,
        style: TextStyle(
          fontFamily: MyFont.myFont,
          fontWeight: FontWeight.bold,
          color: MyColors.white,
        ),
      ),
      icon: SizedBox(
        height: 150.0,
        child: Image.asset(
          Assets.successfully,
          scale: 3,
        ),
      ),
    );
  }
}
