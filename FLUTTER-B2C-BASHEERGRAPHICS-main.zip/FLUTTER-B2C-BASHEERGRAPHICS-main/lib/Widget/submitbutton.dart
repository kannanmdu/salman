import 'package:book/Const/color.dart';
import 'package:flutter/material.dart';

import '../Const/fonts.dart';
import '../Const/size.dart';

class SubmitButton extends StatelessWidget {
  final String title;
  final bool isLoading;
  final Color? color;
  final Color? textColor;
  final Function onTap;
  const SubmitButton(
      {Key? key,
      required this.isLoading,
      required this.onTap,
      required this.title,
      this.color,
      this.textColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: isLoading
          ? null
          : () {
              onTap();
            },
      style: ElevatedButton.styleFrom(
        disabledBackgroundColor: Colors.transparent,
        backgroundColor: color ?? MyColors.primaryCustom,
        minimumSize: Size(width(context), 50),
        shape: RoundedRectangleBorder(
          // side: const BorderSide(color: MyColors.primaryCustom, width: 6),
          borderRadius: BorderRadius.circular(10.0), // <-- Radius
        ),
      ),
      child: isLoading
          ? const CircularProgressIndicator()
          : Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                title,
                style: TextStyle(
                    fontFamily: MyFont.myFont,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: textColor ?? MyColors.white),
              ),
            ),
    );
  }
}
