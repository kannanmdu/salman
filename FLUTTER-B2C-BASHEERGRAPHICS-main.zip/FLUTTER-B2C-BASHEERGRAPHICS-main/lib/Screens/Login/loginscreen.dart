import 'package:book/Const/color.dart';
import 'package:book/Const/fonts.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Helper/inputformator.dart';
import '../../Widget/textformfield.dart';
import 'logincontroller.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late LoginController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(LoginController());
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.loginKey,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    Assets.logo,
                    scale: 5,
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.emailController,
                    inputFormatters: [],
                    hintText: "Email",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Mobile Number";
                      } else if (!validateEmail(value)) {
                        return "Invalid Email";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.emailPassController,
                    inputFormatters: [],
                    hintText: "Password must contains 6 letters",
                    obscureText: controller.isVisible.value ? false : true,
                    suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            controller.isVisible.value =
                                !controller.isVisible.value;
                          });
                        },
                        icon: Icon(
                          controller.isVisible.value
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: MyColors.primaryCustom,
                        )),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Mobile Number";
                      } else if (value.length < 6) {
                        return "Password must contains 6 letters";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  SubmitButton(
                      isLoading: false,
                      onTap: () {
                        if (controller.loginKey.currentState!.validate()) {
                          controller.onLoginTapped();
                        }
                      },
                      title: "Continue"),
                  const SizedBox(height: 20),
                  TextButton(
                      onPressed: () {
                        Get.offAllNamed(Routes.forgotPasswordScreen);
                      },
                      child: const Text("Forgot Password")),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     CustomPaint(
                  //       painter: MyPainter(),
                  //       size: const Size(140.0,
                  //           4.0), // Set the size of the CustomPaint widget
                  //     ),
                  //     Text(
                  //       "Or Login with",
                  //       style: TextStyle(
                  //           fontFamily: MyFont.myFont, color: MyColors.white),
                  //     ),
                  //     CustomPaint(
                  //       painter: MyPainter(),
                  //       size: const Size(140.0,
                  //           4.0), // Set the size of the CustomPaint widget
                  //     ),
                  //   ],
                  // ),
                  // const SizedBox(height: 20),
                  // SubmitButton(
                  //   isLoading: false,
                  //   onTap: () {
                  //     setState(() {
                  //       controller.isEmail.value = !controller.isEmail.value;
                  //     });
                  //   },
                  //   title: "Phone",
                  //   textColor: MyColors.primaryCustom,
                  //   color: MyColors.white,
                  // ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: MyColors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0))),
              onPressed: () {
                Get.offAllNamed(Routes.registrationScreen);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: RichText(
                    text: TextSpan(children: [
                  TextSpan(
                      text: "Don’t have an Account?",
                      style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: MyColors.grey)),
                  const WidgetSpan(child: SizedBox(width: 10)),
                  TextSpan(
                      text: "REGISTER",
                      style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: MyColors.primaryCustom)),
                ])),
              )),
        ),
      ),
    );
  }
}

// ///LOGIN THROUGH EMAIL
// class EmailLogin extends StatefulWidget {
//   const EmailLogin({super.key});
//
//   @override
//   State<EmailLogin> createState() => _EmailLoginState();
// }
//
// class _EmailLoginState extends State<EmailLogin> {
//   late LoginController controller;
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     controller = Get.find<LoginController>();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Form(
//       key: controller.emailLoginKey,
//       child: Scaffold(
//         body: SafeArea(
//           child: Center(
//             child: SingleChildScrollView(
//               padding: const EdgeInsets.all(18.0),
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Image.asset(
//                     Assets.logo,
//                     scale: 5,
//                   ),
//                   const SizedBox(height: 20),
//                   CustomTextFormField(
//                     controller: controller.emailController,
//                     inputFormatters: [],
//                     hintText: "Email",
//                     validator: (value) {
//                       if (value == null || value.isEmpty) {
//                         return "Please Enter Mobile Number";
//                       } else if (!validateEmail(value)) {
//                         return "Invalid Email";
//                       } else {
//                         return null;
//                       }
//                     },
//                   ),
//                   const SizedBox(height: 20),
//                   CustomTextFormField(
//                     controller: controller.emailPassController,
//                     inputFormatters: [],
//                     hintText: "Password must contains 6 letters",
//                     validator: (value) {
//                       if (value == null || value.isEmpty) {
//                         return "Please Enter Mobile Number";
//                       } else if (value.length < 6) {
//                         return "Password must contains 6 letters";
//                       } else {
//                         return null;
//                       }
//                     },
//                   ),
//                   const SizedBox(height: 20),
//                   SubmitButton(
//                       isLoading: false,
//                       onTap: () {
//                         if (controller.loginKey.currentState!.validate()) {}
//                       },
//                       title: "Continue"),
//                   const SizedBox(height: 20),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       CustomPaint(
//                         painter: MyPainter(),
//                         size: const Size(140.0,
//                             4.0), // Set the size of the CustomPaint widget
//                       ),
//                       Text(
//                         "Or Login with",
//                         style: TextStyle(
//                             fontFamily: MyFont.myFont, color: MyColors.white),
//                       ),
//                       CustomPaint(
//                         painter: MyPainter(),
//                         size: const Size(140.0,
//                             4.0), // Set the size of the CustomPaint widget
//                       ),
//                     ],
//                   ),
//                   const SizedBox(height: 20),
//                   SubmitButton(
//                     isLoading: false,
//                     onTap: () {
//                       Get.offAll(
//                         () => const LoginScreen(),
//                         transition: Transition.leftToRight,
//                       );
//                     },
//                     title: "Phone",
//                     textColor: MyColors.primaryCustom,
//                     color: MyColors.white,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         bottomNavigationBar: Padding(
//           padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
//           child: ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                   backgroundColor: MyColors.white,
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(10.0))),
//               onPressed: () {},
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(vertical: 15),
//                 child: RichText(
//                     text: TextSpan(children: [
//                   TextSpan(
//                       text: "Don’t have an Account?",
//                       style: TextStyle(
//                           fontFamily: MyFont.myFont,
//                           fontWeight: FontWeight.bold,
//                           fontSize: 15,
//                           color: MyColors.grey)),
//                   const WidgetSpan(child: SizedBox(width: 10)),
//                   TextSpan(
//                       text: "REGISTER",
//                       style: TextStyle(
//                           fontFamily: MyFont.myFont,
//                           fontWeight: FontWeight.bold,
//                           fontSize: 15,
//                           color: MyColors.primaryCustom)),
//                 ])),
//               )),
//         ),
//       ),
//     );
//   }
// }
