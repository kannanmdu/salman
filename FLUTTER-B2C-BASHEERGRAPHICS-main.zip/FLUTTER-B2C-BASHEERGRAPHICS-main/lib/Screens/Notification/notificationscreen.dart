import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:lorem_gen/lorem_gen.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: MyColors.bars,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Get.offAllNamed(Routes.bottomNavBar);
          },
          icon: Image.asset(
            Assets.arrow,
            scale: 4,
          ),
        ),
        title: Text(
          "Notification",
          style: TextStyle(
            fontFamily: MyFont.myFont,
            color: MyColors.white,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {},
              icon: const Icon(Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom, size: 30))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(10.0),
        child: notificationList(),
      ),
    );
  }

  ///Notification Card Color

  final List<Color> cardColors = [
    MyColors.lightPurple,
    MyColors.lightOrange,
    MyColors.lightGreen,
    MyColors.lightPink,
  ];

  final List<Color> textColors = [
    MyColors.darkPurple,
    MyColors.darkOrange,
    MyColors.darkGreen,
    MyColors.pink,
  ];

  ///Dummy Text
  final paragraph = Lorem.paragraph();

  notificationList() {
    return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 14,
        itemBuilder: (context, index) {
          int colorIndex = index % cardColors.length;
          int textColorsIndex = index % textColors.length;
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              color: cardColors[colorIndex],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      Assets.calendar,
                      scale: 3,
                      color: textColors[textColorsIndex],
                    ),
                    const SizedBox(width: 20),
                    Flexible(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Your Order is On the way",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: textColors[textColorsIndex],
                              fontFamily: MyFont.myFont,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            paragraph,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: MyFont.myFont,
                              fontSize: 16,
                              color: textColors[textColorsIndex],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                        onPressed: () {},
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                          color: textColors[textColorsIndex],
                        ))
                  ],
                ),
              ),
            ),
          );
        });
  }
}
