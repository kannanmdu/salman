import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Helper/NetworkManger.dart';
import '../../Helper/api.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/AddressModel.dart';
import '../../ModelClass/B2CCustomerLogin.dart';
import '../../ModelClass/ProductModelRef.dart';
import '../../ModelClass/SalesOrder.dart';
import '../../locator/cart_service.dart';
import '../../locator/locator.dart';

class AddToCartController extends GetxController with StateMixin {
  List<ProductModel> selectedItems = [];

  late SalesOrder salesOrder;

  RxBool isLoading = false.obs;

  final CartService cartService = getIt<CartService>();

  Rx<List<AddressModel>?> addressList = (null as List<AddressModel>?).obs;

  List<AddressModel> selectedAddress = [];

  B2cLoginModel? loginUser;

  salesOrderApi() async {
    isLoading.value = true;
    int index = 1;
    salesOrder.orderDetail?.forEach((element) {
      element.slNo = index;
      index += 1;
    });
    NetworkManager.post(URl: HttpUrl.placeOrder, params: salesOrder.toJson())
        .then((apiResponse) async {
      isLoading.value = false;
      if (apiResponse.apiResponseModel != null) {
        if (apiResponse.apiResponseModel!.status) {
          selectedItems.clear();
          cartService.cartItems.clear();
          await PreferenceHelper.removeCartData();
          showPopup();
          Timer(const Duration(seconds: 5), () async {
            cartService.clearCart();
            await PreferenceHelper.removeCartData()
                .then((value) => Get.offAllNamed(Routes.bottomNavBar));
          });
        } else {
          String? message = apiResponse.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      } else {
        PreferenceHelper.getShowSnackBar(
            context: Get.context!, msg: apiResponse.error);
      }
    });
  }

  void updateProductCount() {
    for (var product in selectedItems) {
      cartService.cartItems.firstWhereOrNull((element) {
        if (element.bookId == product.bookId) {
          product.qtyCount = element.qtyCount;
          return true;
        } else {
          return false;
        }
      });
    }
  }

  showPopup() {
    showDialog(
      context: Get.context!,
      builder: (BuildContext context) {
        return AlertDialog(
          iconPadding: EdgeInsets.zero,
          backgroundColor: MyColors.bars,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
          title: const Text(
            "Order Placed \nSuccessfully",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: MyColors.white,
            ),
          ),
          icon: SizedBox(
            height: 150.0,
            child: Image.asset(
              Assets.successfully,
              scale: 3,
            ),
          ),
        );
      },
    );
  }

  getAddress() async {
    isLoading.value = true;
    loginUser = await PreferenceHelper.getUserData();
    await NetworkManager.get(
      url: HttpUrl.addressGetAll,
      parameters: {
        "OrganizationId": HttpUrl.org,
        "CustomerId": loginUser?.b2CCustomerId
      },
    ).then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            addressList.value = (response.apiResponseModel!.data as List)
                .map((e) => AddressModel.fromJson(e))
                .toList();
            change(addressList.value);
          }
          change(null, status: RxStatus.success());
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel?.message,
          );
        }
      } else {
        addressList.value?.length = 0;
        change(null, status: RxStatus.success());
        print("addressList.value?.length");
        print(addressList.value?.length);
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      Get.showSnackbar(
        PreferenceHelper.getShowSnackBar(
          msg: error.toString(),
        ),
      );
    });
    print("addressList.value?.length");
    print(addressList.value?.length);
  }
}
