import 'package:book/Const/size.dart';
import 'package:book/Helper/preferencehelper.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:flutter/material.dart';
import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:flutter_paypal_checkout/flutter_paypal_checkout.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';
import '../../Helper/api.dart';
import '../../ModelClass/SalesOrder.dart';
import '../../Widget/line.dart';
import '../Category/individualcategory/individualcategorycontroller.dart';
import 'addtocartcontrolller.dart';

class AddToCartScreen extends StatefulWidget {
  const AddToCartScreen({super.key});

  @override
  State<AddToCartScreen> createState() => _AddToCartScreenState();
}

class _AddToCartScreenState extends State<AddToCartScreen> {
  late AddToCartController controller;

  int? _selectedItemIndex;

  double qtyTotal = 0;
  double price = 0;
  double shippingCharge = 0.00;
  double grandTotal = 0.00;
  double taxValue = 0;

  ///CURRENT DATE
  String currentDate = DateTime.now().toString();

  String? sendSalesAddress;
  int selectedAddressIndex = -1;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserData();
    controller = Get.put(AddToCartController());
    InCatController _cartController = Get.put(InCatController());
    controller.selectedItems = _cartController.cartAddedProduct.value;
    controller.cartService.cartChangeStream.listen((_) {});
    controller.getAddress();
  }

  getUserData() async {
    await PreferenceHelper.getUserData().then((value) {
      customerId = value?.b2CCustomerId;
      b2CCustomerName = value?.b2CCustomerName;
      branchCode = value?.branchCode;
      emailId = value?.emailId;
      emailId = value?.mobileNo;
      postalCode = value?.postalCode;
      address = value?.addressLine1.toString();
      countryId = value?.countryId;
      orgId = value?.orgId.toString();
    });
  }

  ///GET CUSTOMER DATA
  String? customerId;
  String? orgId;
  String? countryId;
  String? address;
  String? postalCode;
  String? emailId;
  String? mobileNo;
  String? b2CCustomerName;
  String? branchCode;

  @override
  Widget build(BuildContext context) {
    double grandTotal = 0;
    double price = 0;

    ///PRICE
    for (var element in controller.selectedItems) {
      price += (element.qtyCount * element.sellingPrice!);
      grandTotal = shippingCharge + price;

      ///SHIPPING CHARGERS
      if (price <= 49) {
        grandTotal = price + 5;
        shippingCharge = 5.00;
      } else if (price >= 50 && price <= 79) {
        grandTotal = price + 3;
        shippingCharge = 3.00;
      } else if (price >= 80) {
        grandTotal = price;
        shippingCharge = 0.00;
      }
    }
    return GetBuilder<AddToCartController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Cart",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Shipping details",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: MyColors.white,
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 250,
                child: Center(
                  child: getAddressListing(),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Order details",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: MyColors.white,
                ),
              ),
              const SizedBox(height: 20),
              orderDetailsListView(),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Price",
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                  Text(
                    '\$ ${price.toStringAsFixed(2) ?? ""}',
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              CustomPaint(
                painter: MyPainter(),
                size: Size(width(context),
                    4.0), // Set the size of the CustomPaint widget
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        "Shipping fee",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: MyColors.white,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Icon(
                        Icons.error_outline,
                        color: MyColors.grey,
                      )
                    ],
                  ),
                  Text(
                    '\$ ${shippingCharge.toStringAsFixed(2) ?? ""}',
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              CustomPaint(
                painter: MyPainter(),
                size: Size(width(context),
                    4.0), // Set the size of the CustomPaint widget
              ),
              const SizedBox(height: 10),

              ///PROMO CODE
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //   children: [
              //     Text(
              //       "Promotion",
              //       style: TextStyle(
              //         fontFamily: MyFont.myFont,
              //         fontWeight: FontWeight.bold,
              //         fontSize: 16,
              //         color: MyColors.white,
              //       ),
              //     ),
              //     const SizedBox(width: 10),
              //     Text(
              //       "- \$ 30.00",
              //       style: TextStyle(
              //         fontFamily: MyFont.myFont,
              //         fontWeight: FontWeight.bold,
              //         fontSize: 16,
              //         color: MyColors.green,
              //       ),
              //     ),
              //   ],
              // ),
              // const SizedBox(height: 10),
              // CustomPaint(
              //   painter: MyPainter(),
              //   size: Size(
              //       width(context), 4.0), // Set the size of the CustomPaint widget
              // ),
              // const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Total",
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '\$ ${grandTotal.toStringAsFixed(2)}',
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: SubmitButton(
              isLoading: false,
              onTap: () async {


                if (controller.selectedAddress.isNotEmpty) {
                  if (controller.selectedItems.first.qtyCount == 0) {
                    // showBarBottom();
                    controller.selectedItems.clear();
                    controller.cartService.cartItems.clear();
                    controller.updateProductCount();
                    Get.offAndToNamed(Routes.bottomNavBar);
                  } else {
                    controller.salesOrder = SalesOrder(
                      orgId: HttpUrl.org,
                      branchCode: branchCode,
                      orderNo: "",
                      mobileNo: mobileNo,
                      emailId: emailId,
                      orderDate: currentDate,
                      customerId: customerId,
                      customerName: b2CCustomerName,
                      customerAddress: sendSalesAddress,
                      postalCode: postalCode,
                      taxCode: 0,
                      taxType: "E",
                      taxPerc: taxValue,
                      currencyCode: "",
                      currencyRate: 1,
                      total: price,
                      billDiscount: 0,
                      billDiscountPerc: 0,
                      subTotal: price,
                      tax: taxValue,
                      netTotal: grandTotal,
                      paymentType: "",
                      paidAmount: grandTotal,
                      remarks: "",
                      isActive: true,
                      createdBy: b2CCustomerName,
                      createdOn: currentDate,
                      changedBy: "admin",
                      changedOn: currentDate,
                      status: 0,
                      customerShipToId: 0,
                      customerShipToAddress: "",
                      latitude: 0,
                      longitude: 0,
                      signatureimage: "",
                      cameraimage: "",
                      orderDateString: currentDate,
                      createdFrom: "B2C",
                      customerEmail: emailId,
                      deliveryAmount: shippingCharge,
                      orderDetail: controller.selectedItems
                          .map((e) => OrderDetail(
                                orgId: HttpUrl.org,
                                orderNo: "",
                                slNo: 0,
                                productCode: e.bookId,
                                productName: e.title,
                                qty: e.qtyCount.toInt(),
                                foc: 0,
                                price: e.sellingPrice,
                                total: e.qtyCount.toInt() * e.sellingPrice!,
                                itemDiscount: 0,
                                itemDiscountPerc: 0,
                                subTotal: e.qtyCount.toInt() * e.sellingPrice!,
                                tax: taxValue,
                                netTotal:
                                    (e.qtyCount.toInt() * e.sellingPrice!) +
                                        (taxValue.toInt()),
                                taxCode: 0,
                                taxType: "E",
                                createdBy: "Admin",
                                taxPerc: 0,
                                createdOn: currentDate,
                                changedBy: "Admin",
                                changedOn: currentDate,
                                weight: 0,
                                remarks: "",
                              ))
                          .toList(),
                    );

                    await payment(grandTotal,price);
                  }
                } else {
                  PreferenceHelper.getShowSnackBar(
                      msg: "Please Select Delivery Address");
                }
              },
              title: "Pay \$ ${grandTotal.toStringAsFixed(2)}"),
        ),
      );
    });
  }

  ///ORDER DETAIL LISTVIEW BUILDER
  orderDetailsListView() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: controller.selectedItems.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 8, 0, 8),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 140,
                        width: 100,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: (controller
                                      .selectedItems[index].bookImageFilePath !=
                                  null)
                              ? ("${controller.selectedItems[index].bookImageFilePath}"
                                      .isNotEmpty)
                                  ? Image.network(
                                      '${controller.selectedItems[index].bookImageFilePath}',
                                      fit: BoxFit.fill,
                                    )
                                  : Image.asset(
                                      Assets.noBook,
                                      fit: BoxFit.fill,
                                    )
                              : Image.asset(
                                  Assets.noBook,
                                  fit: BoxFit.fill,
                                ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Flexible(
                        child: SizedBox(
                          width: width(context) / 2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                controller.selectedItems[index].title ?? "",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                                style: TextStyle(
                                  fontFamily: MyFont.myFont,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: MyColors.white,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  SizedBox(
                                    width: 20,
                                    child: Text(
                                      '${controller.selectedItems[index].qtyCount.toInt()}',
                                      key: ValueKey<int>(
                                        controller.selectedItems[index].qtyCount
                                                .toInt() ??
                                            0,
                                      ),
                                      style: TextStyle(
                                        fontFamily: MyFont.myFont,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: MyColors.white,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                  Text(
                                    " X \$ ${controller.selectedItems[index].sellingPrice}",
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: MyColors.white,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              SizedBox(
                                height: 40,
                                child: Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        setState(() {
                                          controller.cartService.removeFromCart(
                                              product: controller
                                                  .selectedItems[index]);
                                          controller.updateProductCount();
                                        });

                                        await PreferenceHelper.saveCartData(
                                            controller.selectedItems);
                                        await checkEmptyCart(index: index);
                                      },
                                      child: Container(
                                        height: double.infinity,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: MyColors.primaryCustom),
                                            borderRadius:
                                                BorderRadius.circular(5.0)),
                                        padding: const EdgeInsets.all(5.0),
                                        child: const Icon(
                                          Icons.remove,
                                          color: MyColors.white,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Container(
                                      decoration: BoxDecoration(
                                          color: MyColors.white,
                                          borderRadius:
                                              BorderRadius.circular(5.0)),
                                      height: double.infinity,
                                      width: 40,
                                      padding: const EdgeInsets.all(5.0),
                                      child: AnimatedSwitcher(
                                        duration:
                                            const Duration(milliseconds: 300),
                                        transitionBuilder: (Widget child,
                                            Animation<double> animation) {
                                          return ScaleTransition(
                                              scale: animation, child: child);
                                        },
                                        child: SizedBox(
                                          width: 20,
                                          child: Text(
                                            '${controller.selectedItems[index].qtyCount.toInt()}',
                                            key: ValueKey<int>(
                                              controller.selectedItems[index]
                                                      .qtyCount
                                                      .toInt() ??
                                                  0,
                                            ),
                                            style: TextStyle(
                                              fontFamily: MyFont.myFont,
                                              color: MyColors.black,
                                              fontSize: 14,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    InkWell(
                                      onTap: () async {
                                        setState(() {
                                          controller.cartService.addToCart(
                                              product: controller
                                                  .selectedItems[index]);
                                          controller.updateProductCount();
                                        });

                                        await PreferenceHelper.saveCartData(
                                            controller.selectedItems);
                                      },
                                      child: Container(
                                        height: double.infinity,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: MyColors.primaryCustom),
                                            borderRadius:
                                                BorderRadius.circular(5.0)),
                                        padding: const EdgeInsets.all(5.0),
                                        child: const Icon(
                                          Icons.add,
                                          color: MyColors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton(
                        onPressed: () {},
                        icon: Image.asset(
                          Assets.clear,
                          scale: 4,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  CustomPaint(
                    painter: MyPainter(),
                    size: Size(width(context),
                        4.0), // Set the size of the CustomPaint widget
                  ),
                ],
              ),
            );
          }),
    );
  }

  ///ADDRESSLISTING
  getAddressListing() {
    return (controller.addressList.value != null &&
            controller.addressList.value!.isNotEmpty)
        ? ListView.builder(
            shrinkWrap: true,
            itemCount: controller.addressList.value?.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              final isSelected = index == selectedAddressIndex;
              final address = controller.addressList.value?[index];
              return InkWell(
                onTap: () {
                  setState(() {
                    if (isSelected) {
                      // If the address is already selected, deselect it
                      selectedAddressIndex = -1;
                      controller.selectedAddress.clear();
                    } else {
                      // If a different address is selected, update the selection
                      selectedAddressIndex = index;
                      controller.selectedAddress.clear();
                      controller.selectedAddress.add(address!);
                    }
                  });
                  sendSalesAddress =
                      "${controller.selectedAddress.first.addressLine1},${controller.selectedAddress.first.floorNo},${controller.selectedAddress.first.unitNo},${controller.selectedAddress.first.addressLine2},${controller.selectedAddress.first.postalCode}";
                  print(sendSalesAddress);
                  print("cartController.selectedAddress.length");
                  print(controller.selectedAddress.length);
                  print(controller.selectedAddress.first.addressLine1);
                },
                child: Card(
                  color: MyColors.bars,
                  shape: RoundedRectangleBorder(
                      side: BorderSide(
                          color: isSelected
                              ? MyColors.mainTheme
                              : Colors.transparent),
                      borderRadius: BorderRadius.circular(20.0)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image.asset(
                              Assets.location,
                              scale: 3,
                            ),
                            const SizedBox(width: 20),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Shipping address",
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: MyColors.primaryCustom,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "${address?.unitNo}, ${address?.floorNo}, ${address?.addressLine1}, \n${address?.addressLine2}, ${address?.addressLine3}, \n${address?.postalCode}",
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: MyColors.white,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "Name •  ${controller.addressList.value?[index].name} \n"
                                  "Ph No •  ${controller.addressList.value?[index].phone}, \n",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: MyColors.grey,
                                  ),
                                ),
                              ],
                            ),
                            // Theme(
                            //   data: ThemeData(
                            //     unselectedWidgetColor: MyColors
                            //         .white, // Change the color of unselected radio buttons
                            //   ),
                            //   child: Radio(
                            //     value: index,
                            //     groupValue: _selectedItemIndex,
                            //     onChanged: (value) {
                            //       setState(() {
                            //         if (_selectedItemIndex == value) {
                            //           _selectedItemIndex = null;
                            //           controller.addressList.value?[index]
                            //               .isSelected = false;
                            //         } else {
                            //           _selectedItemIndex = value;
                            //           controller.addressList.value?.forEach(
                            //               (element) =>
                            //                   element.isSelected = false);
                            //           controller.addressList.value?[index]
                            //               .isSelected = true;
                            //         }
                            //       });
                            //     },
                            //   ),
                            // ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            })
        : const Center(
            child: Text(
            "Add your Delivery Address",
            style: TextStyle(color: MyColors.white),
          ));
  }

  ///CHECKEMPTYCART
  Future<void> checkEmptyCart({required index}) async {
    if (controller.selectedItems[index].qtyCount == 0) {
      controller.selectedItems.removeAt(index);
    }
    await PreferenceHelper.saveCartData(controller.selectedItems);
    if (controller.selectedItems.isEmpty) {
      Get.back();
    }
  }

  // "name": "A demo product",
  // "quantity": 1,
  // "price": '10.12',
  // "currency": "USD"
  payment(double grandTotal1, double total1)  {
    // Navigator.of(context).push(
    //   MaterialPageRoute(
    //     builder: (BuildContext context) =>
    //         Scaffold(
    //       body: UsePaypal(
    //           sandboxMode: true,
    //           clientId: "ARczUVWk1e-x6ejyg0HiZpTzhHrUOkwEFl5bEN603Re_g29aKHtH9QTc7OICazEmdXh0nAg-RSiIuCED",
    //           secretKey: "ELef53CDK1Q25iPsRcH68eAh5dLc4XLXx1s1wwo4DKkRPlb-ja-yQGdOnP_XkPnH-Kx6Tf2NmmMddo0f",
    //           returnURL: "https://samplesite.com/return",
    //         cancelURL: "https://samplesite.com/cancel",
    //           transactions:  [
    //             {
    //               "amount":  const {
    //                 "total": "13",
    //                 "currency": "SGD",
    //                 "details": {
    //                   "subtotal": "12",
    //                   "shipping": '0',
    //                   "shipping_discount": 0
    //                 }
    //               },
    //               "description":
    //               "The payment transaction description.",
    //               // "payment_options": {
    //               //   "allowed_payment_method":
    //               //       "INSTANT_FUNDING_SOURCE"
    //               // },
    //               "item_list":  {
    //                 "items": Items,
    //                 // shipping address is not required though
    //                 // "shipping_address": {
    //                 //   "recipient_name": "Jane Foster",
    //                 //   "line1": "Travis County",
    //                 //   "line2": "",
    //                 //   "city": "Austin",
    //                 //   "country_code": "US",
    //                 //   "postal_code": "73301",
    //                 //   "phone": "+00000000",
    //                 //   "state": "Texas"
    //                 // },
    //               }
    //             }
    //           ],
    //           note: "Contact us for any questions on your order.",
    //           onSuccess: (Map params) async {
    //             print("onSuccess: $params");
    //            await controller.salesOrderApi();
    //           },
    //           onError: (error) {
    //             print("onError: $error");
    //           },
    //           onCancel: (params) {
    //             print('cancelled: $params');
    //           },
    //       ),
    //     ),
    //   )
    // );

    List<Map<String, dynamic>>  itemList = controller.selectedItems.map((item) {
      return {
        "name": item.title,
        "quantity": item.qtyCount,
        "price": "${item.sellingPrice!}", // Assuming sellingPrice is already in SGD
        "currency": "SGD"
      };
    }).toList();
    print("===========1234567890");
    print(itemList.first['name']);
    print(itemList.first['quantity']);
    print(itemList.first['price']);
    print(itemList.first['currency']);

    print("===========0987654321");
    print(itemList.last['name']);
    print(itemList.last['quantity']);
    print(itemList.last['price']);
    print(itemList.last['currency']);

    Navigator.of(context).push(MaterialPageRoute(
      builder: (BuildContext context) => PaypalCheckout(
        sandboxMode: true,
        clientId: "ARczUVWk1e-x6ejyg0HiZpTzhHrUOkwEFl5bEN603Re_g29aKHtH9QTc7OICazEmdXh0nAg-RSiIuCED",
        secretKey: "ELef53CDK1Q25iPsRcH68eAh5dLc4XLXx1s1wwo4DKkRPlb-ja-yQGdOnP_XkPnH-Kx6Tf2NmmMddo0f",
        returnURL: "success.snippetcoder.com",
        cancelURL: "cancel.snippetcoder.com",
        transactions:   [
          {
            "amount":  {
              "total": "$grandTotal1", // Total amount in SGD
              "currency": "SGD", // Currency changed to SGD
              "details": {
                "subtotal": "$grandTotal1", // Subtotal in SGD
                "shipping": '0',
                "shipping_discount": 0
              }
            },
            "description": "The payment transaction description.",
            "item_list": {
              // "items": [
              //   {
              //     "name": "The Passenger",
              //     "quantity": 1,
              //     "price": '150', // Price per item in SGD
              //     "currency": "SGD" // Currency changed to SGD
              //   },
              //   {
              //     "name": "American Lightning",
              //     "quantity": 2,
              //     "price": '400', // Price per item in SGD
              //     "currency": "SGD" // Currency changed to SGD
              //   }
              // ],
              "items": itemList,
            }
          }
        ],
        note: "Contact us for any questions on your order.",
        onSuccess: (Map params) async {
          print("onSuccess: $params");
        },
        onError: (error) {
          print("onError: $error");
          Navigator.pop(context);
        },
        onCancel: () {
          print('cancelled:');
        },
      ),
    ));

  }
}

///SHIPPING SERVICE DETAILS
// Row(
//   crossAxisAlignment: CrossAxisAlignment.start,
//   children: [
//     Image.asset(
//       Assets.appIcon,
//       scale: 3,
//     ),
//     const SizedBox(width: 20),
//     Flexible(
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             "Shipping service",
//             style: TextStyle(
//               fontFamily: MyFont.myFont,
//               fontWeight: FontWeight.bold,
//               fontSize: 16,
//               color: MyColors.white,
//             ),
//           ),
//           const SizedBox(height: 5),
//           Text(
//             "Hapag-lloyd",
//             maxLines: 2,
//             overflow: TextOverflow.ellipsis,
//             style: TextStyle(
//               fontFamily: MyFont.myFont,
//               fontWeight: FontWeight.bold,
//               fontSize: 16,
//               color: MyColors.white,
//             ),
//           ),
//           const SizedBox(height: 5),
//           Text(
//             "2h - 3h",
//             maxLines: 2,
//             overflow: TextOverflow.ellipsis,
//             style: TextStyle(
//               fontFamily: MyFont.myFont,
//               fontWeight: FontWeight.bold,
//               fontSize: 16,
//               color: MyColors.grey,
//             ),
//           ),
//         ],
//       ),
//     )
//   ],
// )
