import 'package:book/Const/color.dart';
import 'package:book/Const/fonts.dart';
import 'package:book/ModelClass/B2CCustomerLogin.dart';
import 'package:book/Screens/DashBoard/foryouscreen.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/size.dart';
import '../../Helper/extension.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/ProductModelRef.dart';
import '../Category/individualcategory/individualcategorycontroller.dart';
import 'dashboardcontroller.dart';

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  late DashBoardController controller;

  B2cLoginModel? b2cLoginModel = B2cLoginModel();
  late InCatController inCatController;
  List<String> savedProduct = [];

  initialiseData() async {
    b2cLoginModel = await PreferenceHelper.getUserData();
    b2cLoginModel?.b2CCustomerName;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialiseData();
    controller = Get.put(DashBoardController());
    inCatController = Get.put(InCatController());
    inCatController.updateProductCount();
    controller.bannerGet();
    controller.forYouGet();
    controller.bestSellerGet();
    inCatController.cartService.cartChangeStream.listen((_) {
      setState(() {});
    });
    initData();
    controller.latestBookGet();
    controller.comingSoonBookGet();
  }

  late final List<ProductModel> localData;

  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      inCatController.cartAddedProduct.clear();
      inCatController.cartAddedProduct.addAll(localData);
    }
    print("inCatController.cartAddedProduct.length");
    print(inCatController.cartAddedProduct.length);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DashBoardController>(builder: (logic) {
      if (logic.isLoadings.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }
      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          toolbarHeight: 80,
          backgroundColor: MyColors.bars,
          title: SizedBox(
            height: 40,
            child: Image.asset(
              Assets.appName,
              scale: 5,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Get.toNamed(Routes.notificationScreen);
                },
                icon: Image.asset(
                  Assets.notification,
                  scale: 3,
                )),
            buildAppBarCartButton(),
          ],
        ),
        body: SingleChildScrollView(
          // padding: const EdgeInsets.all(18.0),
          physics: const ScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
                child: Text(
                  "Best Deals",
                  style: TextStyle(
                    fontFamily: MyFont.myFont,
                    fontWeight: FontWeight.normal,
                    fontSize: 18,
                    color: MyColors.white,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              bannerImg(),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "For you",
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: MyColors.white,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Get.toNamed(Routes.forYouScreen);
                      },
                      child: Text(
                        "View All",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.normal,
                          fontSize: 18,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: SizedBox(
                  // color: MyColors.bars,
                  height: 260,
                  child: forYouList(),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          if (controller.isBestClick.value = true) {
                            controller.isLatestClick.value = false;
                            controller.isComingClick.value = false;
                          }
                        });
                      },
                      child: Text(
                        "Best sellers",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: (controller.isBestClick.value)
                              ? MyColors.mainTheme
                              : MyColors.white,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          if (controller.isLatestClick.value = true) {
                            controller.isBestClick.value = false;
                            controller.isComingClick.value = false;
                          }
                        });
                      },
                      child: Text(
                        "Latest",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: (controller.isLatestClick.value)
                              ? MyColors.mainTheme
                              : MyColors.white,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          if (controller.isComingClick.value = true) {
                            controller.isBestClick.value = false;
                            controller.isLatestClick.value = false;
                          }
                        });
                      },
                      child: Text(
                        "Coming soon",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: (controller.isComingClick.value)
                              ? MyColors.mainTheme
                              : MyColors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              (controller.isBestClick.value) ? bestSellerList() : SizedBox(),
              (controller.isLatestClick.value) ? latestList() : SizedBox(),
              (controller.isComingClick.value) ? comingSoonList() : SizedBox(),
            ],
          ),
        ),
      );
    });
  }

  ///BANNER WITH API
  bannerImg() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
      child: (controller.bannerGetImageList.isNotEmpty)
          ? SizedBox(
              height: height(context) / 5,
              width: double.infinity,
              child: CarouselSlider.builder(
                carouselController: controller.carouselController,
                itemCount: controller.bannerGetImageList.length,
                itemBuilder: (BuildContext context, int index, int realIndex) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20.0),
                      child: SizedBox(
                          width: width(context),
                          child:
                          // (controller.bannerImageList[index].bannerImageFilePath != null)
                          //     ? (controller.bannerImageList[index].bannerImageFilePath!.isNotEmpty)
                          //     ?
                          Image.network('${controller.bannerGetImageList[index].bannerImageFilePath}',
                              fit: BoxFit.fill)
                        // : Image.asset(Assets.noBook)
                              // : Image.asset(Assets.noBook)

                          // Image.asset(
                          //   controller
                          //       .bannerImageList[index].bannerImageFilePath
                          //       .toString(),
                          //   fit: BoxFit.fill,
                          // )
                  ),
                    ),
                  );
                },
                options: CarouselOptions(
                  scrollPhysics: const BouncingScrollPhysics(),
                  autoPlay: true,
                  aspectRatio: 0.6,
                  height: double.infinity,
                  viewportFraction: 1,
                  onPageChanged: (index, reason) {
                    setState(() {
                      controller.currentIndex = index;
                    });
                  },
                ),
              ),
            )
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: SizedBox(
                    width: width(context),
                    child: Image.asset(
                      Assets.banner,
                      fit: BoxFit.fill,
                    )),
              ),
            ),
    );
  }

  forYouList() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: controller.forYouProductList.length >= 5
              ? 5
              : controller.forYouProductList.length,
          physics: const ScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(8),
              child: Stack(
                fit: StackFit.passthrough,
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    height: 100,
                    width: 140,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: (controller.forYouProductList[index].bookImage !=
                                null)
                            ? (controller.forYouProductList[index].bookImage!
                                    .isNotEmpty)
                                ? Image.network(
                                    '${controller.forYouProductList[index].bookImage}',
                                    fit: BoxFit.fill)
                                : Image.asset(Assets.noBook)
                            : Image.asset(Assets.noBook)),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(3, 140, 3, 10),
                    child: (controller.forYouProductList[index].qtyCount == 0)
                        ? Padding(
                            padding: const EdgeInsets.only(left: 80),
                            child: GestureDetector(
                              onTap: () async {
                                ProductModel? selectedProduct =
                                    controller.forYouProductList[index];
                                if (savedProduct
                                    .contains(selectedProduct.bookId)) {
                                  var selectedIndex = inCatController
                                      .cartAddedProduct
                                      .indexWhere((element) =>
                                          element.bookId ==
                                          selectedProduct.bookId);

                                  inCatController.cartAddedProduct
                                      .removeAt(selectedIndex);
                                  savedProduct.remove(selectedProduct.bookId);
                                }
                                setState(() {
                                  inCatController.cartService
                                      .addToCart(product: selectedProduct);
                                  controller.updateProductCount();
                                });

                                if (selectedProduct.qtyCount != 0) {
                                  bool isAlreadyAdded = inCatController
                                      .cartAddedProduct
                                      .any((element) =>
                                          element.bookId ==
                                          selectedProduct.bookId);

                                  if (!isAlreadyAdded) {
                                    inCatController.cartAddedProduct
                                        .add(selectedProduct);
                                  }
                                }
                                await PreferenceHelper.saveCartData(
                                    inCatController.cartAddedProduct);
                              },
                              child: const Align(
                                alignment: Alignment.centerRight,
                                child: SizedBox(
                                  child: CircleAvatar(
                                    child: Icon(Icons.add),
                                  ),
                                ),
                              ),
                            ),
                          )
                        : Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: MyColors.white,
                                  borderRadius: BorderRadius.circular(40.0)),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 1, vertical: 5.5),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                            controller.forYouProductList[index];

                                        setState(() {
                                          inCatController.cartService
                                              .removeFromCart(
                                                  product: selectedProduct);
                                          inCatController.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount == 0) {
                                          if (inCatController.cartAddedProduct
                                              .any((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId)) {
                                            var selectedIndex = inCatController
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                                    element.bookId ==
                                                    selectedProduct.bookId);

                                            inCatController.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            if (inCatController
                                                .cartAddedProduct.isEmpty) {
                                              inCatController.cartAddedProduct
                                                  .clear();
                                            }
                                          }
                                        }
                                        // bottomAppBar(index);
                                        // if (controller.productList[index].qtycount == 0) {
                                        //   controller.cartAddedProduct.length = 0;
                                        // }
                                        await PreferenceHelper.saveCartData(
                                            inCatController.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.remove,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    ),
                                    // Obx(() {
                                    //   return
                                    AnimatedSwitcher(
                                      duration:
                                          const Duration(milliseconds: 300),
                                      transitionBuilder: (Widget child,
                                          Animation<double> animation) {
                                        return ScaleTransition(
                                            scale: animation, child: child);
                                      },
                                      child: SizedBox(
                                        width: 20,
                                        child: Text(
                                          '${controller.forYouProductList[index].qtyCount.toInt()}',
                                          key: ValueKey<int>(
                                            controller.forYouProductList[index]
                                                    .qtyCount
                                                    .toInt() ??
                                                0,
                                          ),
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            color: MyColors.black,
                                            fontSize: 16,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    // }),
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                            controller.forYouProductList[index];

                                        if (savedProduct
                                            .contains(selectedProduct.bookId)) {
                                          var selectedIndex = inCatController
                                              .cartAddedProduct
                                              .indexWhere((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId);

                                          inCatController.cartAddedProduct
                                              .removeAt(selectedIndex);
                                          savedProduct
                                              .remove(selectedProduct.bookId);
                                        }
                                        setState(() {
                                          inCatController.cartService.addToCart(
                                              product: selectedProduct);
                                          inCatController.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount != 0) {
                                          bool isAlreadyAdded = inCatController
                                              .cartAddedProduct
                                              .any((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId);

                                          if (!isAlreadyAdded) {
                                            inCatController.cartAddedProduct
                                                .add(selectedProduct);
                                          }
                                        }
                                        await PreferenceHelper.saveCartData(
                                            inCatController.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.add,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            );
          }),
    );
  }

  ///BEST SELLER BOOK LIST
  bestSellerList() {
    return Column(
      children: [
        ListView.builder(
            shrinkWrap: true,
            itemCount: controller.bestSellerBookList.length >= 5
                ? 5
                : controller.bestSellerBookList.length,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return SizedBox(
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Row(
                    children: [
                      SizedBox(
                          height: 150,
                          child: ClipRRect(
                              borderRadius: BorderRadius.circular(10.0),
                              child: (controller.bestSellerBookList[index]
                                          .bookImage !=
                                      null)
                                  ? (controller.bestSellerBookList[index]
                                          .bookImage!.isNotEmpty)
                                      ? Image.network(
                                          '${controller.bestSellerBookList[index].bookImage}',
                                          fit: BoxFit.fill)
                                      : Image.asset(Assets.noBook)
                                  : Image.asset(Assets.noBook))),
                      const SizedBox(width: 20),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              controller.bestSellerBookList[index].title ?? "",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.bestSellerBookList[index].authorName ??
                                  "",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.primaryCustom,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.bestSellerBookList[index].sellingPrice!
                                  .toStringAsFixed(2),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: MyColors.brown,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20.0))),
                                  onPressed: () {},
                                  child: Text(
                                    "View",
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.bold,
                                      color: MyColors.lightBrown,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                (controller.bestSellerBookList[index]
                                            .qtyCount ==
                                        0)
                                    ? ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: MyColors.brown,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        20.0))),
                                        onPressed: () async {
                                          ProductModel? selectedProduct =
                                              controller
                                                  .bestSellerBookList[index];
                                          if (savedProduct.contains(
                                              selectedProduct.bookId)) {
                                            var selectedIndex = inCatController
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                                    element.bookId ==
                                                    selectedProduct.bookId);

                                            inCatController.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            savedProduct
                                                .remove(selectedProduct.bookId);
                                          }
                                          setState(() {
                                            inCatController.cartService
                                                .addToCart(
                                                    product: selectedProduct);
                                            controller.updateProductCount();
                                          });

                                          if (selectedProduct.qtyCount != 0) {
                                            bool isAlreadyAdded =
                                                inCatController.cartAddedProduct
                                                    .any((element) =>
                                                        element.bookId ==
                                                        selectedProduct.bookId);

                                            if (!isAlreadyAdded) {
                                              inCatController.cartAddedProduct
                                                  .add(selectedProduct);
                                            }
                                          }
                                          await PreferenceHelper.saveCartData(
                                              inCatController.cartAddedProduct);
                                        },
                                        child: Text(
                                          "Add",
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            fontWeight: FontWeight.bold,
                                            color: MyColors.lightBrown,
                                          ),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 10, 0, 10),
                                        child: Container(
                                          // decoration: BoxDecoration(
                                          //     color: MyColors.white,
                                          //     borderRadius:
                                          //         BorderRadius.circular(40.0)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 1, vertical: 5.5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .bestSellerBookList[
                                                            index];

                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .removeFromCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount ==
                                                        0) {
                                                      if (inCatController
                                                          .cartAddedProduct
                                                          .any((element) =>
                                                              element.bookId ==
                                                              selectedProduct
                                                                  .bookId)) {
                                                        var selectedIndex = inCatController
                                                            .cartAddedProduct
                                                            .indexWhere((element) =>
                                                                element
                                                                    .bookId ==
                                                                selectedProduct
                                                                    .bookId);

                                                        inCatController
                                                            .cartAddedProduct
                                                            .removeAt(
                                                                selectedIndex);
                                                        if (inCatController
                                                            .cartAddedProduct
                                                            .isEmpty) {
                                                          inCatController
                                                              .cartAddedProduct
                                                              .clear();
                                                        }
                                                      }
                                                    }
                                                    // bottomAppBar(index);
                                                    // if (controller.productList[index].qtycount == 0) {
                                                    //   controller.cartAddedProduct.length = 0;
                                                    // }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.remove,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                // Obx(() {
                                                //   return
                                                AnimatedSwitcher(
                                                  duration: const Duration(
                                                      milliseconds: 300),
                                                  transitionBuilder:
                                                      (Widget child,
                                                          Animation<double>
                                                              animation) {
                                                    return ScaleTransition(
                                                        scale: animation,
                                                        child: child);
                                                  },
                                                  child: SizedBox(
                                                    width: 40,
                                                    child: Text(
                                                      '${controller.bestSellerBookList[index].qtyCount.toInt()}',
                                                      key: ValueKey<int>(
                                                        controller
                                                                .bestSellerBookList[
                                                                    index]
                                                                .qtyCount
                                                                .toInt() ??
                                                            0,
                                                      ),
                                                      style: TextStyle(
                                                        fontFamily:
                                                            MyFont.myFont,
                                                        color: MyColors.white,
                                                        fontSize: 16,
                                                      ),
                                                      textAlign:
                                                          TextAlign.center,
                                                    ),
                                                  ),
                                                ),
                                                // }),
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .bestSellerBookList[
                                                            index];

                                                    if (savedProduct.contains(
                                                        selectedProduct
                                                            .bookId)) {
                                                      var selectedIndex =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .indexWhere((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      inCatController
                                                          .cartAddedProduct
                                                          .removeAt(
                                                              selectedIndex);
                                                      savedProduct.remove(
                                                          selectedProduct
                                                              .bookId);
                                                    }
                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .addToCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount !=
                                                        0) {
                                                      bool isAlreadyAdded =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .any((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      if (!isAlreadyAdded) {
                                                        inCatController
                                                            .cartAddedProduct
                                                            .add(
                                                                selectedProduct);
                                                      }
                                                    }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.add,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
        Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: TextButton(
              onPressed: () {
                Get.toNamed(Routes.bestSellerBookScreen);
              },
              child: const Text(
                "View All",
                style: TextStyle(
                  fontSize: 15,
                ),
              )),
        ),
      ],
    );
  }

  ///LATEST BOOK LIST
  latestList() {
    return Column(
      children: [
        ListView.builder(
            shrinkWrap: true,
            itemCount: controller.latestBookList.length >= 5
                ? 5
                : controller.latestBookList.length,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return SizedBox(
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Row(
                    children: [
                      SizedBox(
                        height: 150,
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: (controller
                                        .latestBookList[index].bookImage !=
                                    null)
                                ? (controller.latestBookList[index].bookImage!
                                        .isNotEmpty)
                                    ? Image.network(
                                        '${controller.latestBookList[index].bookImage}',
                                        fit: BoxFit.fill)
                                    : Image.asset(Assets.noBook)
                                : Image.asset(Assets.noBook)),
                      ),
                      const SizedBox(width: 20),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              controller.latestBookList[index].title ?? "",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.latestBookList[index].authorName ?? "",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.primaryCustom,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.latestBookList[index].sellingPrice!
                                  .toStringAsFixed(2),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: MyColors.brown,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20.0))),
                                  onPressed: () {},
                                  child: Text(
                                    "View",
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.bold,
                                      color: MyColors.lightBrown,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                (controller.latestBookList[index].qtyCount == 0)
                                    ? ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: MyColors.brown,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        20.0))),
                                        onPressed: () async {
                                          ProductModel? selectedProduct =
                                              controller.latestBookList[index];
                                          if (savedProduct.contains(
                                              selectedProduct.bookId)) {
                                            var selectedIndex = inCatController
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                                    element.bookId ==
                                                    selectedProduct.bookId);

                                            inCatController.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            savedProduct
                                                .remove(selectedProduct.bookId);
                                          }
                                          setState(() {
                                            inCatController.cartService
                                                .addToCart(
                                                    product: selectedProduct);
                                            controller.updateProductCount();
                                          });

                                          if (selectedProduct.qtyCount != 0) {
                                            bool isAlreadyAdded =
                                                inCatController.cartAddedProduct
                                                    .any((element) =>
                                                        element.bookId ==
                                                        selectedProduct.bookId);

                                            if (!isAlreadyAdded) {
                                              inCatController.cartAddedProduct
                                                  .add(selectedProduct);
                                            }
                                          }
                                          await PreferenceHelper.saveCartData(
                                              inCatController.cartAddedProduct);
                                        },
                                        child: Text(
                                          "Add",
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            fontWeight: FontWeight.bold,
                                            color: MyColors.lightBrown,
                                          ),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 10, 0, 10),
                                        child: Container(
                                          // decoration: BoxDecoration(
                                          //     color: MyColors.white,
                                          //     borderRadius:
                                          //         BorderRadius.circular(40.0)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 1, vertical: 5.5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .latestBookList[
                                                            index];

                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .removeFromCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount ==
                                                        0) {
                                                      if (inCatController
                                                          .cartAddedProduct
                                                          .any((element) =>
                                                              element.bookId ==
                                                              selectedProduct
                                                                  .bookId)) {
                                                        var selectedIndex = inCatController
                                                            .cartAddedProduct
                                                            .indexWhere((element) =>
                                                                element
                                                                    .bookId ==
                                                                selectedProduct
                                                                    .bookId);

                                                        inCatController
                                                            .cartAddedProduct
                                                            .removeAt(
                                                                selectedIndex);
                                                        if (inCatController
                                                            .cartAddedProduct
                                                            .isEmpty) {
                                                          inCatController
                                                              .cartAddedProduct
                                                              .clear();
                                                        }
                                                      }
                                                    }
                                                    // bottomAppBar(index);
                                                    // if (controller.productList[index].qtycount == 0) {
                                                    //   controller.cartAddedProduct.length = 0;
                                                    // }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.remove,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                // Obx(() {
                                                //   return
                                                AnimatedSwitcher(
                                                  duration: const Duration(
                                                      milliseconds: 300),
                                                  transitionBuilder:
                                                      (Widget child,
                                                          Animation<double>
                                                              animation) {
                                                    return ScaleTransition(
                                                        scale: animation,
                                                        child: child);
                                                  },
                                                  child: SizedBox(
                                                    width: 40,
                                                    child: Text(
                                                      '${controller.latestBookList[index].qtyCount.toInt()}',
                                                      key: ValueKey<int>(
                                                        controller
                                                                .latestBookList[
                                                                    index]
                                                                .qtyCount
                                                                .toInt() ??
                                                            0,
                                                      ),
                                                      style: TextStyle(
                                                        fontFamily:
                                                            MyFont.myFont,
                                                        color: MyColors.white,
                                                        fontSize: 16,
                                                      ),
                                                      textAlign:
                                                          TextAlign.center,
                                                    ),
                                                  ),
                                                ),
                                                // }),
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .latestBookList[
                                                            index];

                                                    if (savedProduct.contains(
                                                        selectedProduct
                                                            .bookId)) {
                                                      var selectedIndex =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .indexWhere((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      inCatController
                                                          .cartAddedProduct
                                                          .removeAt(
                                                              selectedIndex);
                                                      savedProduct.remove(
                                                          selectedProduct
                                                              .bookId);
                                                    }
                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .addToCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount !=
                                                        0) {
                                                      bool isAlreadyAdded =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .any((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      if (!isAlreadyAdded) {
                                                        inCatController
                                                            .cartAddedProduct
                                                            .add(
                                                                selectedProduct);
                                                      }
                                                    }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.add,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
        Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: TextButton(
              onPressed: () {
                Get.toNamed(Routes.latestBookListScreen);
              },
              child: const Text(
                "View All",
                style: TextStyle(
                  fontSize: 15,
                ),
              )),
        ),
      ],
    );
  }

  ///COMING SOON BOOK LIST
  comingSoonList() {
    return Column(
      children: [
        ListView.builder(
            shrinkWrap: true,
            itemCount: controller.comingSoonBookList.length >= 5
                ? 5
                : controller.comingSoonBookList.length,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return SizedBox(
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Row(
                    children: [
                      SizedBox(
                        height: 150,
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: (controller
                                        .comingSoonBookList[index].bookImage !=
                                    null)
                                ? (controller.comingSoonBookList[index]
                                        .bookImage!.isNotEmpty)
                                    ? Image.network(
                                        '${controller.comingSoonBookList[index].bookImage}',
                                        fit: BoxFit.fill)
                                    : Image.asset(Assets.noBook)
                                : Image.asset(Assets.noBook)),
                      ),
                      const SizedBox(width: 20),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              controller.comingSoonBookList[index].title ?? "",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.comingSoonBookList[index].authorName ??
                                  "",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.primaryCustom,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              controller.comingSoonBookList[index].sellingPrice!
                                  .toStringAsFixed(2),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: MyColors.brown,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20.0))),
                                  onPressed: () {},
                                  child: Text(
                                    "View",
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.bold,
                                      color: MyColors.lightBrown,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                (controller.comingSoonBookList[index]
                                            .qtyCount ==
                                        0)
                                    ? ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: MyColors.brown,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        20.0))),
                                        onPressed: () async {
                                          ProductModel? selectedProduct =
                                              controller
                                                  .comingSoonBookList[index];
                                          if (savedProduct.contains(
                                              selectedProduct.bookId)) {
                                            var selectedIndex = inCatController
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                                    element.bookId ==
                                                    selectedProduct.bookId);

                                            inCatController.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            savedProduct
                                                .remove(selectedProduct.bookId);
                                          }
                                          setState(() {
                                            inCatController.cartService
                                                .addToCart(
                                                    product: selectedProduct);
                                            controller.updateProductCount();
                                          });

                                          if (selectedProduct.qtyCount != 0) {
                                            bool isAlreadyAdded =
                                                inCatController.cartAddedProduct
                                                    .any((element) =>
                                                        element.bookId ==
                                                        selectedProduct.bookId);

                                            if (!isAlreadyAdded) {
                                              inCatController.cartAddedProduct
                                                  .add(selectedProduct);
                                            }
                                          }
                                          await PreferenceHelper.saveCartData(
                                              inCatController.cartAddedProduct);
                                        },
                                        child: Text(
                                          "Add",
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            fontWeight: FontWeight.bold,
                                            color: MyColors.lightBrown,
                                          ),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 10, 0, 10),
                                        child: Container(
                                          // decoration: BoxDecoration(
                                          //     color: MyColors.white,
                                          //     borderRadius:
                                          //         BorderRadius.circular(40.0)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 1, vertical: 5.5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .comingSoonBookList[
                                                            index];

                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .removeFromCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount ==
                                                        0) {
                                                      if (inCatController
                                                          .cartAddedProduct
                                                          .any((element) =>
                                                              element.bookId ==
                                                              selectedProduct
                                                                  .bookId)) {
                                                        var selectedIndex = inCatController
                                                            .cartAddedProduct
                                                            .indexWhere((element) =>
                                                                element
                                                                    .bookId ==
                                                                selectedProduct
                                                                    .bookId);

                                                        inCatController
                                                            .cartAddedProduct
                                                            .removeAt(
                                                                selectedIndex);
                                                        if (inCatController
                                                            .cartAddedProduct
                                                            .isEmpty) {
                                                          inCatController
                                                              .cartAddedProduct
                                                              .clear();
                                                        }
                                                      }
                                                    }
                                                    // bottomAppBar(index);
                                                    // if (controller.productList[index].qtycount == 0) {
                                                    //   controller.cartAddedProduct.length = 0;
                                                    // }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.remove,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                // Obx(() {
                                                //   return
                                                AnimatedSwitcher(
                                                  duration: const Duration(
                                                      milliseconds: 300),
                                                  transitionBuilder:
                                                      (Widget child,
                                                          Animation<double>
                                                              animation) {
                                                    return ScaleTransition(
                                                        scale: animation,
                                                        child: child);
                                                  },
                                                  child: SizedBox(
                                                    width: 40,
                                                    child: Text(
                                                      '${controller.comingSoonBookList[index].qtyCount.toInt()}',
                                                      key: ValueKey<int>(
                                                        controller
                                                                .comingSoonBookList[
                                                                    index]
                                                                .qtyCount
                                                                .toInt() ??
                                                            0,
                                                      ),
                                                      style: TextStyle(
                                                        fontFamily:
                                                            MyFont.myFont,
                                                        color: MyColors.white,
                                                        fontSize: 16,
                                                      ),
                                                      textAlign:
                                                          TextAlign.center,
                                                    ),
                                                  ),
                                                ),
                                                // }),
                                                GestureDetector(
                                                  onTap: () async {
                                                    ProductModel?
                                                        selectedProduct =
                                                        controller
                                                                .comingSoonBookList[
                                                            index];

                                                    if (savedProduct.contains(
                                                        selectedProduct
                                                            .bookId)) {
                                                      var selectedIndex =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .indexWhere((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      inCatController
                                                          .cartAddedProduct
                                                          .removeAt(
                                                              selectedIndex);
                                                      savedProduct.remove(
                                                          selectedProduct
                                                              .bookId);
                                                    }
                                                    setState(() {
                                                      inCatController
                                                          .cartService
                                                          .addToCart(
                                                              product:
                                                                  selectedProduct);
                                                      inCatController
                                                          .updateProductCount();
                                                    });

                                                    if (selectedProduct
                                                            .qtyCount !=
                                                        0) {
                                                      bool isAlreadyAdded =
                                                          inCatController
                                                              .cartAddedProduct
                                                              .any((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                      if (!isAlreadyAdded) {
                                                        inCatController
                                                            .cartAddedProduct
                                                            .add(
                                                                selectedProduct);
                                                      }
                                                    }
                                                    await PreferenceHelper
                                                        .saveCartData(
                                                            inCatController
                                                                .cartAddedProduct);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5.0),
                                                        border: Border.all(
                                                            width: 2,
                                                            color: MyColors
                                                                .brown)),
                                                    child: const Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 5,
                                                              horizontal: 5),
                                                      child: Icon(
                                                        Icons.add,
                                                        color: MyColors.white,
                                                        size: 18,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
        Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: TextButton(
              onPressed: () {
                Get.toNamed(Routes.comingSoonBookList);
              },
              child: const Text(
                "View All",
                style: TextStyle(
                  fontSize: 15,
                ),
              )),
        ),
      ],
    );
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (inCatController.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                    arguments: inCatController.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (inCatController.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        inCatController.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
