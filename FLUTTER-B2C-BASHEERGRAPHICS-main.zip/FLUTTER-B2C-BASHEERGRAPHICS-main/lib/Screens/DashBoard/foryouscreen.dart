import 'package:book/Const/fonts.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Helper/extension.dart';
import 'foryoucontroller.dart';

class ForYouScreen extends StatefulWidget {
  const ForYouScreen({super.key});

  @override
  State<ForYouScreen> createState() => _ForYouScreenState();
}

class _ForYouScreenState extends State<ForYouScreen> {
  late ForYouController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.put(ForYouController());
    controller.forYouGet();
  }

  ///Increment - Decrement Function
  int counter = 1;

  void increment() {
    setState(() {
      counter++;
    });
  }

  void decrement() {
    setState(() {
      if (counter > 0) {
        counter--;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ForYouController>(builder: (logic) {
      if (logic.isLoadings.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "For you",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Image.asset(
                  Assets.notification,
                  scale: 3,
                )),
            IconButton(
                onPressed: () {},
                icon: const Icon(Icons.shopping_cart_rounded,
                    color: MyColors.primaryCustom, size: 30))
          ],
        ),
        body: SingleChildScrollView(
          physics: const ScrollPhysics(),
          padding: const EdgeInsets.all(18.0),
          child: Column(
            children: [
              forYouGridView(),
            ],
          ),
        ),
      );
    });
  }

  ///For You GridView Builder

  List book = [
    Assets.book1,
    Assets.book2,
    Assets.book3,
    Assets.book4,
    Assets.book5,
  ];

  forYouGridView() {
    return GridView.builder(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisExtent: 180,
        ),
        itemCount: controller.forYouProductList.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Get.toNamed(Routes.productDetailScreen);
            },
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Stack(
                fit: StackFit.passthrough,
                alignment: Alignment.center,
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(10.0),
                      child: (controller.forYouProductList[index].bookImage !=
                              null)
                          ? (controller.forYouProductList[index].bookImage!
                                  .isNotEmpty)
                              ? Image.network(
                                  '${controller.forYouProductList[index].bookImage}',
                                  fit: BoxFit.fill)
                              : Image.asset(Assets.noBook)
                          : Image.asset(Assets.noBook)),
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 110, left: 2, right: 2, bottom: 10),
                    child: Container(
                      height: 50,
                      width: 120,
                      padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
                      decoration: BoxDecoration(
                          color: controller.isForYouAddClick.value
                              ? Colors.transparent
                              : MyColors.white,
                          borderRadius: controller.isForYouAddClick.value
                              ? BorderRadius.zero
                              : BorderRadius.circular(60.0),
                          border: controller.isForYouAddClick.value
                              ? const Border.fromBorderSide(BorderSide.none)
                              : Border.all(
                                  color: MyColors.primaryCustom, width: 2)),
                      child: controller.isForYouAddClick.value
                          ? Align(
                              alignment: Alignment.centerRight,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    controller.isForYouAddClick.value =
                                        !controller.isForYouAddClick.value;
                                  });
                                },
                                child: const CircleAvatar(
                                  backgroundColor: MyColors.mainTheme,
                                  child: Icon(
                                    Icons.add,
                                    color: MyColors.white,
                                  ),
                                ),
                              ),
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (counter > 1) {
                                      setState(() {
                                        decrement();
                                      });
                                    } else {
                                      setState(() {
                                        controller.isForYouAddClick.value =
                                            !controller.isForYouAddClick.value;
                                      });
                                    }
                                  },
                                  child: CircleAvatar(
                                    backgroundColor: MyColors.mainTheme,
                                    child: (counter > 1)
                                        ? const Icon(
                                            Icons.remove,
                                            color: MyColors.white,
                                          )
                                        : const Icon(
                                            Icons.delete,
                                            size: 15,
                                            color: MyColors.white,
                                          ),
                                  ),
                                ),
                                FittedBox(
                                  child: SizedBox(
                                    width: 20,
                                    child: Center(
                                      child: Text(
                                        "$counter",
                                        style: TextStyle(
                                          fontFamily: MyFont.myFont,
                                          fontWeight: FontWeight.normal,
                                          color: MyColors.black,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      increment();
                                    });
                                  },
                                  child: const CircleAvatar(
                                    backgroundColor: MyColors.mainTheme,
                                    child: Icon(
                                      Icons.add,
                                      size: 20,
                                      color: MyColors.white,
                                    ),
                                  ),
                                )
                              ],
                            ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
