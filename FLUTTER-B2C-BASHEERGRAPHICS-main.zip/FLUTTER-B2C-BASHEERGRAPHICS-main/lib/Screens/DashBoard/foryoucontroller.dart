import 'package:get/get.dart';

import '../../Helper/NetworkManger.dart';
import '../../Helper/api.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/ProductModelRef.dart';

class ForYouController extends GetxController with StateMixin {
  RxBool isForYouAddClick = true.obs;

  RxBool isLoadings = false.obs;

  List<ProductModel> forYouProductList = [];

  ///FOR YOU LIST
  forYouGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "LB",
    }).then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            forYouProductList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }
}
