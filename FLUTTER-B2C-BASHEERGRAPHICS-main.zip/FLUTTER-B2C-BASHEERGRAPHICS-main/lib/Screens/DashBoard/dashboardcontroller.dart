import 'package:carousel_slider/carousel_controller.dart';
import 'package:get/get.dart';

import '../../Helper/NetworkManger.dart';
import '../../Helper/api.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/BannerModel.dart';
import '../../ModelClass/ProductModelRef.dart';
import '../../locator/cart_service.dart';
import '../../locator/locator.dart';

class DashBoardController extends GetxController with StateMixin {
  final CarouselController carouselController = CarouselController();

  int currentIndex = 0;

  RxBool isAddClick = true.obs;
  Rx<bool> isLoadings = false.obs;

  ///Dashboard Bottom List
  RxBool isBestClick = true.obs;
  RxBool isLatestClick = false.obs;
  RxBool isComingClick = false.obs;

  final CartService cartService = getIt<CartService>();

  RxList<ProductModel> cartAddedProduct = <ProductModel>[].obs;

  List<BannerModel> bannerImageList = [];

  List<BannerModel> bannerGetImageList = [];

  List<ProductModel> forYouProductList = [];

  List<ProductModel> bestSellerBookList = [];

  List<ProductModel> latestBookList = [];

  List<ProductModel> comingSoonBookList = [];

  bannerGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.bannerImageGet, parameters: {})
        .then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            bannerImageList = (response.apiResponseModel!.data as List)
                .map((e) => BannerModel.fromJson(e))
                .toList();
            bannerGetImageList = bannerImageList!.where((element) => (element.bannerImageFilePath!.isNotEmpty  && element.bannerImageFilePath != null))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  ///FOR YOU LIST
  forYouGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "LB",
    }).then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            forYouProductList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            updateProductCount();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  ///BEST SELLER
  bestSellerGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "BS",
    }).then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            bestSellerBookList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  ///LATEST BOOK LIST
  latestBookGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "LB",
    }).then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            latestBookList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  ///COMING SOON BOOK LIST

  comingSoonBookGet() {
    isLoadings.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "CS",
    }).then((response) {
      isLoadings.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            comingSoonBookList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  ///UPDATE PRODUCT
  Future<void> updateProductCount() async {
    for (var product in forYouProductList) {
      cartService.cartItems.firstWhereOrNull((element) {
        if (element.bookId == product.bookId) {
          product.qtyCount = element.qtyCount;
          return true;
        } else {
          return false;
        }
      });
    }
  }
}
