import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/ProductModelRef.dart';
import '../Category/individualcategory/individualcategorycontroller.dart';
import 'dashboardcontroller.dart';

class ComingSoonBookList extends StatefulWidget {
  const ComingSoonBookList({super.key});

  @override
  State<ComingSoonBookList> createState() => _ComingSoonBookListState();
}

class _ComingSoonBookListState extends State<ComingSoonBookList> {
  late DashBoardController controller;

  late InCatController inCatController;

  List<String> savedProduct = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(DashBoardController());
    inCatController = Get.put(InCatController());
    inCatController.updateProductCount();
    inCatController.cartService.cartChangeStream.listen((_) {
      setState(() {});
    });
    initData();
  }

  late final List<ProductModel> localData;

  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      inCatController.cartAddedProduct.clear();
      inCatController.cartAddedProduct.addAll(localData);
    }
    print("inCatController.cartAddedProduct.length");
    print(inCatController.cartAddedProduct.length);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: MyColors.bars,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Image.asset(
            Assets.arrow,
            scale: 4,
          ),
        ),
        title: Text(
          "Coming Soon Books",
          style: TextStyle(
            fontFamily: MyFont.myFont,
            color: MyColors.white,
          ),
        ),
        actions: [
          buildAppBarCartButton(),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            ListView.builder(
                shrinkWrap: true,
                itemCount: controller.comingSoonBookList.length,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return SizedBox(
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Row(
                        children: [
                          SizedBox(
                            height: 150,
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10.0),
                                child: (controller.comingSoonBookList[index]
                                            .bookImage !=
                                        null)
                                    ? (controller.comingSoonBookList[index]
                                            .bookImage!.isNotEmpty)
                                        ? Image.network(
                                            '${controller.comingSoonBookList[index].bookImage}',
                                            fit: BoxFit.fill)
                                        : Image.asset(Assets.noBook)
                                    : Image.asset(Assets.noBook)),
                          ),
                          const SizedBox(width: 20),
                          Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  controller.comingSoonBookList[index].title ??
                                      "",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 16,
                                    color: MyColors.white,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  controller.comingSoonBookList[index]
                                          .authorName ??
                                      "",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 16,
                                    color: MyColors.primaryCustom,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  controller
                                      .comingSoonBookList[index].sellingPrice!
                                      .toStringAsFixed(2),
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 16,
                                    color: MyColors.white,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  children: [
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          backgroundColor: MyColors.brown,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20.0))),
                                      onPressed: () {},
                                      child: Text(
                                        "View",
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontFamily: MyFont.myFont,
                                          fontWeight: FontWeight.bold,
                                          color: MyColors.lightBrown,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 20),
                                    (controller.comingSoonBookList[index]
                                                .qtyCount ==
                                            0)
                                        ? ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor: MyColors.brown,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.0))),
                                            onPressed: () async {
                                              ProductModel? selectedProduct =
                                                  controller.comingSoonBookList[
                                                      index];
                                              if (savedProduct.contains(
                                                  selectedProduct.bookId)) {
                                                var selectedIndex =
                                                    inCatController
                                                        .cartAddedProduct
                                                        .indexWhere((element) =>
                                                            element.bookId ==
                                                            selectedProduct
                                                                .bookId);

                                                inCatController.cartAddedProduct
                                                    .removeAt(selectedIndex);
                                                savedProduct.remove(
                                                    selectedProduct.bookId);
                                              }
                                              setState(() {
                                                inCatController.cartService
                                                    .addToCart(
                                                        product:
                                                            selectedProduct);
                                                controller.updateProductCount();
                                              });

                                              if (selectedProduct.qtyCount !=
                                                  0) {
                                                bool isAlreadyAdded =
                                                    inCatController
                                                        .cartAddedProduct
                                                        .any((element) =>
                                                            element.bookId ==
                                                            selectedProduct
                                                                .bookId);

                                                if (!isAlreadyAdded) {
                                                  inCatController
                                                      .cartAddedProduct
                                                      .add(selectedProduct);
                                                }
                                              }
                                              await PreferenceHelper
                                                  .saveCartData(inCatController
                                                      .cartAddedProduct);
                                            },
                                            child: Text(
                                              "Add",
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontFamily: MyFont.myFont,
                                                fontWeight: FontWeight.bold,
                                                color: MyColors.lightBrown,
                                              ),
                                            ),
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0, 10, 0, 10),
                                            child: Container(
                                              // decoration: BoxDecoration(
                                              //     color: MyColors.white,
                                              //     borderRadius:
                                              //         BorderRadius.circular(40.0)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 1,
                                                        vertical: 5.5),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceAround,
                                                  children: [
                                                    GestureDetector(
                                                      onTap: () async {
                                                        ProductModel?
                                                            selectedProduct =
                                                            controller
                                                                    .comingSoonBookList[
                                                                index];

                                                        setState(() {
                                                          inCatController
                                                              .cartService
                                                              .removeFromCart(
                                                                  product:
                                                                      selectedProduct);
                                                          inCatController
                                                              .updateProductCount();
                                                        });

                                                        if (selectedProduct
                                                                .qtyCount ==
                                                            0) {
                                                          if (inCatController
                                                              .cartAddedProduct
                                                              .any((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId)) {
                                                            var selectedIndex = inCatController
                                                                .cartAddedProduct
                                                                .indexWhere((element) =>
                                                                    element
                                                                        .bookId ==
                                                                    selectedProduct
                                                                        .bookId);

                                                            inCatController
                                                                .cartAddedProduct
                                                                .removeAt(
                                                                    selectedIndex);
                                                            if (inCatController
                                                                .cartAddedProduct
                                                                .isEmpty) {
                                                              inCatController
                                                                  .cartAddedProduct
                                                                  .clear();
                                                            }
                                                          }
                                                        }
                                                        // bottomAppBar(index);
                                                        // if (controller.productList[index].qtycount == 0) {
                                                        //   controller.cartAddedProduct.length = 0;
                                                        // }
                                                        await PreferenceHelper
                                                            .saveCartData(
                                                                inCatController
                                                                    .cartAddedProduct);
                                                      },
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5.0),
                                                            border: Border.all(
                                                                width: 2,
                                                                color: MyColors
                                                                    .brown)),
                                                        child: const Padding(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 5,
                                                                  horizontal:
                                                                      5),
                                                          child: Icon(
                                                            Icons.remove,
                                                            color:
                                                                MyColors.white,
                                                            size: 18,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    // Obx(() {
                                                    //   return
                                                    AnimatedSwitcher(
                                                      duration: const Duration(
                                                          milliseconds: 300),
                                                      transitionBuilder:
                                                          (Widget child,
                                                              Animation<double>
                                                                  animation) {
                                                        return ScaleTransition(
                                                            scale: animation,
                                                            child: child);
                                                      },
                                                      child: SizedBox(
                                                        width: 40,
                                                        child: Text(
                                                          '${controller.comingSoonBookList[index].qtyCount.toInt()}',
                                                          key: ValueKey<int>(
                                                            controller
                                                                    .comingSoonBookList[
                                                                        index]
                                                                    .qtyCount
                                                                    .toInt() ??
                                                                0,
                                                          ),
                                                          style: TextStyle(
                                                            fontFamily:
                                                                MyFont.myFont,
                                                            color:
                                                                MyColors.white,
                                                            fontSize: 16,
                                                          ),
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                      ),
                                                    ),
                                                    // }),
                                                    GestureDetector(
                                                      onTap: () async {
                                                        ProductModel?
                                                            selectedProduct =
                                                            controller
                                                                    .comingSoonBookList[
                                                                index];

                                                        if (savedProduct
                                                            .contains(
                                                                selectedProduct
                                                                    .bookId)) {
                                                          var selectedIndex = inCatController
                                                              .cartAddedProduct
                                                              .indexWhere((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                          inCatController
                                                              .cartAddedProduct
                                                              .removeAt(
                                                                  selectedIndex);
                                                          savedProduct.remove(
                                                              selectedProduct
                                                                  .bookId);
                                                        }
                                                        setState(() {
                                                          inCatController
                                                              .cartService
                                                              .addToCart(
                                                                  product:
                                                                      selectedProduct);
                                                          inCatController
                                                              .updateProductCount();
                                                        });

                                                        if (selectedProduct
                                                                .qtyCount !=
                                                            0) {
                                                          bool isAlreadyAdded = inCatController
                                                              .cartAddedProduct
                                                              .any((element) =>
                                                                  element
                                                                      .bookId ==
                                                                  selectedProduct
                                                                      .bookId);

                                                          if (!isAlreadyAdded) {
                                                            inCatController
                                                                .cartAddedProduct
                                                                .add(
                                                                    selectedProduct);
                                                          }
                                                        }
                                                        await PreferenceHelper
                                                            .saveCartData(
                                                                inCatController
                                                                    .cartAddedProduct);
                                                      },
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5.0),
                                                            border: Border.all(
                                                                width: 2,
                                                                color: MyColors
                                                                    .brown)),
                                                        child: const Padding(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 5,
                                                                  horizontal:
                                                                      5),
                                                          child: Icon(
                                                            Icons.add,
                                                            color:
                                                                MyColors.white,
                                                            size: 18,
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
          ],
        ),
      ),
    );
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (inCatController.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                    arguments: inCatController.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (inCatController.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        inCatController.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
