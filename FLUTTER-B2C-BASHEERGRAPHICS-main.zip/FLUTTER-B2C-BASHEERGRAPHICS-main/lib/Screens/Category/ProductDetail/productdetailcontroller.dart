import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../../../Const/color.dart';
import '../../../Helper/NetworkManger.dart';
import '../../../Helper/api.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/ProductModelRef.dart';
import '../../../ModelClass/WishListModel.dart';
import '../../../locator/cart_service.dart';
import '../../../locator/locator.dart';

class ProductDetailController extends GetxController with StateMixin {
  RxBool isLoading = true.obs;
  RxBool isProductLoading = true.obs;
  RxBool proDelClick = false.obs;

  String formattedDateTime = "";

  RxBool isFav = false.obs;

  ProductModel? productModel;

  RxList<ProductModel> productList = <ProductModel>[].obs;

  List<ProductModel> selectedItems = [];

  List<ProductModel> similarBookList = [];

  final CartService cartService = getIt<CartService>();

  RxList<ProductModel> cartAddedProduct = <ProductModel>[].obs;

  RxList<WishListModel> productWishList = <WishListModel>[].obs;


  Future<void> productWishListGetByCustomer(String? bookId) async {
    isLoading.value = true;
    change(null, status: RxStatus.loading());

    await NetworkManager.get(
      url: HttpUrl.productWishListGetByCustomer,
      parameters: {
        "OrganizationId": HttpUrl.org,
        "CustomerId": await PreferenceHelper.getUserData()
            .then((value) => value?.b2CCustomerId),
      },
    ).then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            List<WishListModel> list;
            list = resJson.map<WishListModel>((value) {
              return WishListModel.fromJson(value);
            }).toList();
            productWishList.value = list;
            isFav.value = productWishList.value.any((element) => element.productCode == bookId);
            print("isFav.value");
            print(isFav.value);
            change(null, status: RxStatus.success());
          } else {
            print("productList.length");
            print(productWishList.length);
            change(null, status: RxStatus.error());
          }
        } else {
          change(null, status: RxStatus.error());
          String? message = response.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      String? message = error.toString();
      Get.showSnackbar(PreferenceHelper.getShowSnackBar(
          context: Get.context!, msg: message));
    });
  }


  changeFavProduct(String? bookId) async {
    await NetworkManager.post(
        URl: HttpUrl.b2CCustomerFavCreateWishList,
        params: {
          "OrgId": HttpUrl.org,
          "CustomerId": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerId),
          "ProductCode": bookId,
          "ProductName": productList.first.title,
          "IsActive": true,
          "CreatedBy": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerName),
          "CreatedOn": formattedDateTime
        }).then((apiResponse) async {
      if (apiResponse.apiResponseModel != null &&
          apiResponse.apiResponseModel!.status) {
        if (apiResponse.apiResponseModel!.status) {
          change(null, status: RxStatus.success());
          productList.first.isFavourite = true;
          change(null, status: RxStatus.success());
          Fluttertoast.showToast(
            msg: 'Added to the Favourite',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.black,
            textColor: Colors.white,
            fontSize: 16.0,
          );
          change(null, status: RxStatus.success());
        } else {
          String? message = apiResponse.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(msg: message);
        }
      }
    });
  }

  unFavProduct(String? bookId) async {
    isProductLoading.value = true;
    NetworkManager.get(
        url: HttpUrl.b2CCustomerUnFavCreateWishList,
        parameters: {
          "OrganizationId": HttpUrl.org,
          "CustomerId": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerId),
          "ProductCode": bookId,
          "UserName": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerName),
        }).then((response) {
      isProductLoading.value = false;
      change(null, status: RxStatus.success());
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          change(null, status: RxStatus.success());
          productList.first.isFavourite = false;
          PreferenceHelper.getShowSnackBar(msg: "Removed From Saved List");
          change(null, status: RxStatus.success());
        }
      } else {
        change(null, status: RxStatus.error());
        String message = response.apiResponseModel?.message ?? "";
        PreferenceHelper.getShowSnackBar(msg: message);
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      String message = error.toString();
      PreferenceHelper.getShowSnackBar(msg: message);
    });
  }

  Future<void> productGetByCode({String? bookId}) async {
    isLoading.value = true;
    change(null, status: RxStatus.loading());

    await NetworkManager.get(
      url: HttpUrl.productGetByCode,
      parameters: {
        "OrganizationId": HttpUrl.org,
        "BookId": bookId,
      },
    ).then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            List<ProductModel> list;
            list = resJson.map<ProductModel>((value) {
              return ProductModel.fromJson(value);
            }).toList();
            productList.value = list;
            change(null, status: RxStatus.success());
          } else {
            print("productList.length");
            print(productList.length);
            change(null, status: RxStatus.error());
          }
        } else {
          change(null, status: RxStatus.error());
          String? message = response.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      String? message = error.toString();
      Get.showSnackbar(PreferenceHelper.getShowSnackBar(
          context: Get.context!, msg: message));
    });
  }

  ///SIMILAR BOOK LIST
  similarBookGet() {
    isLoading.value = true;
    NetworkManager.get(url: HttpUrl.forYouBookList, parameters: {
      "OrganizationId": 1,
      "TagCode": "SB",
    }).then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            similarBookList = (response.apiResponseModel!.data as List)
                .map((e) => ProductModel.fromJson(e))
                .toList();
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  Future<void> updateProductCount() async {
    for (var product in similarBookList) {
      cartService.cartItems.firstWhereOrNull((element) {
        if (element.bookId == product.bookId) {
          product.qtyCount = element.qtyCount;
          return true;
        } else {
          return false;
        }
      });
    }
  }

}
