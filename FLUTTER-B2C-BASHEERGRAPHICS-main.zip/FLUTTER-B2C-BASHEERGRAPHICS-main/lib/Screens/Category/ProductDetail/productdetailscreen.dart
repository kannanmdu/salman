import 'package:book/Const/size.dart';
import 'package:book/Screens/Category/ProductDetail/productdetailcontroller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/ProductModelRef.dart';
import '../individualcategory/individualcategorycontroller.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late ProductDetailController controller;
  late InCatController inCatController;

  ProductModel? productModel;
  List<String> savedProduct = [];
  String? bookId;

  late String deepLink;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(ProductDetailController());
    inCatController = Get.put(InCatController());
    productModel = Get.arguments as ProductModel;
    controller.productWishListGetByCustomer(productModel!.bookId);
    controller.productGetByCode(bookId: productModel?.bookId);
    inCatController.cartService.cartChangeStream.listen((_) {
      setState(() {});
    });
    initData();
    // initUniLinks();
  }

  late final List<ProductModel> localData;

  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      inCatController.cartAddedProduct.clear();
      inCatController.cartAddedProduct.addAll(localData);
    }
    controller.similarBookGet();
  }

  ///FOR LINK SHARING

  // Future<void> shareProduct() async {
  //   final String? productId =
  //       productModel!.bookId; // Replace with the ID of your product
  //   final deepLink =
  //       'myapp://productDetail?id=$productId'; // Custom scheme with product ID
  //   final String shareTitle =
  //       'Product Detail'; //// Title for the shared content
  //
  //   final url = Uri.parse(deepLink);
  //
  //   // Share the URL along with a title
  //   await Share.share(url as String);
  // }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Books",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
          actions: [
            // IconButton(
            //     onPressed: () {},
            //     icon: Image.asset(
            //       Assets.notification,
            //       scale: 3,
            //     )),
            // IconButton(
            //     onPressed: () {},
            //     icon: const Icon(Icons.shopping_cart_rounded,
            //         color: MyColors.primaryCustom, size: 30))
            buildAppBarCartButton(),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: SizedBox(
                  height: 200,
                  width: 150,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: (controller.productList.first.bookImage != null)
                        ? (controller.productList.first.bookImage!.isNotEmpty)
                            ? Image.network(
                                '${controller.productList.first.bookImage}',
                                fit: BoxFit.fill)
                            : Image.asset(Assets.noBook)
                        : Image.asset(Assets.noBook),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Flexible(
                    child: SizedBox(
                      width: width(context) / 1.5,
                      child: Text(
                        controller.productList.first.title ?? "",
                        textAlign: TextAlign.start,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: MyColors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),

                  ///SHARE BUTTON
                  // IconButton(
                  //     onPressed: () {
                  //       shareProduct();
                  //     },
                  //     icon: Image.asset(
                  //       Assets.share,
                  //       scale: 4,
                  //     )),
                  Obx(() {
                    return IconButton(
                        onPressed: () {
                          setState(() {
                            if (controller.isFav.value == false) {
                              controller.changeFavProduct(productModel?.bookId);
                              controller.isFav.value = true;
                            } else {
                              controller.unFavProduct(productModel?.bookId);
                              controller.isFav.value = false;
                            }
                          });
                        },
                        icon: (controller.isFav.value)
                            ? Image.asset(
                                Assets.save,
                                scale: 4,
                              )
                            : const Icon(
                                Icons.bookmark_border,
                                color: MyColors.primaryCustom,
                              ));
                  }),
                ],
              ),
              (controller.productList.first != null)
                  ? const SizedBox(height: 10)
                  : const SizedBox(),
              Text(
                controller.productList.first.authorName ?? "",
                textAlign: TextAlign.start,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: MyColors.primaryCustom,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Card(
                        color: MyColors.brown,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Text(
                            "Quantity",
                            style: TextStyle(
                              fontFamily: MyFont.myFont,
                              fontWeight: FontWeight.bold,
                              color: MyColors.lightBrown,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Card(
                        color: MyColors.brown,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Text(
                            "12",
                            style: TextStyle(
                              fontFamily: MyFont.myFont,
                              fontWeight: FontWeight.bold,
                              color: MyColors.lightBrown,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 40,
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () async {
                            // ProductModel? selectedProduct =
                            //     controller.productList.first;
                            //
                            // setState(() {
                            //   inCatController.cartService
                            //       .removeFromCart(product: selectedProduct);
                            //   inCatController.updateProductCount();
                            // });
                            //
                            // if (selectedProduct.qtyCount == 0) {
                            //   if (inCatController.cartAddedProduct.any(
                            //       (element) =>
                            //           element.bookId ==
                            //           selectedProduct.bookId)) {
                            //     var selectedIndex = inCatController
                            //         .cartAddedProduct
                            //         .indexWhere((element) =>
                            //             element.bookId ==
                            //             selectedProduct.bookId);
                            //
                            //     inCatController.cartAddedProduct
                            //         .removeAt(selectedIndex);
                            //     if (inCatController.cartAddedProduct.isEmpty) {
                            //       inCatController.cartAddedProduct.clear();
                            //     }
                            //   }
                            // }
                            //
                            // await PreferenceHelper.saveCartData(
                            //     inCatController.cartAddedProduct);

                            bool isAlreadyAdded = inCatController
                                .cartAddedProduct
                                .any((element) =>
                                    element.bookId == productModel?.bookId);

                            if (productModel?.qtyCount != 0) {
                              if (!isAlreadyAdded) {
                                inCatController.cartAddedProduct
                                    .add(productModel!);
                              }
                            }
                            setState(() {
                              inCatController.cartService
                                  .removeFromCart(product: productModel!);
                              inCatController.updateProductCount();
                            });
                            if (inCatController
                                    .cartAddedProduct[
                                        inCatController.selectedIndex.value]
                                    .qtyCount ==
                                0) {
                              if (inCatController.cartAddedProduct.any(
                                  (element) =>
                                      element.bookId == productModel?.bookId)) {
                                var selectedIndex = inCatController
                                    .cartAddedProduct
                                    .indexWhere((element) =>
                                        element.bookId == productModel?.bookId);

                                inCatController.cartAddedProduct
                                    .removeAt(selectedIndex);
                              }
                            }
                            await PreferenceHelper.saveCartData(
                                inCatController.cartAddedProduct);
                          },
                          child: Container(
                            height: double.infinity,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: MyColors.primaryCustom),
                                borderRadius: BorderRadius.circular(5.0)),
                            padding: const EdgeInsets.all(5.0),
                            child: const Icon(
                              Icons.remove,
                              color: MyColors.white,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          decoration: BoxDecoration(
                              color: MyColors.white,
                              borderRadius: BorderRadius.circular(5.0)),
                          height: double.infinity,
                          width: 40,
                          padding: const EdgeInsets.all(5.0),
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            transitionBuilder:
                                (Widget child, Animation<double> animation) {
                              return ScaleTransition(
                                  scale: animation, child: child);
                            },
                            child: SizedBox(
                              width: 20,
                              child: Text(
                                '${productModel!.qtyCount.toInt()}',
                                key: ValueKey<int>(
                                  productModel?.qtyCount.toInt() ?? 0,
                                ),
                                style: TextStyle(
                                  fontFamily: MyFont.myFont,
                                  color: MyColors.black,
                                  fontSize: 14,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        InkWell(
                          onTap: () async {
                            // ProductModel? selectedProduct =
                            //     controller.productList.first;
                            // if (savedProduct.contains(selectedProduct.bookId)) {
                            //   var selectedIndex = inCatController
                            //       .cartAddedProduct
                            //       .indexWhere((element) =>
                            //           element.bookId == selectedProduct.bookId);
                            //
                            //   inCatController.cartAddedProduct
                            //       .removeAt(selectedIndex);
                            //   savedProduct.remove(selectedProduct.bookId);
                            // }
                            // setState(() {
                            //   inCatController.cartService
                            //       .addToCart(product: selectedProduct);
                            //   inCatController.updateProductCount();
                            // });
                            //
                            // if (selectedProduct.qtyCount != 0) {
                            //   bool isAlreadyAdded = inCatController
                            //       .cartAddedProduct
                            //       .any((element) =>
                            //           element.bookId == selectedProduct.bookId);
                            //
                            //   if (!isAlreadyAdded) {
                            //     inCatController.cartAddedProduct
                            //         .add(selectedProduct);
                            //   }
                            // }
                            // await PreferenceHelper.saveCartData(
                            //     inCatController.cartAddedProduct);

                            bool isAlreadyAdded = inCatController
                                .cartAddedProduct
                                .any((element) =>
                                    element.bookId == productModel?.bookId);

                            if (productModel?.qtyCount != 0) {
                              if (!isAlreadyAdded) {
                                inCatController.cartAddedProduct
                                    .add(productModel!);
                              }
                            }
                            setState(() {
                              inCatController.cartService
                                  .addToCart(product: productModel!);
                              inCatController.updateProductCount();
                            });
                            if (inCatController
                                    .cartAddedProduct[
                                        inCatController.selectedIndex.value]
                                    .qtyCount ==
                                0) {
                              if (inCatController.cartAddedProduct.any(
                                  (element) =>
                                      element.bookId == productModel?.bookId)) {
                                var selectedIndex = inCatController
                                    .cartAddedProduct
                                    .indexWhere((element) =>
                                        element.bookId == productModel?.bookId);

                                inCatController.cartAddedProduct
                                    .removeAt(selectedIndex);
                              }
                            }
                            await PreferenceHelper.saveCartData(
                                inCatController.cartAddedProduct);
                          },
                          child: Container(
                            height: double.infinity,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: MyColors.primaryCustom),
                                borderRadius: BorderRadius.circular(5.0)),
                            padding: const EdgeInsets.all(5.0),
                            child: const Icon(
                              Icons.add,
                              color: MyColors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                controller.productList.first.detailDescription ?? "",
                style: TextStyle(
                    fontFamily: MyFont.myFont,
                    fontWeight: FontWeight.normal,
                    fontSize: 16,
                    color: MyColors.white),
              ),
              const SizedBox(height: 20),

              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //   children: [
              //     SizedBox(
              //         width: width(context) / 2.5,
              //         child: ElevatedButton(
              //             style: ElevatedButton.styleFrom(
              //                 backgroundColor: MyColors.scaffold,
              //                 shape: RoundedRectangleBorder(
              //                     side: const BorderSide(
              //                         color: MyColors.mainTheme),
              //                     borderRadius: BorderRadius.circular(10.0))),
              //             onPressed: () {
              //               Get.toNamed(Routes.addToCartScreen);
              //             },
              //             child: Padding(
              //               padding: const EdgeInsets.symmetric(vertical: 15),
              //               child: Text(
              //                 "ADD TO CART",
              //                 maxLines: 1,
              //                 overflow: TextOverflow.ellipsis,
              //                 style: TextStyle(
              //                   fontFamily: MyFont.myFont,
              //                   fontWeight: FontWeight.bold,
              //                   letterSpacing: 3.0,
              //                 ),
              //               ),
              //             ))),
              //     SizedBox(
              //         width: width(context) / 2.5,
              //         child: ElevatedButton(
              //             style: ElevatedButton.styleFrom(
              //                 shape: RoundedRectangleBorder(
              //                     borderRadius: BorderRadius.circular(10.0))),
              //             onPressed: () {},
              //             child: Padding(
              //               padding: const EdgeInsets.symmetric(vertical: 15),
              //               child: Text(
              //                 "BUY  \$30.000000000",
              //                 maxLines: 1,
              //                 overflow: TextOverflow.ellipsis,
              //                 style: TextStyle(
              //                   fontFamily: MyFont.myFont,
              //                   fontWeight: FontWeight.bold,
              //                   letterSpacing: 3.0,
              //                 ),
              //               ),
              //             ))),
              //   ],
              // ),
              // const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Similar Books",
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: MyColors.white,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Get.toNamed(Routes.forYouScreen);
                    },
                    child: Text(
                      "View All",
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.normal,
                        fontSize: 18,
                        color: MyColors.primaryCustom,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                // color: MyColors.bars,
                height: height(context) / 3.2,
                child: similarList(),
              ),
            ],
          ),
        ),
      );
    });
  }

  ///SIMILAR BOOK LIST

  similarList() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 30, 0, 30),
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: controller.similarBookList.length,
          physics: const ScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(8),
              child: Stack(
                fit: StackFit.passthrough,
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    height: 100,
                    width: 140,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Image.asset(
                          Assets.noBook,
                          fit: BoxFit.fill,
                        )),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(3, 140, 3, 10),
                    child: (controller.similarBookList[index].qtyCount == 0)
                        ? Padding(
                            padding: const EdgeInsets.only(left: 80),
                            child: GestureDetector(
                              onTap: () async {
                                ProductModel? selectedProduct =
                                    controller.similarBookList[index];
                                if (savedProduct
                                    .contains(selectedProduct.bookId)) {
                                  var selectedIndex = inCatController
                                      .cartAddedProduct
                                      .indexWhere((element) =>
                                          element.bookId ==
                                          selectedProduct.bookId);

                                  inCatController.cartAddedProduct
                                      .removeAt(selectedIndex);
                                  savedProduct.remove(selectedProduct.bookId);
                                }
                                setState(() {
                                  inCatController.cartService
                                      .addToCart(product: selectedProduct);
                                  controller.updateProductCount();
                                });

                                if (selectedProduct.qtyCount != 0) {
                                  bool isAlreadyAdded = inCatController
                                      .cartAddedProduct
                                      .any((element) =>
                                          element.bookId ==
                                          selectedProduct.bookId);

                                  if (!isAlreadyAdded) {
                                    inCatController.cartAddedProduct
                                        .add(selectedProduct);
                                  }
                                }
                                await PreferenceHelper.saveCartData(
                                    inCatController.cartAddedProduct);
                              },
                              child: const Align(
                                alignment: Alignment.centerRight,
                                child: SizedBox(
                                  child: CircleAvatar(
                                    child: Icon(Icons.add),
                                  ),
                                ),
                              ),
                            ),
                          )
                        : Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: MyColors.white,
                                  borderRadius: BorderRadius.circular(40.0)),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 1, vertical: 5.5),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                            controller.similarBookList[index];

                                        setState(() {
                                          inCatController.cartService
                                              .removeFromCart(
                                                  product: selectedProduct);
                                          inCatController.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount == 0) {
                                          if (inCatController.cartAddedProduct
                                              .any((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId)) {
                                            var selectedIndex = inCatController
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                                    element.bookId ==
                                                    selectedProduct.bookId);

                                            inCatController.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            if (inCatController
                                                .cartAddedProduct.isEmpty) {
                                              inCatController.cartAddedProduct
                                                  .clear();
                                            }
                                          }
                                        }
                                        // bottomAppBar(index);
                                        // if (controller.productList[index].qtycount == 0) {
                                        //   controller.cartAddedProduct.length = 0;
                                        // }
                                        await PreferenceHelper.saveCartData(
                                            inCatController.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.remove,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    ),
                                    // Obx(() {
                                    //   return
                                    AnimatedSwitcher(
                                      duration:
                                          const Duration(milliseconds: 300),
                                      transitionBuilder: (Widget child,
                                          Animation<double> animation) {
                                        return ScaleTransition(
                                            scale: animation, child: child);
                                      },
                                      child: SizedBox(
                                        width: 20,
                                        child: Text(
                                          '${controller.similarBookList[index].qtyCount.toInt()}',
                                          key: ValueKey<int>(
                                            controller.similarBookList[index]
                                                    .qtyCount
                                                    .toInt() ??
                                                0,
                                          ),
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            color: MyColors.black,
                                            fontSize: 16,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    // }),
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                            controller.similarBookList[index];

                                        if (savedProduct
                                            .contains(selectedProduct.bookId)) {
                                          var selectedIndex = inCatController
                                              .cartAddedProduct
                                              .indexWhere((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId);

                                          inCatController.cartAddedProduct
                                              .removeAt(selectedIndex);
                                          savedProduct
                                              .remove(selectedProduct.bookId);
                                        }
                                        setState(() {
                                          inCatController.cartService.addToCart(
                                              product: selectedProduct);
                                          inCatController.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount != 0) {
                                          bool isAlreadyAdded = inCatController
                                              .cartAddedProduct
                                              .any((element) =>
                                                  element.bookId ==
                                                  selectedProduct.bookId);

                                          if (!isAlreadyAdded) {
                                            inCatController.cartAddedProduct
                                                .add(selectedProduct);
                                          }
                                        }
                                        await PreferenceHelper.saveCartData(
                                            inCatController.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.add,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            );
          }),
    );
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (inCatController.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                    arguments: inCatController.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (inCatController.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        inCatController.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
