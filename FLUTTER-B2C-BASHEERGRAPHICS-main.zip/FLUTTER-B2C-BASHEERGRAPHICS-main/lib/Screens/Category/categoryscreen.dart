import 'dart:ffi';

import 'package:book/Const/size.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/ProductModelRef.dart';
import 'categorycontroller.dart';
import 'individualcategory/individualcategorycontroller.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  late CategoryController controller;
  late InCatController inCatController;
  List<String> savedProduct = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(CategoryController());
    inCatController = Get.put(InCatController());
    controller.getAllCategoryList();
    inCatController.cartService.cartChangeStream.listen((_) {
      setState(() {});
    });
    initData();
  }

  late final List<ProductModel> localData;

  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      inCatController.cartAddedProduct.clear();
      inCatController.cartAddedProduct.addAll(localData);
    }
    print("inCatController.cartAddedProduct.length");
    print(inCatController.cartAddedProduct.length);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CategoryController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }
      return Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: MyColors.bars,
            automaticallyImplyLeading: false,
            leading: IconButton(
              onPressed: () {
                Get.offAllNamed(Routes.bottomNavBar);
              },
              icon: Image.asset(
                Assets.arrow,
                scale: 4,
              ),
            ),
            title: Text(
              "Categories",
              style: TextStyle(
                fontFamily: MyFont.myFont,
                color: MyColors.white,
              ),
            ),
            actions: [
              IconButton(
                  onPressed: () {},
                  icon: Image.asset(
                    Assets.notification,
                    scale: 3,
                  )),
              buildAppBarCartButton()
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(18.0),
            physics: const ScrollPhysics(),
            child: Column(
              children: [
                // GestureDetector(
                //   onTap: () {
                //     Get.toNamed(Routes.individualCategoryScreen);
                //   },
                //   child: Stack(
                //     children: [
                //       SizedBox(
                //           height: 150,
                //           width: width(context),
                //           child: ClipRRect(
                //             borderRadius: BorderRadius.circular(20.0),
                //             child: Image.asset(
                //               Assets.cat1,
                //               fit: BoxFit.fill,
                //             ),
                //           )),
                //       Container(
                //         height: 150,
                //         width: width(context),
                //         decoration: BoxDecoration(
                //             borderRadius: BorderRadius.circular(20.0),
                //             gradient: const LinearGradient(
                //                 begin: Alignment.topCenter,
                //                 end: Alignment.bottomCenter,
                //                 colors: [
                //                   MyColors.blackOpacity,
                //                   MyColors.blackOpacity2,
                //                   MyColors.blackOpacity3,
                //                 ])),
                //         child: Center(
                //           child: Text(
                //             "PANTONE",
                //             style: TextStyle(
                //               fontFamily: MyFont.myFont,
                //               fontWeight: FontWeight.bold,
                //               fontSize: 18,
                //               color: MyColors.white,
                //             ),
                //           ),
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
                // const SizedBox(height: 20),
                // GestureDetector(
                //   onTap: () {
                //     Get.toNamed(Routes.individualCategoryScreen);
                //   },
                //   child: Stack(
                //     children: [
                //       SizedBox(
                //           height: 150,
                //           width: width(context),
                //           child: ClipRRect(
                //             borderRadius: BorderRadius.circular(20.0),
                //             child: Image.asset(
                //               Assets.cat1,
                //               fit: BoxFit.fill,
                //             ),
                //           )),
                //       Container(
                //         height: 150,
                //         width: width(context),
                //         decoration: BoxDecoration(
                //             borderRadius: BorderRadius.circular(20.0),
                //             gradient: const LinearGradient(
                //                 begin: Alignment.topCenter,
                //                 end: Alignment.bottomCenter,
                //                 colors: [
                //                   MyColors.blackOpacity,
                //                   MyColors.blackOpacity2,
                //                   MyColors.blackOpacity3,
                //                 ])),
                //         child: Center(
                //           child: Text(
                //             "MAGAZINES",
                //             style: TextStyle(
                //               fontFamily: MyFont.myFont,
                //               fontWeight: FontWeight.bold,
                //               fontSize: 18,
                //               color: MyColors.white,
                //             ),
                //           ),
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
                // const SizedBox(height: 20),
                categoryGrid(),
              ],
            ),
          ));
    });
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (inCatController.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                    arguments: inCatController.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (inCatController.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        inCatController.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }

  ///Category Grid View builder

  List title = [
    "ANIMATION",
    "ARCHITECTURE",
    "ART",
    "CHILDREN",
    "FASHION",
    "FOOD & DRINKS",
    "NEW INTERIOR DESIGN STYLE",
    "PHOTOGRAPHY",
    "SELF HELP CREATIVITY",
    "SKETCHING",
    "TRAVELING",
    "MINDFUL",
  ];

  categoryGrid() {
    return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.categoryList.value?.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1.2,
          crossAxisSpacing: 20.0,
        ),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Get.toNamed(Routes.individualCategoryScreen,
                  arguments: controller.categoryList.value?[index].code ?? "");
            },
            child: Stack(
              children: [
                SizedBox(
                    height: 130,
                    width: width(context),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20.0),
                      child: Image.asset(
                        Assets.cat1,
                        fit: BoxFit.fill,
                      ),
                    )),
                Container(
                  height: 130,
                  width: width(context),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            MyColors.blackOpacity,
                            MyColors.blackOpacity2,
                            MyColors.blackOpacity3,
                          ])),
                  child: Center(
                    child: Text(
                      controller.categoryList.value?[index].name
                              ?.toUpperCase() ??
                          "",
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: MyColors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }
}
