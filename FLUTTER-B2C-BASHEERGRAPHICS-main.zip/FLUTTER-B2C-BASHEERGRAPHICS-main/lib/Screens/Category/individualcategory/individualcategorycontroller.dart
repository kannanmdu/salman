import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Helper/NetworkManger.dart';
import '../../../Helper/api.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/ProductModelRef.dart';
import '../../../locator/cart_service.dart';
import '../../../locator/locator.dart';

class InCatController extends GetxController with StateMixin {
  RxBool isCatAddClick = true.obs;
  RxBool isLoading = false.obs;

  ProductModel? productModel;

  RxList<ProductModel> productList = <ProductModel>[].obs;

  RxList<ProductModel> cartAddedProduct = <ProductModel>[].obs;

  final CartService cartService = getIt<CartService>();
  RxInt selectedIndex = 0.obs;

  int totalPages = 1;
  int currentPage = 1;

  Future<void> getProductByCategoryId(String? categoryCode, {required bool isPagination}) async {
    // isLoading = true.obs;
    // await GetFavProduct();
    change(null, status: RxStatus.loadingMore());
    await NetworkManager.get(
      url: HttpUrl.getAllProduct,
      parameters: {
        "OrganizationId": HttpUrl.org,
        "TranNo": "",
        "ISBN10": "",
        "ISBN13": "",
        "categories": categoryCode,
        "pageNo" : "${currentPage}",
        "pageSize" : "12",
      },
    ).then((response) {
      // isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.result != null) {
          // List? resJson = response.apiResponseModel!.result!;
          // print("::::::::::::::::");
          // print(resJson);
          // if (resJson != null) {
          //   List<ProductModel> list;
          //   list = resJson.map<ProductModel>((value) {
          //     return ProductModel.fromJson(value);
          //   }).toList();
          //   productList.value = list;
          //   print("::::::::::::::::");
          //   print(productList.value?.length);
          //   updateProductCount();
          //   change(null, status: RxStatus.success());
          //   return;
          List? resJson = response.apiResponseModel!.result!;
          if (resJson != null) {
            List<ProductModel> list;
            print("++++++++++++++++++++++++++++++22222222");
            list = resJson.map<ProductModel>((value) {
              return ProductModel.fromJson(value);
            }).toList();
            if (!isPagination) {
              productList.clear();
            }
            productList.value.addAll(list);
            print("productList.length");
            print(productList.length);
            totalPages = response.apiResponseModel?.totalNumberOfPages ?? 1;
            currentPage++;
            updateProductCount();
            change(productList);
          }
        } else {
          productList.value = [];
        }
        change(null, status: RxStatus.success());
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }

  Future<void> updateProductCount() async {
    for (var product in productList) {
      cartService.cartItems.firstWhereOrNull((element) {
        if (element.bookId == product.bookId) {
          product.qtyCount = element.qtyCount;
          return true;
        } else {
          return false;
        }
      });
    }
  }
}
