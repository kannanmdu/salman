import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import '../../../Const/size.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/ProductModelRef.dart';
import 'individualcategorycontroller.dart';

class IndividualCategoryScreen extends StatefulWidget {
  const IndividualCategoryScreen({super.key});

  @override
  State<IndividualCategoryScreen> createState() =>
      _IndividualCategoryScreenState();
}

class _IndividualCategoryScreenState extends State<IndividualCategoryScreen> {
  late InCatController controller;

  ///Increment - Decrement Function
  int counter = 1;

  void increment() {
    setState(() {
      counter++;
    });
  }

  void decrement() {
    setState(() {
      if (counter > 0) {
        counter--;
      }
    });
  }

  String? categoryCode;

  List<String> savedProduct = [];

  final ScrollController scrollController = ScrollController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(InCatController());
    categoryCode = Get.arguments as String;
    print("..........$categoryCode..............");
    controller.currentPage =1;
    controller.getProductByCategoryId(categoryCode,isPagination: false);
    controller.cartService.cartChangeStream.listen((_) {
      setState(() {});
    });
    initData();
    controller.updateProductCount();
  }

  late final List<ProductModel> localData;


  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    scrollController.addListener(_scrollListener);
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      controller.cartAddedProduct.clear();
      controller.cartAddedProduct.addAll(localData);
    }
  }

  final _scrollThreshold = 200.0;


  Future<void> _scrollListener() async {
    final maxScroll = scrollController.position.maxScrollExtent;
    final currentScroll = scrollController.position.pixels;
    if (maxScroll - currentScroll <= _scrollThreshold) {
      if (controller.currentPage <= controller.totalPages &&
          !controller.status.isLoadingMore) {
        // await controller.getProductByCategoryId(
        //     categoryId: catrogryModel?.code ?? '',
        //     subCategoryId:
        //     (slectedSubCategoryId == "" || slectedSubCategoryId == null)
        //         ? ""
        //         : slectedSubCategoryId,
        //     isPagination: true,
        //     subCategoryL2Name: subSubCategoryId ?? "");
      await controller.getProductByCategoryId(categoryCode,isPagination: true);
      }
    }
  }



  @override
  Widget build(BuildContext context) {
    return GetBuilder<InCatController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Books",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Image.asset(
                  Assets.notification,
                  scale: 3,
                )),
            // IconButton(
            //     onPressed: () {},
            //     icon: const Icon(Icons.shopping_cart_rounded,
            //         color: MyColors.primaryCustom, size: 30))
            buildAppBarCartButton(),
          ],
        ),
        body:
        // (controller.productList.value != null)
        //     ? controller.productList.value!.isNotEmpty
        //         ?
        SingleChildScrollView(
          // controller:  scrollController,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(18.0),
                    child: Column(
                      children: [
                        // inCatGridView(),
                        Container(
                          height: height(context) / 1.23,
                          // width: width(context) / 1.25,
                          child: inCatGridView(),
                        ),
                        if (controller.status.isLoading)
                          const Center(
                              child: CircularProgressIndicator(color: MyColors.mainTheme)
                          )
                      ],
                    ))
            //     : Center(
            //         child: Image.asset(Assets.noImage),
            //       )
            // : Center(
            //     child: Image.asset(Assets.noImage),
            //   ),
      );
    });
  }

  ///For You GridView Builder

  List book = [
    Assets.book1,
    Assets.book2,
    Assets.book3,
    Assets.book4,
    Assets.book5,
  ];

  inCatGridView() {
    // return
    if ((controller.productList.value.isNotEmpty)) {
      return Column(
        children: [
          Expanded(
            child: Obx(() {
              return GridView.builder(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  controller:  scrollController,
                  physics: const ScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisExtent: 190,
                  ),
                  itemCount: controller.productList.value?.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        Get.toNamed(Routes.productDetailScreen,
                            arguments: controller.productList.value?[index]);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(5),
                        child: Stack(
                          fit: StackFit.passthrough,
                          alignment: Alignment.center,
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(10.0),
                                child: (controller.productList[index].bookImage != null)
                                    ? (controller
                                    .productList[index].bookImage!.isNotEmpty)
                                    ? Image.network(
                                    '${controller.productList[index].bookImage}',
                                    fit: BoxFit.fill)
                                    : Image.asset(Assets.noBook)
                                    : Image.asset(Assets.noBook)),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(3, 110, 3, 0),
                              child: (controller.productList[index].qtyCount == 0)
                                  ? GestureDetector(
                                onTap: () async {
                                  ProductModel? selectedProduct =
                                  controller.productList.value[index];
                                  if (savedProduct
                                      .contains(selectedProduct.bookId)) {
                                    var selectedIndex = controller.cartAddedProduct
                                        .indexWhere((element) =>
                                    element.bookId ==
                                        selectedProduct.bookId);

                                    controller.cartAddedProduct
                                        .removeAt(selectedIndex);
                                    savedProduct.remove(selectedProduct.bookId);
                                  }
                                  setState(() {
                                    controller.cartService
                                        .addToCart(product: selectedProduct);
                                    controller.updateProductCount();
                                  });

                                  if (selectedProduct.qtyCount != 0) {
                                    bool isAlreadyAdded =
                                    controller.cartAddedProduct.any((element) =>
                                    element.bookId ==
                                        selectedProduct.bookId);

                                    if (!isAlreadyAdded) {
                                      controller.cartAddedProduct
                                          .add(selectedProduct);
                                    }
                                  }
                                  await PreferenceHelper.saveCartData(
                                      controller.cartAddedProduct);
                                },
                                child: const Align(
                                  alignment: Alignment.centerRight,
                                  child: SizedBox(
                                    child: CircleAvatar(
                                      child: Icon(Icons.add),
                                    ),
                                  ),
                                ),
                              )
                                  : Padding(
                                padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                child: Container(
                                  decoration: BoxDecoration(
                                      color: MyColors.white,
                                      borderRadius: BorderRadius.circular(40.0)),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 1, vertical: 5.5),
                                    child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      children: [
                                        GestureDetector(
                                          onTap: () async {
                                            ProductModel? selectedProduct =
                                            controller.productList[index];

                                            setState(() {
                                              controller.cartService.removeFromCart(
                                                  product: selectedProduct);
                                              controller.updateProductCount();
                                            });

                                            if (selectedProduct.qtyCount == 0) {
                                              if (controller.cartAddedProduct.any(
                                                      (element) =>
                                                  element.bookId ==
                                                      selectedProduct.bookId)) {
                                                var selectedIndex = controller
                                                    .cartAddedProduct
                                                    .indexWhere((element) =>
                                                element.bookId ==
                                                    selectedProduct.bookId);

                                                controller.cartAddedProduct
                                                    .removeAt(selectedIndex);
                                                if (controller
                                                    .cartAddedProduct.isEmpty) {
                                                  controller.cartAddedProduct
                                                      .clear();
                                                }
                                              }
                                            }
                                            // bottomAppBar(index);
                                            // if (controller.productList[index].qtycount == 0) {
                                            //   controller.cartAddedProduct.length = 0;
                                            // }
                                            await PreferenceHelper.saveCartData(
                                                controller.cartAddedProduct);
                                          },
                                          child: const CircleAvatar(
                                            child: Icon(
                                              Icons.remove,
                                              color: MyColors.white,
                                              size: 18,
                                            ),
                                          ),
                                        ),
                                        // Obx(() {
                                        //   return
                                        AnimatedSwitcher(
                                          duration:
                                          const Duration(milliseconds: 300),
                                          transitionBuilder: (Widget child,
                                              Animation<double> animation) {
                                            return ScaleTransition(
                                                scale: animation, child: child);
                                          },
                                          child: SizedBox(
                                            width: 20,
                                            child: Text(
                                              '${controller.productList[index].qtyCount.toInt()}',
                                              key: ValueKey<int>(
                                                controller
                                                    .productList[index].qtyCount
                                                    .toInt() ??
                                                    0,
                                              ),
                                              style: TextStyle(
                                                fontFamily: MyFont.myFont,
                                                color: MyColors.black,
                                                fontSize: 16,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                        // }),
                                        GestureDetector(
                                          onTap: () async {
                                            ProductModel? selectedProduct =
                                            controller.productList.value[index];
                                            if (savedProduct
                                                .contains(selectedProduct.bookId)) {
                                              var selectedIndex = controller
                                                  .cartAddedProduct
                                                  .indexWhere((element) =>
                                              element.bookId ==
                                                  selectedProduct.bookId);

                                              controller.cartAddedProduct
                                                  .removeAt(selectedIndex);
                                              savedProduct
                                                  .remove(selectedProduct.bookId);
                                            }
                                            setState(() {
                                              controller.cartService.addToCart(
                                                  product: selectedProduct);
                                              controller.updateProductCount();
                                            });

                                            if (selectedProduct.qtyCount != 0) {
                                              bool isAlreadyAdded = controller
                                                  .cartAddedProduct
                                                  .any((element) =>
                                              element.bookId ==
                                                  selectedProduct.bookId);

                                              if (!isAlreadyAdded) {
                                                controller.cartAddedProduct
                                                    .add(selectedProduct);
                                              }
                                            }
                                            await PreferenceHelper.saveCartData(
                                                controller.cartAddedProduct);
                                          },
                                          child: const CircleAvatar(
                                            child: Icon(
                                              Icons.add,
                                              color: MyColors.white,
                                              size: 18,
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  });
            }),
          ),
          if (controller.status.isLoadingMore)
            Center(
                child: CircularProgressIndicator(color: MyColors.mainTheme)
            ),
        ],
      );
    } else if (controller.status.isLoadingMore || controller.status.isLoading) {
      return Center(
          child: CircularProgressIndicator(color: MyColors.mainTheme)
      );
    } else {
      return Center(
        child: Image.asset(Assets.noImage),
      );
    }
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (controller.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                    arguments: controller.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (controller.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        controller.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }
}
