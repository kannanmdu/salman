import 'package:book/Helper/preferencehelper.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Helper/NetworkManger.dart';
import '../../Helper/api.dart';
import '../../ModelClass/CategoryModel.dart';

class CategoryController extends GetxController with StateMixin {
  RxBool isLoading = false.obs;

  Rx<List<CategoryModel>?> categoryList = (null as List<CategoryModel>?).obs;

  getAllCategoryList() {
    isLoading.value = true;
    NetworkManager.get(url: HttpUrl.getAllCategory, parameters: {})
        .then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        change(null, status: RxStatus.success());
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            List<CategoryModel> list = resJson.map<CategoryModel>((value) {
              return CategoryModel.fromJson(value);
            }).toList();
            categoryList.value = list;
            change(null, status: RxStatus.success());
            return;
          }
        } else {
          change(null, status: RxStatus.error());
          PreferenceHelper.getShowSnackBar(
              msg: response.apiResponseModel!.message ?? "");
        }
      } else {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(
            msg: response.apiResponseModel!.message ?? "");
      }
    }).catchError(
      (error) {
        change(null, status: RxStatus.error());
        PreferenceHelper.getShowSnackBar(msg: error.toString() ?? "");
      },
    );
  }
}
