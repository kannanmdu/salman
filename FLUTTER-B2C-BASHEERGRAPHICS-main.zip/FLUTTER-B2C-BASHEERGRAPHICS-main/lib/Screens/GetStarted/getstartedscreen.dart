import 'dart:async';

import 'package:book/Const/color.dart';
import 'package:book/Screens/Login/loginscreen.dart';
import 'package:book/Screens/SplashScreen/splashscreen.dart';
import 'package:flutter/material.dart';

import '../../Const/assets.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/B2CCustomerLogin.dart';
import '../BottomNavBar/bottonnavigationbar.dart';

class GetStartedScreen extends StatefulWidget {
  const GetStartedScreen({super.key});

  @override
  State<GetStartedScreen> createState() => _GetStartedScreenState();
}

class _GetStartedScreenState extends State<GetStartedScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  var b2cCustomer;
  B2cLoginModel? b2cLoginModel;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _initialiseData();

    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (builder) => (b2cLoginModel != null)
                  ? const BottomNavBar()
                  : const SplashScreen()));
    });

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3), // Adjust the duration as needed
    );

    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_controller);

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose(); // Dispose the animation controller
    super.dispose();
  }

  _initialiseData() async {
    b2cLoginModel = await PreferenceHelper.getUserData();
    setState(() {
      b2cCustomer = b2cLoginModel?.b2CCustomerId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
                // decoration:
                //     BoxDecoration(border: Border.all(color: MyColors.white)),
                child: Image.asset(
              Assets.start,
            )),
            FadeTransition(
              opacity: _animation,
              child: Image.asset(
                Assets.appName,
                scale: 5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
