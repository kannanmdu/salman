import 'package:book/Const/size.dart';
import 'package:book/Screens/Payment/paymentcontroller.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:book/Widget/textformfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  late PaymentController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(PaymentController());
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.payKey,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Payment",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: Text(
                      "Cancel",
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: MyColors.grey,
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Text(
                    "Checkout",
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: MyColors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              ///Slider Pending
              Text(
                "Choose a payment method",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: MyColors.white,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "You will not be charged until you review this order on the next page.",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: MyColors.grey,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Theme(
                    data: ThemeData(
                        unselectedWidgetColor: MyColors.primaryCustom),
                    child: Radio(
                      value: 1,
                      groupValue: controller.selectedValue,
                      onChanged: (int? value) {
                        setState(() {
                          controller.selectedValue = value;
                        });
                      },
                    ),
                  ),
                  Text(
                    "Cash on Delivery",
                    style: TextStyle(
                      fontFamily: MyFont.myFont,
                      fontWeight: FontWeight.normal,
                      color: MyColors.white,
                    ),
                  )
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Theme(
                        data: ThemeData(
                            unselectedWidgetColor: MyColors.primaryCustom),
                        child: Radio(
                          value: 2,
                          groupValue: controller.selectedValue,
                          onChanged: (int? value) {
                            setState(() {
                              controller.selectedValue = value;
                            });
                          },
                        ),
                      ),
                      Text(
                        "Credit card",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.normal,
                          color: MyColors.white,
                        ),
                      ),
                    ],
                  ),
                  Image.asset(
                    Assets.visa,
                    scale: 3,
                  )
                ],
              ),
              const SizedBox(height: 20),
              Text(
                "Name on card",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: MyColors.white,
                ),
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.cardNameController,
                inputFormatters: [],
                hintText: "Card Name",
              ),
              const SizedBox(height: 20),
              Text(
                "Card number",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: MyColors.white,
                ),
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.cardNumController,
                inputFormatters: [],
                hintText: "Card Number",
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: width(context) / 2.5,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Expiration date",
                          style: TextStyle(
                            fontFamily: MyFont.myFont,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: MyColors.white,
                          ),
                        ),
                        const SizedBox(height: 20),
                        CustomTextFormField(
                          controller: controller.cardExpDateController,
                          inputFormatters: [],
                          hintText: "MM/YY",
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: width(context) / 2.5,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Security code",
                          style: TextStyle(
                            fontFamily: MyFont.myFont,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: MyColors.white,
                          ),
                        ),
                        const SizedBox(height: 20),
                        CustomTextFormField(
                          controller: controller.cardExpDateController,
                          inputFormatters: [],
                          hintText: "",
                        ),
                      ],
                    ),
                  )
                ],
              ),
              const SizedBox(height: 20),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Theme(
                    data: ThemeData(
                        unselectedWidgetColor: MyColors.primaryCustom),
                    child: Checkbox(
                      value: controller.isChecked,
                      onChanged: (bool? value) {
                        setState(() {
                          controller.isChecked = value!;
                        });
                      },
                    ),
                  ),
                  Flexible(
                    child: Text(
                      "My billing address is the same as my shipping address.",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        color: MyColors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: SubmitButton(
              isLoading: false,
              onTap: () {
                Get.toNamed(Routes.paymentConfirmationScreen);
              },
              title: "Confirm and Continue"),
        ),
      ),
    );
  }
}
