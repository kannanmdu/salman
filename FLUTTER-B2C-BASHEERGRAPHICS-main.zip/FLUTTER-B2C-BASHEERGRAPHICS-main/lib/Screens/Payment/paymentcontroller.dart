import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PaymentController extends GetxController with StateMixin {
  int? selectedValue;
  bool isChecked = false;

  final payKey = GlobalKey<FormState>();

  TextEditingController cardNameController = TextEditingController();
  TextEditingController cardNumController = TextEditingController();
  TextEditingController cardExpDateController = TextEditingController();
  TextEditingController cardSecurityCodeController = TextEditingController();
}
