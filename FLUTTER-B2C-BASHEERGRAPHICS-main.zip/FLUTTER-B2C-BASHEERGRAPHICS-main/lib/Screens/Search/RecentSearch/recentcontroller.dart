import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RecentController extends GetxController with StateMixin {
  RxBool isRecentSearchClick = true.obs;
}
