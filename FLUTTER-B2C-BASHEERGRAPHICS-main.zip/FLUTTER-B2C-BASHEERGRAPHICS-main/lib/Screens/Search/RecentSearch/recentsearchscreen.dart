import 'package:book/Const/fonts.dart';
import 'package:book/Screens/Search/RecentSearch/recentcontroller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Const/assets.dart';
import '../../../Const/color.dart';

class RecentSearchScreen extends StatefulWidget {
  const RecentSearchScreen({super.key});

  @override
  State<RecentSearchScreen> createState() => _RecentSearchScreenState();
}

class _RecentSearchScreenState extends State<RecentSearchScreen> {
  late RecentController controller;

  ///Increment - Decrement Function
  int counter = 1;

  void increment() {
    setState(() {
      counter++;
    });
  }

  void decrement() {
    setState(() {
      if (counter > 0) {
        counter--;
      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(RecentController());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: MyColors.bars,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Image.asset(
            Assets.arrow,
            scale: 4,
          ),
        ),
        title: Text(
          "Recent Search",
          style: TextStyle(
            fontFamily: MyFont.myFont,
            color: MyColors.white,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {},
              icon: Image.asset(
                Assets.notification,
                scale: 3,
              )),
          IconButton(
              onPressed: () {},
              icon: const Icon(Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom, size: 30))
        ],
      ),
      body: SingleChildScrollView(
        physics: const ScrollPhysics(),
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            forYouGridView(),
          ],
        ),
      ),
    );
  }

  ///For You GridView Builder

  List book = [
    Assets.book1,
    Assets.book2,
    Assets.book3,
    Assets.book4,
    Assets.book5,
  ];

  forYouGridView() {
    return GridView.builder(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisExtent: 180,
        ),
        itemCount: book.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8),
            child: Stack(
              fit: StackFit.passthrough,
              alignment: Alignment.center,
              children: [
                ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Image.asset(
                      book[index],
                      fit: BoxFit.fill,
                    )),
                Padding(
                  padding: const EdgeInsets.only(
                      top: 110, left: 2, right: 2, bottom: 10),
                  child: Container(
                    height: 50,
                    width: 120,
                    padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
                    decoration: BoxDecoration(
                        color: controller.isRecentSearchClick.value
                            ? Colors.transparent
                            : MyColors.white,
                        borderRadius: controller.isRecentSearchClick.value
                            ? BorderRadius.zero
                            : BorderRadius.circular(60.0),
                        border: controller.isRecentSearchClick.value
                            ? const Border.fromBorderSide(BorderSide.none)
                            : Border.all(
                                color: MyColors.primaryCustom, width: 2)),
                    child: controller.isRecentSearchClick.value
                        ? Align(
                            alignment: Alignment.centerRight,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  controller.isRecentSearchClick.value =
                                      !controller.isRecentSearchClick.value;
                                });
                              },
                              child: const CircleAvatar(
                                backgroundColor: MyColors.mainTheme,
                                child: Icon(
                                  Icons.add,
                                  color: MyColors.white,
                                ),
                              ),
                            ),
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  if (counter > 1) {
                                    setState(() {
                                      decrement();
                                    });
                                  } else {
                                    setState(() {
                                      controller.isRecentSearchClick.value =
                                          !controller.isRecentSearchClick.value;
                                    });
                                  }
                                },
                                child: CircleAvatar(
                                  backgroundColor: MyColors.mainTheme,
                                  child: (counter > 1)
                                      ? const Icon(
                                          Icons.remove,
                                          color: MyColors.white,
                                        )
                                      : const Icon(
                                          Icons.delete,
                                          size: 15,
                                          color: MyColors.white,
                                        ),
                                ),
                              ),
                              FittedBox(
                                child: SizedBox(
                                  width: 20,
                                  child: Center(
                                    child: Text(
                                      "$counter",
                                      style: TextStyle(
                                        fontFamily: MyFont.myFont,
                                        fontWeight: FontWeight.normal,
                                        color: MyColors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    increment();
                                  });
                                },
                                child: const CircleAvatar(
                                  backgroundColor: MyColors.mainTheme,
                                  child: Icon(
                                    Icons.add,
                                    size: 20,
                                    color: MyColors.white,
                                  ),
                                ),
                              )
                            ],
                          ),
                  ),
                ),
              ],
            ),
          );
        });
  }
}
