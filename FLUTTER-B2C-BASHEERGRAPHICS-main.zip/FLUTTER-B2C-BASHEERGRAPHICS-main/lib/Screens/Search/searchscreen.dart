import 'package:book/Const/size.dart';
import 'package:book/Screens/Search/searchcontroller.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:book/Widget/textformfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';
import '../../Helper/preferencehelper.dart';
import '../../Helper/search_dropdown_textfield2.dart';
import '../../ModelClass/AuthorModel.dart';
import '../../ModelClass/ProductModelRef.dart';
import '../../Widget/constructor.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late SearchScreenController controller;

  ///Increment - Decrement Function
  int counter = 1;

  void increment() {
    setState(() {
      counter++;
    });
  }

  void decrement() {
    setState(() {
      if (counter > 0) {
        counter--;
      }
    });
  }

  String? authorName = '';
  String?  name = '';

  List<String> savedProduct = [];
  final _scrollThreshold = 200.0;

  final ScrollController scrollController = ScrollController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(SearchScreenController());
    controller.getAllCustomerList();
    scrollController.addListener(_scrollListener);
  }

  late final List<ProductModel> localData;


  Future<void> initData() async {
    localData = await PreferenceHelper.getCartData();
    scrollController.addListener(_scrollListener);
    if (localData != null) {
      for (int i = 0; i < localData.length; i++) {
        savedProduct.add(localData[i].bookId!);
      }
      controller.cartAddedProduct.clear();
      controller.cartAddedProduct.addAll(localData);
    }
  }



  Future<void> _scrollListener() async {
    final maxScroll = scrollController.position.maxScrollExtent;
    final currentScroll = scrollController.position.pixels;
    if (maxScroll - currentScroll <= _scrollThreshold) {
      if (controller.currentPage <= controller.totalPages &&
          !controller.status.isLoadingMore) {
        // await controller.getProductByCategoryId(
        //     categoryId: catrogryModel?.code ?? '',
        //     subCategoryId:
        //     (slectedSubCategoryId == "" || slectedSubCategoryId == null)
        //         ? ""
        //         : slectedSubCategoryId,
        //     isPagination: true,
        //     subCategoryL2Name: subSubCategoryId ?? "");
       await controller.getProductByCategoryId(authorName,name,isPagination: true);
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder<SearchScreenController>(builder: (logic) {
      if (logic.isLoading.value) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }
      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.offAllNamed(Routes.bottomNavBar);
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Search",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Image.asset(
                  Assets.notification,
                  scale: 3,
                )),
            buildAppBarCartButton(),
          ],
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 18, 10, 5),
              child: SizedBox(
                  // width: width(context) / 1,
                  child: CustomTextFormField(
                      controller: controller.searchController,
                      hintText: "Book Name",
                      hintTextStyle: const TextStyle(
                        fontWeight: FontWeight.w600,color: Colors.black
                      ),
                      inputFormatters: [],
                    onChanged: (value) {
                        setState(() {
                          name =  value;
                        });
                    }
                  )),
            ),
            Container(
              height: 60,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Obx(() {
                  return SearchDropdownTextField<
                      AuthorModel>(
                      hintText: 'Author Name',
                      hintTextStyle: TextStyle(
                        fontFamily: MyFont.myFont,
                        color: MyColors.black,
                      ),
                      textStyle: TextStyle(
                        fontFamily: MyFont.myFont,
                        color: MyColors.black,
                      ),
                      // suffixIcon: const Icon(
                      //   Icons.clear,
                      //   color: MyColors.black,
                      // ),
                      inputBorder: BorderSide.none,
                      filled: true,
                      filledColor: MyColors.white,
                      border: const OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                      items: controller.getCustomerList.value,
                      color: Colors.black54,
                      selectedItem: controller.selectedBusinessCategory,
                      isValidator: false,
                      // errorMessage: '*',
                      // onAddPressed: () {
                      // setState(() {
                      //   businessCategoryId = "";
                      //   controller.selectedBusinessCategory =
                      //   null;
                      // });
                      // },
                      onChanged: (value) {
                        FocusScope.of(context).unfocus();
                        controller.selectedBusinessCategory = value;
                        authorName = value.authorName;
                      });
                }),
              ),
            ),
            const SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                    width: width(context) / 3,
                    child: SubmitButton(
                        isLoading: false,
                        onTap: () {
                          setState(() {
                            controller.searchController.text = "";
                            name = "";
                            controller.selectedBusinessCategory = null;
                            authorName = "";
                            controller.productList.clear();
                          });
                    }, title: "Clear")),
                SizedBox(
                    width: width(context) / 3,
                    child: SubmitButton(
                        isLoading: false, onTap: () {
                      controller.currentPage = 1;
                      controller.getProductByCategoryId(authorName,name,isPagination: false,);
                    }, title: "Search"))
              ],
            ),
            // const SizedBox(height: 20),
            // Padding(
            //   padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       SizedBox(
            //           width: width(context) / 2.3,
            //           child: CustomTextFormField(
            //             controller: controller.fromDateController,
            //             inputFormatters: [],
            //             hintText: "From Date",
            //             suffixIcon: IconButton(
            //                 onPressed: () {},
            //                 icon: const Icon(
            //                   Icons.calendar_month,
            //                   color: MyColors.primaryCustom,
            //                 )),
            //           )),
            //       SizedBox(
            //         width: width(context) / 2.3,
            //         child: CustomTextFormField(
            //           controller: controller.toDateController,
            //           inputFormatters: [],
            //           hintText: "To Date",
            //           suffixIcon: IconButton(
            //               onPressed: () {},
            //               icon: const Icon(
            //                 Icons.calendar_month,
            //                 color: MyColors.primaryCustom,
            //               )),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // const SizedBox(height: 20),
            // SizedBox(
            //   height: 40,
            //   child: searchCategoryList(),
            // ),
            // const SizedBox(height: 20),
            // searchGridView(),
            // const SizedBox(height: 20),
            // Padding(
            //   padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       Text(
            //         "Recent Search",
            //         style: TextStyle(
            //           fontFamily: MyFont.myFont,
            //           fontWeight: FontWeight.bold,
            //           fontSize: 18,
            //           color: MyColors.white,
            //         ),
            //       ),
            //       TextButton(
            //         onPressed: () {
            //           Get.toNamed(Routes.recentSearchScreen);
            //         },
            //         child: Text(
            //           "View All",
            //           style: TextStyle(
            //             fontFamily: MyFont.myFont,
            //             fontWeight: FontWeight.normal,
            //             fontSize: 18,
            //             color: MyColors.primaryCustom,
            //           ),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // const SizedBox(height: 10),
            // Container(
            //   color: MyColors.bars,
            //   height: 260,
            //   child: recentSearchList(),
            // ),
            // const SizedBox(height: 10),
            // Padding(
            //   padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       Text(
            //         "For you",
            //         style: TextStyle(
            //           fontFamily: MyFont.myFont,
            //           fontWeight: FontWeight.bold,
            //           fontSize: 18,
            //           color: MyColors.white,
            //         ),
            //       ),
            //       TextButton(
            //         onPressed: () {
            //           Get.toNamed(Routes.forYouScreen);
            //         },
            //         child: Text(
            //           "View All",
            //           style: TextStyle(
            //             fontFamily: MyFont.myFont,
            //             fontWeight: FontWeight.normal,
            //             fontSize: 18,
            //             color: MyColors.primaryCustom,
            //           ),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // const SizedBox(height: 10),
            // Container(
            //   color: MyColors.bars,
            //   height: 260,
            //   child: forYouList(),
            // ),

         // if (controller.productList == null)


        // Obx(() {
        //   if (controller.productList.value.isEmpty) {
        //     return const Center(
        //       child: Text(''),
        //     );
        //   } else {
        //     return Expanded(
        //       child: GridView.builder(
        //           shrinkWrap: true,
        //           padding: EdgeInsets.zero,
        //           controller:  scrollController,
        //           physics: const ScrollPhysics(),
        //           scrollDirection: Axis.vertical,
        //           gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        //             crossAxisCount: 3,
        //             mainAxisExtent: 190,
        //           ),
        //           itemCount: controller.productList.value?.length,
        //           itemBuilder: (context, index) {
        //             return GestureDetector(
        //               onTap: () {
        //                 Get.toNamed(Routes.productDetailScreen,
        //                     arguments: controller.productList.value?[index]);
        //               },
        //               child: Padding(
        //                 padding: const EdgeInsets.all(5),
        //                 child: Stack(
        //                   fit: StackFit.passthrough,
        //                   alignment: Alignment.center,
        //                   children: [
        //                     ClipRRect(
        //                         borderRadius: BorderRadius.circular(10.0),
        //                         child: (controller.productList[index].bookImage != null)
        //                             ? (controller
        //                             .productList[index].bookImage!.isNotEmpty)
        //                             ? Image.network(
        //                             '${controller.productList[index].bookImage}',
        //                             fit: BoxFit.fill)
        //                             : Image.asset(Assets.noBook)
        //                             : Image.asset(Assets.noBook)),
        //                     Padding(
        //                       padding: const EdgeInsets.fromLTRB(3, 110, 3, 0),
        //                       child: (controller.productList[index].qtyCount == 0)
        //                           ? GestureDetector(
        //                         onTap: () async {
        //                           ProductModel? selectedProduct =
        //                           controller.productList.value[index];
        //                           if (savedProduct
        //                               .contains(selectedProduct.bookId)) {
        //                             var selectedIndex = controller.cartAddedProduct
        //                                 .indexWhere((element) =>
        //                             element.bookId ==
        //                                 selectedProduct.bookId);
        //
        //                             controller.cartAddedProduct
        //                                 .removeAt(selectedIndex);
        //                             savedProduct.remove(selectedProduct.bookId);
        //                           }
        //                           setState(() {
        //                             controller.cartService
        //                                 .addToCart(product: selectedProduct);
        //                             controller.updateProductCount();
        //                           });
        //
        //                           if (selectedProduct.qtyCount != 0) {
        //                             bool isAlreadyAdded =
        //                             controller.cartAddedProduct.any((element) =>
        //                             element.bookId ==
        //                                 selectedProduct.bookId);
        //
        //                             if (!isAlreadyAdded) {
        //                               controller.cartAddedProduct
        //                                   .add(selectedProduct);
        //                             }
        //                           }
        //                           await PreferenceHelper.saveCartData(
        //                               controller.cartAddedProduct);
        //                         },
        //                         child: const Align(
        //                           alignment: Alignment.centerRight,
        //                           child: SizedBox(
        //                             child: CircleAvatar(
        //                               child: Icon(Icons.add),
        //                             ),
        //                           ),
        //                         ),
        //                       )
        //                           : Padding(
        //                         padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
        //                         child: Container(
        //                           decoration: BoxDecoration(
        //                               color: MyColors.white,
        //                               borderRadius: BorderRadius.circular(40.0)),
        //                           child: Padding(
        //                             padding: const EdgeInsets.symmetric(
        //                                 horizontal: 1, vertical: 5.5),
        //                             child: Row(
        //                               mainAxisAlignment:
        //                               MainAxisAlignment.spaceAround,
        //                               children: [
        //                                 GestureDetector(
        //                                   onTap: () async {
        //                                     ProductModel? selectedProduct =
        //                                     controller.productList[index];
        //
        //                                     setState(() {
        //                                       controller.cartService.removeFromCart(
        //                                           product: selectedProduct);
        //                                       controller.updateProductCount();
        //                                     });
        //
        //                                     if (selectedProduct.qtyCount == 0) {
        //                                       if (controller.cartAddedProduct.any(
        //                                               (element) =>
        //                                           element.bookId ==
        //                                               selectedProduct.bookId)) {
        //                                         var selectedIndex = controller
        //                                             .cartAddedProduct
        //                                             .indexWhere((element) =>
        //                                         element.bookId ==
        //                                             selectedProduct.bookId);
        //
        //                                         controller.cartAddedProduct
        //                                             .removeAt(selectedIndex);
        //                                         if (controller
        //                                             .cartAddedProduct.isEmpty) {
        //                                           controller.cartAddedProduct
        //                                               .clear();
        //                                         }
        //                                       }
        //                                     }
        //                                     // bottomAppBar(index);
        //                                     // if (controller.productList[index].qtycount == 0) {
        //                                     //   controller.cartAddedProduct.length = 0;
        //                                     // }
        //                                     await PreferenceHelper.saveCartData(
        //                                         controller.cartAddedProduct);
        //                                   },
        //                                   child: const CircleAvatar(
        //                                     child: Icon(
        //                                       Icons.remove,
        //                                       color: MyColors.white,
        //                                       size: 18,
        //                                     ),
        //                                   ),
        //                                 ),
        //                                 // Obx(() {
        //                                 //   return
        //                                 AnimatedSwitcher(
        //                                   duration:
        //                                   const Duration(milliseconds: 300),
        //                                   transitionBuilder: (Widget child,
        //                                       Animation<double> animation) {
        //                                     return ScaleTransition(
        //                                         scale: animation, child: child);
        //                                   },
        //                                   child: SizedBox(
        //                                     width: 20,
        //                                     child: Text(
        //                                       '${controller.productList[index].qtyCount.toInt()}',
        //                                       key: ValueKey<int>(
        //                                         controller
        //                                             .productList[index].qtyCount
        //                                             .toInt() ??
        //                                             0,
        //                                       ),
        //                                       style: TextStyle(
        //                                         fontFamily: MyFont.myFont,
        //                                         color: MyColors.black,
        //                                         fontSize: 16,
        //                                       ),
        //                                       textAlign: TextAlign.center,
        //                                     ),
        //                                   ),
        //                                 ),
        //                                 // }),
        //                                 GestureDetector(
        //                                   onTap: () async {
        //                                     ProductModel? selectedProduct =
        //                                     controller.productList.value[index];
        //                                     if (savedProduct
        //                                         .contains(selectedProduct.bookId)) {
        //                                       var selectedIndex = controller
        //                                           .cartAddedProduct
        //                                           .indexWhere((element) =>
        //                                       element.bookId ==
        //                                           selectedProduct.bookId);
        //
        //                                       controller.cartAddedProduct
        //                                           .removeAt(selectedIndex);
        //                                       savedProduct
        //                                           .remove(selectedProduct.bookId);
        //                                     }
        //                                     setState(() {
        //                                       controller.cartService.addToCart(
        //                                           product: selectedProduct);
        //                                       controller.updateProductCount();
        //                                     });
        //
        //                                     if (selectedProduct.qtyCount != 0) {
        //                                       bool isAlreadyAdded = controller
        //                                           .cartAddedProduct
        //                                           .any((element) =>
        //                                       element.bookId ==
        //                                           selectedProduct.bookId);
        //
        //                                       if (!isAlreadyAdded) {
        //                                         controller.cartAddedProduct
        //                                             .add(selectedProduct);
        //                                       }
        //                                     }
        //                                     await PreferenceHelper.saveCartData(
        //                                         controller.cartAddedProduct);
        //                                   },
        //                                   child: const CircleAvatar(
        //                                     child: Icon(
        //                                       Icons.add,
        //                                       color: MyColors.white,
        //                                       size: 18,
        //                                     ),
        //                                   ),
        //                                 )
        //                               ],
        //                             ),
        //                           ),
        //                         ),
        //                       ),
        //                     ),
        //                   ],
        //                 ),
        //               ),
        //             );
        //           }),
        //     );
        //   }
        // }),
            const SizedBox(height: 10),
            inCatGridView(),
            if (controller.status.isLoadingMore)
              const Center(
                  child: CircularProgressIndicator(color: MyColors.mainTheme)
              ),
          ],
        ),
      );
    });
  }

  // ///Horizontal Listview
  //
  // int selectedListIndex = 0;
  //
  // List<SearchList> searchLists = [
  //   SearchList(
  //       text: 'Title',
  //       searchGrid: SearchGrid(image: [
  //         Assets.book1,
  //         Assets.book1,
  //         Assets.book1,
  //         Assets.book1,
  //         Assets.book1,
  //       ])),
  //   SearchList(
  //       text: 'Author',
  //       searchGrid: SearchGrid(image: [
  //         Assets.book2,
  //         Assets.book2,
  //         Assets.book2,
  //         Assets.book2,
  //         Assets.book2,
  //       ])),
  //   SearchList(
  //       text: 'Categories',
  //       searchGrid: SearchGrid(image: [
  //         Assets.book3,
  //         Assets.book3,
  //         Assets.book3,
  //         Assets.book3,
  //         Assets.book3,
  //       ])),
  //   SearchList(
  //       text: 'Series',
  //       searchGrid: SearchGrid(image: [
  //         Assets.book4,
  //         Assets.book4,
  //         Assets.book4,
  //         Assets.book4,
  //         Assets.book4,
  //       ])),
  // ];
  //
  // searchCategoryList() {
  //   return Padding(
  //     padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
  //     child: ListView.builder(
  //         shrinkWrap: true,
  //         physics: const ScrollPhysics(),
  //         scrollDirection: Axis.horizontal,
  //         itemCount: searchLists.length,
  //         itemBuilder: (context, index) {
  //           return GestureDetector(
  //             onTap: () {
  //               setState(() {
  //                 selectedListIndex = index;
  //               });
  //             },
  //             child: Card(
  //               color: selectedListIndex == index
  //                   ? MyColors.yellow
  //                   : MyColors.brown,
  //               shape: RoundedRectangleBorder(
  //                   borderRadius: BorderRadius.circular(20.0)),
  //               child: Padding(
  //                 padding: const EdgeInsets.symmetric(horizontal: 10),
  //                 child: Center(
  //                   child: Text(
  //                     searchLists[index].text,
  //                     style: TextStyle(
  //                         fontFamily: MyFont.myFont,
  //                         fontWeight: FontWeight.bold,
  //                         color: selectedListIndex == index
  //                             ? MyColors.white
  //                             : MyColors.lightBrown),
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           );
  //         }),
  //   );
  // }
  //
  // ///GridView Builder
  //
  // searchGridView() {
  //   return GridView.builder(
  //       shrinkWrap: true,
  //       padding: EdgeInsets.zero,
  //       physics: const NeverScrollableScrollPhysics(),
  //       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
  //         crossAxisCount: 3,
  //         mainAxisExtent: 180,
  //       ),
  //       itemCount: searchLists[selectedListIndex].searchGrid.image.length,
  //       itemBuilder: (context, index) {
  //         return Padding(
  //           padding: const EdgeInsets.all(8),
  //           child: Stack(
  //             fit: StackFit.passthrough,
  //             alignment: Alignment.center,
  //             children: [
  //               ClipRRect(
  //                   borderRadius: BorderRadius.circular(10.0),
  //                   child: Image.asset(
  //                     searchLists[selectedListIndex].searchGrid.image[index],
  //                     fit: BoxFit.fill,
  //                   )),
  //               Padding(
  //                 padding: const EdgeInsets.only(
  //                     top: 110, left: 5, right: 5, bottom: 10),
  //                 child: Container(
  //                   height: 50,
  //                   width: 120,
  //                   padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
  //                   decoration: BoxDecoration(
  //                       color: controller.isSearchButton.value
  //                           ? Colors.transparent
  //                           : MyColors.white,
  //                       borderRadius: controller.isSearchButton.value
  //                           ? BorderRadius.zero
  //                           : BorderRadius.circular(60.0),
  //                       border: controller.isSearchButton.value
  //                           ? const Border.fromBorderSide(BorderSide.none)
  //                           : Border.all(
  //                               color: MyColors.primaryCustom, width: 2)),
  //                   child: controller.isSearchButton.value
  //                       ? Align(
  //                           alignment: Alignment.centerRight,
  //                           child: InkWell(
  //                             onTap: () {
  //                               setState(() {
  //                                 controller.isSearchButton.value =
  //                                     !controller.isSearchButton.value;
  //                               });
  //                             },
  //                             child: const CircleAvatar(
  //                               backgroundColor: MyColors.mainTheme,
  //                               child: Icon(
  //                                 Icons.add,
  //                                 color: MyColors.white,
  //                               ),
  //                             ),
  //                           ),
  //                         )
  //                       : Row(
  //                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                           children: [
  //                             InkWell(
  //                               onTap: () {
  //                                 if (counter > 1) {
  //                                   setState(() {
  //                                     decrement();
  //                                   });
  //                                 } else {
  //                                   setState(() {
  //                                     controller.isSearchButton.value =
  //                                         !controller.isSearchButton.value;
  //                                   });
  //                                 }
  //                               },
  //                               child: CircleAvatar(
  //                                 backgroundColor: MyColors.mainTheme,
  //                                 child: (counter > 1)
  //                                     ? const Icon(
  //                                         Icons.remove,
  //                                         color: MyColors.white,
  //                                       )
  //                                     : const Icon(
  //                                         Icons.delete,
  //                                         size: 15,
  //                                         color: MyColors.white,
  //                                       ),
  //                               ),
  //                             ),
  //                             FittedBox(
  //                               child: SizedBox(
  //                                 width: 20,
  //                                 child: Center(
  //                                   child: Text(
  //                                     "$counter",
  //                                     style: TextStyle(
  //                                       fontFamily: MyFont.myFont,
  //                                       fontWeight: FontWeight.normal,
  //                                       color: MyColors.black,
  //                                     ),
  //                                   ),
  //                                 ),
  //                               ),
  //                             ),
  //                             InkWell(
  //                               onTap: () {
  //                                 setState(() {
  //                                   increment();
  //                                 });
  //                               },
  //                               child: const CircleAvatar(
  //                                 backgroundColor: MyColors.mainTheme,
  //                                 child: Icon(
  //                                   Icons.add,
  //                                   size: 20,
  //                                   color: MyColors.white,
  //                                 ),
  //                               ),
  //                             )
  //                           ],
  //                         ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         );
  //       });
  // }
  //
  // ///Recent Search
  //
  // List book = [
  //   Assets.book1,
  //   Assets.book2,
  //   Assets.book3,
  //   Assets.book4,
  //   Assets.book5,
  // ];
  //
  // recentSearchList() {
  //   return Padding(
  //     padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
  //     child: ListView.builder(
  //         shrinkWrap: true,
  //         itemCount: book.length,
  //         physics: const ScrollPhysics(),
  //         scrollDirection: Axis.horizontal,
  //         itemBuilder: (context, index) {
  //           return Padding(
  //             padding: const EdgeInsets.all(8),
  //             child: Stack(
  //               fit: StackFit.passthrough,
  //               alignment: Alignment.center,
  //               children: [
  //                 SizedBox(
  //                   height: 100,
  //                   width: 140,
  //                   child: ClipRRect(
  //                       borderRadius: BorderRadius.circular(10.0),
  //                       child: Image.asset(
  //                         book[index],
  //                         fit: BoxFit.fill,
  //                       )),
  //                 ),
  //                 Center(
  //                   child: Padding(
  //                     padding: const EdgeInsets.only(top: 140),
  //                     child: Container(
  //                       height: 50,
  //                       width: 130,
  //                       padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
  //                       decoration: BoxDecoration(
  //                           color: controller.isRecentSearchButton.value
  //                               ? Colors.transparent
  //                               : MyColors.white,
  //                           borderRadius: controller.isRecentSearchButton.value
  //                               ? BorderRadius.zero
  //                               : BorderRadius.circular(60.0),
  //                           border: controller.isRecentSearchButton.value
  //                               ? const Border.fromBorderSide(BorderSide.none)
  //                               : Border.all(
  //                                   color: MyColors.primaryCustom, width: 2)),
  //                       child: controller.isRecentSearchButton.value
  //                           ? Align(
  //                               alignment: Alignment.centerRight,
  //                               child: InkWell(
  //                                 onTap: () {
  //                                   setState(() {
  //                                     controller.isRecentSearchButton.value =
  //                                         !controller
  //                                             .isRecentSearchButton.value;
  //                                   });
  //                                 },
  //                                 child: const CircleAvatar(
  //                                   backgroundColor: MyColors.mainTheme,
  //                                   child: Icon(
  //                                     Icons.add,
  //                                     color: MyColors.white,
  //                                   ),
  //                                 ),
  //                               ),
  //                             )
  //                           : Padding(
  //                               padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
  //                               child: Row(
  //                                 mainAxisAlignment:
  //                                     MainAxisAlignment.spaceBetween,
  //                                 children: [
  //                                   InkWell(
  //                                     onTap: () {
  //                                       if (counter > 1) {
  //                                         setState(() {
  //                                           decrement();
  //                                         });
  //                                       } else {
  //                                         setState(() {
  //                                           controller.isRecentSearchButton
  //                                                   .value =
  //                                               !controller
  //                                                   .isRecentSearchButton.value;
  //                                         });
  //                                       }
  //                                     },
  //                                     child: CircleAvatar(
  //                                       backgroundColor: MyColors.mainTheme,
  //                                       child: (counter > 1)
  //                                           ? const Icon(
  //                                               Icons.remove,
  //                                               size: 20,
  //                                               color: MyColors.white,
  //                                             )
  //                                           : const Icon(
  //                                               Icons.delete,
  //                                               size: 20,
  //                                               color: MyColors.white,
  //                                             ),
  //                                     ),
  //                                   ),
  //                                   FittedBox(
  //                                     child: SizedBox(
  //                                       width: 35,
  //                                       child: Center(
  //                                         child: Text(
  //                                           "$counter",
  //                                           style: TextStyle(
  //                                             fontFamily: MyFont.myFont,
  //                                             fontWeight: FontWeight.normal,
  //                                             fontSize: 18,
  //                                             color: MyColors.black,
  //                                           ),
  //                                         ),
  //                                       ),
  //                                     ),
  //                                   ),
  //                                   InkWell(
  //                                     onTap: () {
  //                                       setState(() {
  //                                         increment();
  //                                       });
  //                                     },
  //                                     child: const CircleAvatar(
  //                                       backgroundColor: MyColors.mainTheme,
  //                                       child: Icon(
  //                                         Icons.add,
  //                                         size: 20,
  //                                         color: MyColors.white,
  //                                       ),
  //                                     ),
  //                                   )
  //                                 ],
  //                               ),
  //                             ),
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           );
  //         }),
  //   );
  // }
  //
  // ///For You GridView Builder
  //
  // List bookGrid = [
  //   Assets.book1,
  //   Assets.book2,
  //   Assets.book3,
  //   Assets.book4,
  //   Assets.book5,
  // ];
  //
  // forYouList() {
  //   return Padding(
  //     padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
  //     child: ListView.builder(
  //         shrinkWrap: true,
  //         itemCount: book.length,
  //         physics: const ScrollPhysics(),
  //         scrollDirection: Axis.horizontal,
  //         itemBuilder: (context, index) {
  //           return Padding(
  //             padding: const EdgeInsets.all(8),
  //             child: Stack(
  //               fit: StackFit.passthrough,
  //               alignment: Alignment.center,
  //               children: [
  //                 SizedBox(
  //                   height: 100,
  //                   width: 140,
  //                   child: ClipRRect(
  //                       borderRadius: BorderRadius.circular(10.0),
  //                       child: Image.asset(
  //                         book[index],
  //                         fit: BoxFit.fill,
  //                       )),
  //                 ),
  //                 Center(
  //                   child: Padding(
  //                     padding: const EdgeInsets.only(top: 140),
  //                     child: Container(
  //                       height: 50,
  //                       width: 130,
  //                       padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
  //                       decoration: BoxDecoration(
  //                           color: controller.isForYouButton.value
  //                               ? Colors.transparent
  //                               : MyColors.white,
  //                           borderRadius: controller.isForYouButton.value
  //                               ? BorderRadius.zero
  //                               : BorderRadius.circular(60.0),
  //                           border: controller.isForYouButton.value
  //                               ? const Border.fromBorderSide(BorderSide.none)
  //                               : Border.all(
  //                                   color: MyColors.primaryCustom, width: 2)),
  //                       child: controller.isForYouButton.value
  //                           ? Align(
  //                               alignment: Alignment.centerRight,
  //                               child: InkWell(
  //                                 onTap: () {
  //                                   setState(() {
  //                                     controller.isForYouButton.value =
  //                                         !controller.isForYouButton.value;
  //                                   });
  //                                 },
  //                                 child: const CircleAvatar(
  //                                   backgroundColor: MyColors.mainTheme,
  //                                   child: Icon(
  //                                     Icons.add,
  //                                     color: MyColors.white,
  //                                   ),
  //                                 ),
  //                               ),
  //                             )
  //                           : Padding(
  //                               padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
  //                               child: Row(
  //                                 mainAxisAlignment:
  //                                     MainAxisAlignment.spaceBetween,
  //                                 children: [
  //                                   InkWell(
  //                                     onTap: () {
  //                                       if (counter > 1) {
  //                                         setState(() {
  //                                           decrement();
  //                                         });
  //                                       } else {
  //                                         setState(() {
  //                                           controller.isForYouButton.value =
  //                                               !controller
  //                                                   .isForYouButton.value;
  //                                         });
  //                                       }
  //                                     },
  //                                     child: CircleAvatar(
  //                                       backgroundColor: MyColors.mainTheme,
  //                                       child: (counter > 1)
  //                                           ? const Icon(
  //                                               Icons.remove,
  //                                               size: 20,
  //                                               color: MyColors.white,
  //                                             )
  //                                           : const Icon(
  //                                               Icons.delete,
  //                                               size: 20,
  //                                               color: MyColors.white,
  //                                             ),
  //                                     ),
  //                                   ),
  //                                   FittedBox(
  //                                     child: SizedBox(
  //                                       width: 35,
  //                                       child: Center(
  //                                         child: Text(
  //                                           "$counter",
  //                                           style: TextStyle(
  //                                             fontFamily: MyFont.myFont,
  //                                             fontWeight: FontWeight.normal,
  //                                             fontSize: 18,
  //                                             color: MyColors.black,
  //                                           ),
  //                                         ),
  //                                       ),
  //                                     ),
  //                                   ),
  //                                   InkWell(
  //                                     onTap: () {
  //                                       setState(() {
  //                                         increment();
  //                                       });
  //                                     },
  //                                     child: const CircleAvatar(
  //                                       backgroundColor: MyColors.mainTheme,
  //                                       child: Icon(
  //                                         Icons.add,
  //                                         size: 20,
  //                                         color: MyColors.white,
  //                                       ),
  //                                     ),
  //                                   )
  //                                 ],
  //                               ),
  //                             ),
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           );
  //         }),
  //   );
  // }


  inCatGridView() {
    // return
    if ((controller.productList.value.isNotEmpty)) {
      return Expanded(
        child: Obx(() {
          return GridView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              controller:  scrollController,
              physics: const ScrollPhysics(),
              scrollDirection: Axis.vertical,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisExtent: 190,
              ),
              itemCount: controller.productList.value?.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Get.toNamed(Routes.productDetailScreen,
                        arguments: controller.productList.value?[index]);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Stack(
                      fit: StackFit.passthrough,
                      alignment: Alignment.center,
                      children: [
                        ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: (controller.productList[index].bookImage != null)
                                ? (controller
                                .productList[index].bookImage!.isNotEmpty)
                                ? Image.network(
                                '${controller.productList[index].bookImage}',
                                fit: BoxFit.fill)
                                : Image.asset(Assets.noBook)
                                : Image.asset(Assets.noBook)),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(3, 110, 3, 0),
                          child: (controller.productList[index].qtyCount == 0)
                              ? GestureDetector(
                            onTap: () async {
                              ProductModel? selectedProduct =
                              controller.productList.value[index];
                              if (savedProduct
                                  .contains(selectedProduct.bookId)) {
                                var selectedIndex = controller.cartAddedProduct
                                    .indexWhere((element) =>
                                element.bookId ==
                                    selectedProduct.bookId);

                                controller.cartAddedProduct
                                    .removeAt(selectedIndex);
                                savedProduct.remove(selectedProduct.bookId);
                              }
                              setState(() {
                                controller.cartService
                                    .addToCart(product: selectedProduct);
                                controller.updateProductCount();
                              });

                              if (selectedProduct.qtyCount != 0) {
                                bool isAlreadyAdded =
                                controller.cartAddedProduct.any((element) =>
                                element.bookId ==
                                    selectedProduct.bookId);

                                if (!isAlreadyAdded) {
                                  controller.cartAddedProduct
                                      .add(selectedProduct);
                                }
                              }
                              await PreferenceHelper.saveCartData(
                                  controller.cartAddedProduct);
                            },
                            child: const Align(
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                child: CircleAvatar(
                                  child: Icon(Icons.add),
                                ),
                              ),
                            ),
                          )
                              : Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: MyColors.white,
                                  borderRadius: BorderRadius.circular(40.0)),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 1, vertical: 5.5),
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceAround,
                                  children: [
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                        controller.productList[index];

                                        setState(() {
                                          controller.cartService.removeFromCart(
                                              product: selectedProduct);
                                          controller.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount == 0) {
                                          if (controller.cartAddedProduct.any(
                                                  (element) =>
                                              element.bookId ==
                                                  selectedProduct.bookId)) {
                                            var selectedIndex = controller
                                                .cartAddedProduct
                                                .indexWhere((element) =>
                                            element.bookId ==
                                                selectedProduct.bookId);

                                            controller.cartAddedProduct
                                                .removeAt(selectedIndex);
                                            if (controller
                                                .cartAddedProduct.isEmpty) {
                                              controller.cartAddedProduct
                                                  .clear();
                                            }
                                          }
                                        }
                                        // bottomAppBar(index);
                                        // if (controller.productList[index].qtycount == 0) {
                                        //   controller.cartAddedProduct.length = 0;
                                        // }
                                        await PreferenceHelper.saveCartData(
                                            controller.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.remove,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    ),
                                    // Obx(() {
                                    //   return
                                    AnimatedSwitcher(
                                      duration:
                                      const Duration(milliseconds: 300),
                                      transitionBuilder: (Widget child,
                                          Animation<double> animation) {
                                        return ScaleTransition(
                                            scale: animation, child: child);
                                      },
                                      child: SizedBox(
                                        width: 20,
                                        child: Text(
                                          '${controller.productList[index].qtyCount.toInt()}',
                                          key: ValueKey<int>(
                                            controller
                                                .productList[index].qtyCount
                                                .toInt() ??
                                                0,
                                          ),
                                          style: TextStyle(
                                            fontFamily: MyFont.myFont,
                                            color: MyColors.black,
                                            fontSize: 16,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    // }),
                                    GestureDetector(
                                      onTap: () async {
                                        ProductModel? selectedProduct =
                                        controller.productList.value[index];
                                        if (savedProduct
                                            .contains(selectedProduct.bookId)) {
                                          var selectedIndex = controller
                                              .cartAddedProduct
                                              .indexWhere((element) =>
                                          element.bookId ==
                                              selectedProduct.bookId);

                                          controller.cartAddedProduct
                                              .removeAt(selectedIndex);
                                          savedProduct
                                              .remove(selectedProduct.bookId);
                                        }
                                        setState(() {
                                          controller.cartService.addToCart(
                                              product: selectedProduct);
                                          controller.updateProductCount();
                                        });

                                        if (selectedProduct.qtyCount != 0) {
                                          bool isAlreadyAdded = controller
                                              .cartAddedProduct
                                              .any((element) =>
                                          element.bookId ==
                                              selectedProduct.bookId);

                                          if (!isAlreadyAdded) {
                                            controller.cartAddedProduct
                                                .add(selectedProduct);
                                          }
                                        }
                                        await PreferenceHelper.saveCartData(
                                            controller.cartAddedProduct);
                                      },
                                      child: const CircleAvatar(
                                        child: Icon(
                                          Icons.add,
                                          color: MyColors.white,
                                          size: 18,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              });
        }),
      );
    } else if (controller.status.isLoadingMore || controller.status.isLoading) {
      return Center(
          child: CircularProgressIndicator(color: MyColors.mainTheme)
      );
    } else {
      return Center(
        child: Image.asset(Assets.noImage),
      );
    }
  }

  ///APPBAR DESIGN
  buildAppBarCartButton() {
    return Obx(() {
      return GestureDetector(
        onTap: () async {
          if (controller.cartAddedProduct.isNotEmpty) {
            Get.toNamed(Routes.addToCartScreen,
                arguments: controller.cartAddedProduct)
                ?.then((value) {
              if (value == true) {
                initData();
              }
            });
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                margin: EdgeInsets.all(10),
                borderRadius: 10,
                backgroundColor: Colors.red,
                snackPosition: SnackPosition.TOP,
                message: "Please select atleast one product",
                icon: Icon(
                  Icons.error,
                  color: Colors.white,
                ),
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.only(right: 11.0),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(right: 11.0),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  color: MyColors.primaryCustom,
                  size: 30,
                ),
              ),
              if (controller.cartAddedProduct.isNotEmpty)
                Positioned(
                  top: 10,
                  right: 5,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: MyColors.white,
                        border: Border.all(color: Colors.white, width: 1)),
                    child: Center(
                      child: Text(
                        controller.cartAddedProduct.length.toString(),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: MyColors.primaryCustom,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }

}
