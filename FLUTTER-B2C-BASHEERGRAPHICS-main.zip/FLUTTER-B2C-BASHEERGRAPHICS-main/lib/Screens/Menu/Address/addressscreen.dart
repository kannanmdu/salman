import 'dart:ffi';

import 'package:book/Const/size.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import 'addresscontroller.dart';

class AddressListScreen extends StatefulWidget {
  const AddressListScreen({super.key});

  @override
  State<AddressListScreen> createState() => _AddressListScreenState();
}

class _AddressListScreenState extends State<AddressListScreen> {
  late AddressController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(AddressController());
    controller.getAddress();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddressController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Location",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Get.toNamed(Routes.addNewAddressScreen);
                },
                icon: const Icon(Icons.add))
          ],
        ),
        body: (controller.addressList.value != null)
            ? SingleChildScrollView(
                padding: const EdgeInsets.all(18.0),
                child: Column(
                  children: [
                    addressListView(),
                  ],
                ))
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      Assets.noImage,
                      scale: 2,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "No Address Here",
                      style: TextStyle(
                        fontSize: 16,
                        color: MyColors.white,
                      ),
                    )
                  ],
                ),
              ),
      );
    });
  }

  ///ADDRESS LIST VIEW BUILDER

  addressListView() {
    return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.addressList.value?.length,
        itemBuilder: (context, index) {
          String? address =
              " ${controller.addressList.value?[index].addressLine1}, "
              " ${controller.addressList.value?[index].addressLine2}, "
              " ${controller.addressList.value?[index].addressLine3}, "
              " ${controller.addressList.value?[index].floorNo}, "
              "${controller.addressList.value?[index].unitNo}";

          return Card(
            color: MyColors.bars,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        Assets.address,
                        scale: 3,
                      ),
                      const SizedBox(width: 20),
                      SizedBox(
                        width: width(context) / 1.7,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Home",
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              address,
                              textAlign: TextAlign.start,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: MyFont.myFont,
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: MyColors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Image.asset(
                      Assets.edit,
                      scale: 3,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
