import 'package:book/Widget/submitbutton.dart';
import 'package:book/Widget/textformfield.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import '../../../Helper/api.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/AddressModel.dart';
import '../../../ModelClass/B2CCustomerLogin.dart';
import 'addresscontroller.dart';

class AddNewAddressScreen extends StatefulWidget {
  const AddNewAddressScreen({super.key});

  @override
  State<AddNewAddressScreen> createState() => _AddNewAddressScreenState();
}

class _AddNewAddressScreenState extends State<AddNewAddressScreen> {
  late AddressController controller;

  B2cLoginModel? loginUser = B2cLoginModel();

  initialiseData() async {
    loginUser = await PreferenceHelper.getUserData();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialiseData();
    controller = Get.put(AddressController());
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.addAddressKey,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Add New Address",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(18.0),
          child: Column(
            children: [
              CustomTextFormField(
                controller: controller.addressTypeController,
                hintText: "Address Type",
                inputFormatters: [],
                // validator: (value) {
                //   if (value!.isEmpty || value == null) {
                //     return "Enter Address Type";
                //   } else {
                //     return null;
                //   }
                // },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.addressLine1Controller,
                hintText: "Address Line 1",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Address Line 1";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.addressLine2Controller,
                hintText: "Address Line 2",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Address Line 2";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.addressLine3Controller,
                hintText: "Address Line 3",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Address Line 3";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.postalCodeController,
                hintText: "Postal Code",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Postal Code";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.floorNoController,
                hintText: "Floor No",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Floor No";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
              CustomTextFormField(
                controller: controller.unitController,
                hintText: "Unit No",
                inputFormatters: [],
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Enter Unit No";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: SubmitButton(
            isLoading: false,
            onTap: () async {
              if (controller.addAddressKey.currentState!.validate()) {
                print("Success");

                controller.createAddress = AddressModel(
                  orgId: HttpUrl.org,
                  customerId: loginUser?.b2CCustomerId ?? "",
                  deliveryId: 1,
                  fax: "",
                  isDefault: true,
                  mobile: controller.loginUser?.mobileNo ?? "",
                  name: loginUser?.b2CCustomerName,
                  phone: loginUser?.mobileNo ?? "",
                  addressLine1: controller.addressLine1Controller.text,
                  addressLine2: controller.addressLine2Controller.text,
                  addressLine3: controller.addressLine3Controller.text,
                  floorNo: controller.floorNoController.text,
                  unitNo: controller.unitController.text,
                  countryId: "",
                  postalCode: controller.postalCodeController.text,
                  isActive: controller.createAddress?.isActive ?? true,
                  createdBy: "Admin",
                  createdOn: "2024-02-09T05:19:15.162Z",
                  changedBy: loginUser?.b2CCustomerName ?? "",
                  changedOn: "2024-02-09T05:19:15.162Z",
                );
                await controller.postAddress();
                // clear();
              }
            },
            title: "Submit",
          ),
        ),
      ),
    );
  }
}
