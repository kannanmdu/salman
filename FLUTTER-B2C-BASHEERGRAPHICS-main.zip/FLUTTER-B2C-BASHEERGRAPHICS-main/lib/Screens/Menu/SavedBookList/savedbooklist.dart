import 'package:book/Screens/Menu/SavedBookList/savedbooklistcontroller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';

class SavedBookListScreen extends StatefulWidget {
  const SavedBookListScreen({super.key});

  @override
  State<SavedBookListScreen> createState() => _SavedBookListScreenState();
}

class _SavedBookListScreenState extends State<SavedBookListScreen> {
  late SavedBookListController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(SavedBookListController());
    controller.productWishListGetByCustomer();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SavedBookListController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          backgroundColor: MyColors.bars,
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Saved Books",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: SingleChildScrollView(
          physics: const ScrollPhysics(),
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              bestSellerList(),
            ],
          ),
        ),
      );
    });
  }

  ///SAVED BOOKS
  List bestSellerBook = [
    Assets.book2,
    Assets.book1,
    Assets.book3,
    Assets.book4,
    Assets.book5,
  ];

  List bookNames = [
    "The Subtle art of not giving a fuck",
    "Atomic Habits",
    "How to Talk to anyone",
    "Change by Design",
    "Happiness by Design",
  ];

  List bookAuthor = [
    "Mark Manson",
    "James Clear",
    "Leil Lowndes",
    "Tim Brown",
    "Paul Dahn",
  ];

  bestSellerList() {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: controller.productWishList.length,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          String? bookId = controller.productWishList[index].productCode;
          return Card(
            color: MyColors.bars,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 150,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Image.asset(
                          Assets.book1,
                          fit: BoxFit.fill,
                        )),
                  ),
                  const SizedBox(width: 20),
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          controller.productWishList[index].productName ?? "",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: MyFont.myFont,
                            fontWeight: FontWeight.normal,
                            fontSize: 16,
                            color: MyColors.white,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "Book Author",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: MyFont.myFont,
                            fontWeight: FontWeight.normal,
                            fontSize: 16,
                            color: MyColors.primaryCustom,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "\$30.00",
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: MyFont.myFont,
                            fontWeight: FontWeight.normal,
                            fontSize: 16,
                            color: MyColors.white,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: MyColors.brown,
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(20.0))),
                              onPressed: () {},
                              child: Text(
                                "View",
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: MyFont.myFont,
                                  fontWeight: FontWeight.bold,
                                  color: MyColors.lightBrown,
                                ),
                              ),
                            ),
                            const SizedBox(width: 20),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: MyColors.brown,
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(20.0))),
                              onPressed: () {},
                              child: Text(
                                "Add",
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: MyFont.myFont,
                                  fontWeight: FontWeight.bold,
                                  color: MyColors.lightBrown,
                                ),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  IconButton(
                      onPressed: () {
                        // print(";;;;;;;;;;$bookId");
                        controller.unFavProduct(bookId);
                      },
                      icon: const Icon(
                        Icons.clear,
                        color: MyColors.white,
                      ))
                ],
              ),
            ),
          );
        });
  }
}
