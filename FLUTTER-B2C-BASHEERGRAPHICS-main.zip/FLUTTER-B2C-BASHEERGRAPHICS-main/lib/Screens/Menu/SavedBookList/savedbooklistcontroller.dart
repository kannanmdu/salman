import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Helper/NetworkManger.dart';
import '../../../Helper/api.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/WishListModel.dart';

class SavedBookListController extends GetxController with StateMixin {
  RxBool isLoading = false.obs;

  RxBool isFav = false.obs;

  RxList<WishListModel> productWishList = <WishListModel>[].obs;

  Future<void> productWishListGetByCustomer() async {
    isLoading.value = true;
    change(null, status: RxStatus.loading());

    await NetworkManager.get(
      url: HttpUrl.productWishListGetByCustomer,
      parameters: {
        "OrganizationId": HttpUrl.org,
        "CustomerId": await PreferenceHelper.getUserData()
            .then((value) => value?.b2CCustomerId),
      },
    ).then((response) {
      isLoading.value = false;
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            List<WishListModel> list;
            list = resJson.map<WishListModel>((value) {
              return WishListModel.fromJson(value);
            }).toList();
            productWishList.value = list;
            change(null, status: RxStatus.success());
          } else {
            print("productList.length");
            print(productWishList.length);
            change(null, status: RxStatus.error());
          }
        } else {
          change(null, status: RxStatus.error());
          String? message = response.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      String? message = error.toString();
      Get.showSnackbar(PreferenceHelper.getShowSnackBar(
          context: Get.context!, msg: message));
    });
  }

  unFavProduct(String? bookId) async {
    isLoading.value = true;
    print("llllllllll$bookId");
    NetworkManager.get(
        url: HttpUrl.b2CCustomerUnFavCreateWishList,
        parameters: {
          "OrganizationId": HttpUrl.org,
          "CustomerId": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerId),
          "ProductCode": bookId,
          "UserName": await PreferenceHelper.getUserData()
              .then((value) => value?.b2CCustomerName),
        }).then((response) {
      isLoading.value = false;
      change(null, status: RxStatus.success());
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          change(null, status: RxStatus.success());
          isFav.value = false;
          // productWishList.clear();
          PreferenceHelper.getShowSnackBar(msg: "Removed From Saved List");
          change(null, status: RxStatus.success());
        }
      } else {
        change(null, status: RxStatus.error());
        String message = response.apiResponseModel?.message ?? "";
        PreferenceHelper.getShowSnackBar(msg: message);
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      String message = error.toString();
      PreferenceHelper.getShowSnackBar(msg: message);
    });
  }
}
