import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import 'orderlistcontroller.dart';

class OrderListScreen extends StatefulWidget {
  const OrderListScreen({super.key});

  @override
  State<OrderListScreen> createState() => _OrderListScreenState();
}

class _OrderListScreenState extends State<OrderListScreen> {
  late OrderListController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(OrderListController());
    controller.getOrderList();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<OrderListController>(builder: (logic) {
      if (logic.isLoading.value == true) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      }

      return Scaffold(
        appBar: AppBar(
          backgroundColor: MyColors.bars,
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Order List",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: controller.ordersModelList.value != null
            ? SingleChildScrollView(
                padding: const EdgeInsets.all(18.0),
                child: Column(
                  children: [
                    bestSellerList(),
                  ],
                ),
              )
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(Assets.noImage),
                    const SizedBox(height: 10),
                    const Text(
                      "Your Order List is Empty",
                      style: TextStyle(
                        fontSize: 16,
                        color: MyColors.white,
                      ),
                    )
                  ],
                ),
              ),
      );
    });
  }

  bestSellerList() {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: controller.ordersModelList.value?.length,
        physics: const ScrollPhysics(),
        itemBuilder: (context, index) {
          DateTime dateTime = DateFormat("yyyy-MM-dd").parse(
              controller.ordersModelList.value?[index].orderDate.toString() ??
                  "");
          String orderDate = DateFormat("dd-MM-yyyy").format(dateTime);
          return Card(
            color: MyColors.bars,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: Padding(
              padding: const EdgeInsets.all(18.0),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      "Date : ",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontFamily: MyFont.myFont,
                                        fontWeight: FontWeight.normal,
                                        fontSize: 16,
                                        color: MyColors.primaryCustom,
                                      ),
                                    ),
                                    Text(
                                      orderDate,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontFamily: MyFont.myFont,
                                        fontWeight: FontWeight.normal,
                                        fontSize: 16,
                                        color: MyColors.white,
                                      ),
                                    ),
                                  ],
                                ),
                                IconButton(
                                    onPressed: () {
                                      Get.toNamed(Routes.orderDetailScreen,
                                          arguments: controller.ordersModelList
                                              .value?[index].orderNo);
                                    },
                                    icon: const Icon(
                                      Icons.arrow_forward_ios,
                                      color: MyColors.white,
                                      size: 18,
                                    ))
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Text(
                                  "Order Id : ",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 16,
                                    color: MyColors.primaryCustom,
                                  ),
                                ),
                                Text(
                                  controller.ordersModelList.value?[index]
                                          .orderNo ??
                                      "",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: MyFont.myFont,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 16,
                                    color: MyColors.white,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Text(
                                    "Total Amount",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 16,
                                      color: MyColors.primaryCustom,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 50),
                                Flexible(
                                  child: Text(
                                    "\$  ${controller.ordersModelList.value?[index].netTotal.toString()}" ??
                                        "",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontFamily: MyFont.myFont,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 16,
                                      color: MyColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }

  ///TABBAR
  // DefaultTabController(
  // length: 4,
  // initialIndex: 1,
  // child: Scaffold(
  // appBar: AppBar(
  // backgroundColor: MyColors.bars,
  // elevation: 0,
  // leading: IconButton(
  // onPressed: () {
  // Get.back();
  // },
  // icon: Image.asset(
  // Assets.arrow,
  // scale: 4,
  // ),
  // ),
  // title: Text(
  // "Order List",
  // style: TextStyle(
  // fontFamily: MyFont.myFont,
  // fontWeight: FontWeight.bold,
  // ),
  // ),
  // bottom: TabBar(
  // labelColor: MyColors.mainTheme,
  // isScrollable: true,
  // tabs: tabs,
  // unselectedLabelColor: MyColors.grey,
  // indicator: const BoxDecoration(color: Colors.transparent),
  // ),
  // ),
  // body: TabBarView(children: [
  // bestSellerList(),
  // bestSellerList(),
  // bestSellerList(),
  // bestSellerList(),
  // ]),
  // ),
  // );

// //TabScreens
// List<Tab> tabs = [
//   Tab(
//     child: Text(
//       'All',
//       style: TextStyle(
//         fontFamily: MyFont.myFont,
//         fontSize: 15,
//       ),
//     ),
//   ),
//   Tab(
//     child: Text(
//       'Wait for payment',
//       style: TextStyle(
//         fontFamily: MyFont.myFont,
//         fontSize: 15,
//       ),
//     ),
//   ),
//   Tab(
//     child: Text(
//       'Processing',
//       style: TextStyle(
//         fontFamily: MyFont.myFont,
//         fontSize: 15,
//       ),
//     ),
//   ),
//   Tab(
//     child: Text(
//       'Shipping',
//       style: TextStyle(
//         fontFamily: MyFont.myFont,
//         fontSize: 15,
//       ),
//     ),
//   ),
// ];
}
