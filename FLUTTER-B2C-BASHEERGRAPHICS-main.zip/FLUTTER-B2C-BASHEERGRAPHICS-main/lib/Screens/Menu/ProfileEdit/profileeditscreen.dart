import 'package:book/Helper/preferencehelper.dart';
import 'package:book/ModelClass/B2CCustomerCreate.dart';
import 'package:book/ModelClass/B2CCustomerLogin.dart';
import 'package:book/Screens/Menu/ProfileEdit/profileeditcontroller.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:book/Widget/textformfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';

class ProfileEditScreen extends StatefulWidget {
  const ProfileEditScreen({super.key});

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  late ProfileEditController controller;

  String? b2cCustomerId;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserData();
    controller = Get.put(ProfileEditController());
  }

  void getUserData() async {
    await PreferenceHelper.getUserData().then((value) => setState(() {
          b2cCustomerId = "${value?.b2CCustomerId}";
          controller.nameController.text = "${value?.b2CCustomerName}";
          controller.phoneController.text = "${value?.mobileNo}";
          controller.emailController.text = "${value?.emailId}";
        }));
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.updateProfileKey,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: MyColors.bars,
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Edit Profile",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Name",
                  style: TextStyle(
                    color: MyColors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                CustomTextFormField(
                  controller: controller.nameController,
                  inputFormatters: [],
                  hintText: "Name",
                  validator: (value) {
                    if (value!.isEmpty || value == null) {
                      return "Please Enter Name";
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(height: 20),
                const Text(
                  "Mobile No",
                  style: TextStyle(
                    color: MyColors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                CustomTextFormField(
                  controller: controller.phoneController,
                  inputFormatters: [],
                  hintText: "Mobile No",
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty || value == null) {
                      return "Please Enter Mobile Number";
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(height: 20),
                const Text(
                  "Email",
                  style: TextStyle(
                    color: MyColors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                CustomTextFormField(
                  controller: controller.emailController,
                  readOnly: true,
                  inputFormatters: [],
                  hintText: "Email",
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: SubmitButton(
              isLoading: false,
              onTap: () {
                if (controller.updateProfileKey.currentState!.validate()) {
                  print('....$b2cCustomerId........');
                  controller.updateProfile(b2cCustomerId);
                }
              },
              title: "Update"),
        ),
      ),
    );
  }
}
