import 'package:book/ModelClass/B2CCustomerCreate.dart';
import 'package:book/ModelClass/B2CCustomerLogin.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import '../../../Helper/NetworkManger.dart';
import '../../../Helper/api.dart';
import '../../../Helper/preferencehelper.dart';
import '../../../ModelClass/B2CCustomerEditModel.dart';

class ProfileEditController extends GetxController with StateMixin {
  RxBool isLoading = false.obs;

  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  final updateProfileKey = GlobalKey<FormState>();

  late B2cCustomerEditModel b2cCustomerEditModel;

  updateProfile(String? b2cCustomerId) async {
    print("Enter........Enter");
    isLoading.value = true;
    NetworkManager.post(URl: HttpUrl.editProfile, params: {
      "orgId": HttpUrl.org,
      "b2CCustomerId": b2cCustomerId,
      "b2CCustomerName": nameController.text,
      "addressLine1": "",
      "addressLine2": "",
      "addressLine3": "",
      "countryId": "",
      "postalCode": "",
      "mobileNo": phoneController.text,
      "changedBy": "Admin",
      "changedOn": "2024-01-25T07:31:24.101Z",
    }).then((apiResponse) async {
      isLoading.value = false;
      if (apiResponse.apiResponseModel != null) {
        if (apiResponse.apiResponseModel!.status) {
          print(apiResponse.apiResponseModel!.status);
          showPopup();
        } else {
          String? message = apiResponse.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      } else {
        PreferenceHelper.getShowSnackBar(
            context: Get.context!, msg: apiResponse.error);
      }
    });
  }

  showPopup() {
    showDialog(
      context: Get.context!,
      builder: (BuildContext context) {
        return AlertDialog(
          iconPadding: EdgeInsets.zero,
          backgroundColor: MyColors.bars,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
          title: Text(
            "Profile Updated \nSuccessfully",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
              color: MyColors.white,
            ),
          ),
          icon: SizedBox(
            height: 150.0,
            child: Image.asset(
              Assets.successfully,
              scale: 3,
            ),
          ),
        );
      },
    );
    Future.delayed(const Duration(seconds: 3), () {
      Get.offAllNamed(Routes.loginScreen);
    });
  }
}
