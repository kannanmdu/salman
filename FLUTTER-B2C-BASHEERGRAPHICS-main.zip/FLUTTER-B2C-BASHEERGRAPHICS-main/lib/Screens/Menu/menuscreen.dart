import 'dart:ui';

import 'package:book/Const/fonts.dart';
import 'package:book/Widget/submitbutton.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Helper/preferencehelper.dart';
import '../../Widget/constructor.dart';
import 'Address/addressscreen.dart';
import 'ChangePassword/changepassword.dart';
import 'OrederList/orderlistscreen.dart';
import 'ProfileEdit/profileeditcontroller.dart';
import 'SavedBookList/savedbooklist.dart';
import 'SuggestBook/suggestbook.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  String? userName;
  String? mobileNumber;
  String? emailId;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserData();
  }

  void getUserData() async {
    await PreferenceHelper.getUserData().then((value) => setState(() {
          userName = "${value?.b2CCustomerName}";
          mobileNumber = "${value?.mobileNo}";
          emailId = "${value?.emailId}";
        }));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: MyColors.bars,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Get.offAllNamed(Routes.bottomNavBar);
          },
          icon: Image.asset(
            Assets.arrow,
            scale: 4,
          ),
        ),
        title: Text(
          "Menu",
          style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
              color: MyColors.mainTheme),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Image.asset(
              Assets.notification,
              scale: 3.5,
            ),
          ),
          IconButton(
            onPressed: () async {
              await PreferenceHelper.clearUserData()
                  .then((value) => Get.offAllNamed(Routes.loginScreen));
            },
            icon: const Icon(
              Icons.logout,
              color: MyColors.primaryCustom,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const ScrollPhysics(),
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        userName ?? "User",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: MyColors.white,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        mobileNumber ?? "Mobile Number",
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          color: MyColors.grey,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        emailId ?? "",
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: MyFont.myFont,
                          fontWeight: FontWeight.bold,
                          color: MyColors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                    onPressed: () {
                      Get.toNamed(Routes.profileEditScreen);
                    },
                    icon: Image.asset(Assets.edit))
              ],
            ),
            const SizedBox(height: 20),
            menuGridView(),
          ],
        ),
      ),
    );
  }

  ///MENUGRIDVIEWBUILDER
  List<MenuGrid> menuGrid = [
    MenuGrid(
        headText: 'Your Order List',
        text: 'Click to see your recent order list.',
        icon: Assets.cart1,
        color: MyColors.lightPurple,
        textColor: MyColors.darkPurple),
    MenuGrid(
        headText: 'Your Saved Books List',
        text: 'Click to see your saved books list.',
        icon: Assets.cart2,
        color: MyColors.lightGreen,
        textColor: MyColors.darkGreen),
    MenuGrid(
      headText: 'Your Default Address',
      text: 'Click to change your current location.',
      icon: Assets.cart3,
      color: MyColors.lightOrange,
      textColor: MyColors.darkOrange,
    ),
    // MenuGrid(
    //   headText: 'Suggest Books',
    //   text: 'Some short description of this type of report.',
    //   icon: Assets.cart4,
    //   color: MyColors.lightPink,
    //   textColor: MyColors.pink,
    // ),
    MenuGrid(
      headText: 'Change Password',
      text: 'Click to Change the Password',
      icon: Assets.cart4,
      color: MyColors.lightPink,
      textColor: MyColors.pink,
    ),
  ];

  List cardNav() => [
        const OrderListScreen(),
        const SavedBookListScreen(),
        const AddressListScreen(),
        // const SuggestBookScreen(),
        const ChangePasswordScreen(),
      ];

  menuGridView() {
    return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: menuGrid.length,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Get.to(cardNav()[index]);
            },
            child: Card(
              color: menuGrid[index].color,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)),
              child: Padding(
                padding: const EdgeInsets.all(18.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 30,
                      child: Image.asset(
                        menuGrid[index].icon,
                        scale: 2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      menuGrid[index].headText,
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        color: menuGrid[index].textColor,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      menuGrid[index].text,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        color: menuGrid[index].textColor,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
}
