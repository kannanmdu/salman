import 'package:book/Widget/submitbutton.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Const/approute.dart';
import '../../../Const/assets.dart';
import '../../../Const/color.dart';
import '../../../Const/fonts.dart';
import '../../../Widget/textformfield.dart';
import 'changepasswordcontroller.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  late ChangePasswordController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(ChangePasswordController());
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.changePasswordKey,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: MyColors.bars,
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Image.asset(
              Assets.arrow,
              scale: 4,
            ),
          ),
          title: Text(
            "Change Password",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Current Password",
                style: TextStyle(
                  color: MyColors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              CustomTextFormField(
                controller: controller.currentPasswordController,
                inputFormatters: [],
                hintText: "Current Password",
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Please Enter Current Password";
                  } else {
                    return null;
                  }
                },
                obscureText: controller.curPassVis.value ? false : true,
                suffixIcon: IconButton(
                  onPressed: () {
                    setState(() {
                      controller.curPassVis.value =
                          !controller.curPassVis.value;
                    });
                  },
                  icon: Icon(controller.curPassVis.value
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "New Password",
                style: TextStyle(
                  color: MyColors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              CustomTextFormField(
                controller: controller.newPasswordController,
                inputFormatters: [],
                hintText: "New Password",
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Please Enter New Password";
                  } else if (controller.currentPasswordController.text ==
                      controller.newPasswordController.text) {
                    return "New Password & Current Password are same";
                  } else {
                    return null;
                  }
                },
                obscureText: controller.newPassVis.value ? false : true,
                suffixIcon: IconButton(
                  onPressed: () {
                    setState(() {
                      controller.newPassVis.value =
                          !controller.newPassVis.value;
                    });
                  },
                  icon: Icon(controller.newPassVis.value
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Confirm Password",
                style: TextStyle(
                  color: MyColors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              CustomTextFormField(
                controller: controller.confirmPasswordController,
                inputFormatters: [],
                hintText: "Confirm Password",
                validator: (value) {
                  if (value!.isEmpty || value == null) {
                    return "Please Enter Confirm Password";
                  } else if (controller.newPasswordController.text !=
                      controller.confirmPasswordController.text) {
                    return "Confirm Password Doesn't Match";
                  } else {
                    return null;
                  }
                },
                obscureText: controller.confPassVis.value ? false : true,
                suffixIcon: IconButton(
                  onPressed: () {
                    setState(() {
                      controller.confPassVis.value =
                          !controller.confPassVis.value;
                    });
                  },
                  icon: Icon(controller.confPassVis.value
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: SubmitButton(
              isLoading: false,
              onTap: () {
                if (controller.changePasswordKey.currentState!.validate()) {
                  controller.checkCurrentPassword();
                }
              },
              title: "Change Password"),
        ),
      ),
    );
  }
}
