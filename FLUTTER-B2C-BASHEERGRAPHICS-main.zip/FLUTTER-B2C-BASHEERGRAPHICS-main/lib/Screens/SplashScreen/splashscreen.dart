import 'package:book/Const/assets.dart';
import 'package:book/Const/color.dart';
import 'package:book/Const/fonts.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Helper/preferencehelper.dart';
import '../../ModelClass/B2CCustomerLogin.dart';
import '../../Widget/submitbutton.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3), // Adjust the duration as needed
    );

    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_controller);

    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FadeTransition(
        opacity: _animation,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                Assets.logo,
                scale: 5,
              ),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: Text(
                  "Read more and stress less with our online"
                  "\nbook shopping app. Shop from anywhere you"
                  "\nare and discover titles that you"
                  "\nlove.Happy reading!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: MyFont.myFont,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: MyColors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
            child: SubmitButton(
              isLoading: false,
              onTap: () {
                Get.toNamed(Routes.loginScreen);
              },
              title: 'Get Started',
            ),
          ),
          TextButton(
              onPressed: () {
                Get.toNamed(Routes.registrationScreen);
              },
              child: Text(
                "Register",
                style: TextStyle(
                  fontFamily: MyFont.myFont,
                ),
              ))
        ],
      ),
    );
  }
}
