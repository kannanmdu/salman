import 'dart:convert';

import 'package:book/Helper/preferencehelper.dart';
import 'package:book/Screens/Login/loginscreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Const/color.dart';
import '../../Const/fonts.dart';
import '../../Helper/NetworkManger.dart';
import '../../Helper/api.dart';
import '../../ModelClass/B2CCustomerCreate.dart';

class RegistrationController extends GetxController with StateMixin {
  final regKey = GlobalKey<FormState>();

  RxBool isVisible = false.obs;
  RxBool isLoading = false.obs;
  RxBool sendOtpLoading = false.obs;

  RxBool isVerify = false.obs;

  String? otpValue;

  String? otp;

  B2cCustomerRegModel? b2cCustomerRegModel;

  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController addressLine1Controller = TextEditingController();
  TextEditingController addressLine2Controller = TextEditingController();
  TextEditingController addressLine3Controller = TextEditingController();
  TextEditingController unitController = TextEditingController();
  TextEditingController floorController = TextEditingController();
  TextEditingController postalCodeController = TextEditingController();

  final pinController = TextEditingController();

  String currentDate = DateTime.now().toString();

  exitingEmailCheck() async {
    isLoading.value = true;
    change(null, status: RxStatus.loading());
    NetworkManager.get(url: HttpUrl.exitingEmailRegister, parameters: {
      "OrganizationId": "${HttpUrl.org}",
      "EmailId": emailController.text
    }).then((response) {
      change(null, status: RxStatus.success());
      if (response.apiResponseModel != null &&
          response.apiResponseModel!.status) {
        if (response.apiResponseModel!.data != null) {
          List? resJson = response.apiResponseModel!.data!;
          if (resJson != null) {
            if (response.apiResponseModel!.data![0]['B2CCustomerId'] == null) {
              // onRegister();
              sendOTP(true);
            } else {
              PreferenceHelper.getShowSnackBar(msg: "Email Already Exist");
            }
            change(null, status: RxStatus.success());
            return;
          }
        }
      }
    }).catchError((error) {
      change(null, status: RxStatus.error());
      Get.showSnackbar(
        GetSnackBar(
          title: "Error",
          message: error.toString(),
          icon: const Icon(Icons.error),
          duration: const Duration(seconds: 3),
        ),
      );
    });
  }

  sendOTP(bool isResend) async {
    sendOtpLoading.value = true;
    final String url =
        "${HttpUrl.base}/SendOTP/SendOTP?OrganizationId=${HttpUrl.org}&Email=${emailController.text}";
    final response = await http.post(Uri.parse(url));
    sendOtpLoading.value = false;
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      otpValue = data['Data'];
      print('POST request successful${otpValue}');
      print('Response data: ${data['Data']}');

      if (isResend) {
        sendOtpLoading.value = false;
        Get.toNamed(Routes.oTPScreen);
      }
      // You can parse and handle the response here
    } else {
      print('POST request failed with status code: ${response.statusCode}');
      print('Response data: ${response.body}');
      // Handle errors and error responses here
    }
  }

  verifyOtp(BuildContext context) async {
    isVerify.value = true;
    change(null, status: RxStatus.loading());
    NetworkManager.post(URl: HttpUrl.verifyOtp, params: {
      "OrgId": HttpUrl.org,
      "Email": emailController.text,
      "OTP": otp,
    }).then((apiResponse) async {
      isVerify.value = false;
      if (apiResponse.apiResponseModel != null &&
          apiResponse.apiResponseModel!.status) {
        isVerify.value = true;
        onRegister();
        change(null, status: RxStatus.success());
      } else {
        change(null, status: RxStatus.error());
        String? message = apiResponse.apiResponseModel?.message.toString();
        PreferenceHelper.getShowSnackBar(msg: message);
      }
    });
  }

  onRegister() async {
    print("Enter........Enter");
    isLoading.value = true;
    NetworkManager.post(URl: HttpUrl.createCustomerRegister, params: {
      "orgId": HttpUrl.org,
      "branchCode": "HO",
      "b2CCustomerId": "",
      "b2CCustomerName": firstNameController.text,
      "emailId": emailController.text,
      "password": passController.text,
      "addressLine1": addressLine1Controller.text,
      "addressLine2": addressLine2Controller.text,
      "addressLine3": addressLine3Controller.text,
      "floorNo": floorController.text,
      "unitNo": unitController.text,
      "mobileNo": mobileNumberController.text,
      "countryId": "",
      "postalCode": postalCodeController.text,
      "isActive": b2cCustomerRegModel?.isActive ?? true,
      "isApproved": b2cCustomerRegModel?.isApproved ?? true,
      "createdBy": firstNameController.text,
      "createdOn": currentDate,
      "changedBy": "Admin",
      "changedOn": "2024-01-25T07:31:24.101Z",
      "orders": [],
      "address": []
    }).then((apiResponse) async {
      isLoading.value = false;
      if (apiResponse.apiResponseModel != null) {
        if (apiResponse.apiResponseModel!.status) {
          print(apiResponse.apiResponseModel!.status);
          showPopup();
        } else {
          String? message = apiResponse.apiResponseModel?.message;
          PreferenceHelper.getShowSnackBar(context: Get.context!, msg: message);
        }
      } else {
        PreferenceHelper.getShowSnackBar(
            context: Get.context!, msg: apiResponse.error);
      }
    });
  }

  showPopup() {
    showDialog(
      context: Get.context!,
      builder: (BuildContext context) {
        return AlertDialog(
          iconPadding: EdgeInsets.zero,
          backgroundColor: MyColors.bars,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
          title: Text(
            "Account Registered \nSuccessfully",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              fontWeight: FontWeight.bold,
              color: MyColors.white,
            ),
          ),
          icon: SizedBox(
            height: 150.0,
            child: Image.asset(
              Assets.successfully,
              scale: 3,
            ),
          ),
        );
      },
    );
    Future.delayed(const Duration(seconds: 3), () {
      Get.offAllNamed(Routes.loginScreen);
    });
  }
}
