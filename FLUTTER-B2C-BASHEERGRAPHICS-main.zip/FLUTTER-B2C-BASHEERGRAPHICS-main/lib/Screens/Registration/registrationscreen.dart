import 'package:book/Const/color.dart';
import 'package:book/Const/fonts.dart';
import 'package:book/Const/size.dart';
import 'package:book/Helper/inputformator.dart';
import 'package:book/Screens/Registration/registrationcontroller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Const/approute.dart';
import '../../Const/assets.dart';
import '../../Widget/submitbutton.dart';
import '../../Widget/textformfield.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  late RegistrationController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = Get.put(RegistrationController());
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.regKey,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: MyColors.bars,
          automaticallyImplyLeading: false,
          // leading: IconButton(
          //   onPressed: () {
          //     Get.back();
          //   },
          //   icon: Image.asset(
          //     Assets.arrow,
          //     scale: 4,
          //   ),
          // ),
          title: Text(
            "Registration",
            style: TextStyle(
              fontFamily: MyFont.myFont,
              color: MyColors.white,
            ),
          ),
        ),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.firstNameController,
                    inputFormatters: [],
                    hintText: "First Name",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter First Name";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.mobileNumberController,
                    inputFormatters: [],
                    keyboardType: TextInputType.number,
                    hintText: "Mobile No",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Mobile Number";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.emailController,
                    inputFormatters: [],
                    hintText: "Email",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Email";
                      } else if (!(validateEmail(value))) {
                        return "Invalid Email";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.passController,
                    inputFormatters: [],
                    hintText: "Password must contains 6 letters",
                    obscureText: controller.isVisible.value ? false : true,
                    suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            controller.isVisible.value =
                                !controller.isVisible.value;
                          });
                        },
                        icon: Icon(
                          controller.isVisible.value
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: MyColors.primaryCustom,
                        )),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Mobile Number";
                      } else if (value.length < 6) {
                        return "Password must contains 6 letters";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: width(context) / 2.5,
                        child: CustomTextFormField(
                          controller: controller.unitController,
                          inputFormatters: [],
                          hintText: "Unit No",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "Please Enter Unit No";
                            } else {
                              return null;
                            }
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: width(context) / 2.5,
                        child: CustomTextFormField(
                          controller: controller.floorController,
                          inputFormatters: [],
                          hintText: "Floor No",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "Please Enter Floor No";
                            } else {
                              return null;
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.addressLine1Controller,
                    inputFormatters: [],
                    hintText: "Address Line 1",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Address";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.addressLine2Controller,
                    inputFormatters: [],
                    hintText: "Address Line 2",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Address";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.addressLine3Controller,
                    inputFormatters: [],
                    hintText: "Address Line 3",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Address";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  CustomTextFormField(
                    controller: controller.postalCodeController,
                    inputFormatters: [],
                    hintText: "Postal Code",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Please Enter Postal Code";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SubmitButton(
                  isLoading: false,
                  onTap: () {
                    ///Validate
                    if (controller.regKey.currentState!.validate()) {
                      // Get.toNamed(Routes.oTPScreen);
                      controller.exitingEmailCheck();
                    }
                    // Get.toNamed(Routes.oTPScreen);
                  },
                  title: "Continue"),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Get.offAllNamed(Routes.loginScreen);
                },
                child: RichText(
                    text: TextSpan(children: [
                  TextSpan(
                      text: "Have an Account?",
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        color: MyColors.white,
                      )),
                  const WidgetSpan(
                      child: SizedBox(
                    width: 10,
                  )),
                  TextSpan(
                      text: "LOGIN",
                      style: TextStyle(
                        fontFamily: MyFont.myFont,
                        fontWeight: FontWeight.bold,
                        color: MyColors.primaryCustom,
                      )),
                ])),
              )
            ],
          ),
        ),
      ),
    );
  }
}
