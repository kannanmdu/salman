import 'package:book/Const/color.dart';
import 'package:book/Const/fonts.dart';
import 'package:book/Screens/Category/categoryscreen.dart';
import 'package:book/Screens/DashBoard/dashboardscreen.dart';
import 'package:book/Screens/Menu/menuscreen.dart';
import 'package:book/Screens/Search/searchscreen.dart';
import 'package:flutter/material.dart';

import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';

import '../../Const/assets.dart';

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  List<Widget> tabs = [
    const DashBoardScreen(),
    const CategoryScreen(),
    const SearchScreen(),
    const MenuScreen(),
  ];

  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(
      context,
      controller: PersistentTabController(initialIndex: 0),
      screens: tabs,
      backgroundColor: MyColors.bars,
      decoration: NavBarDecoration(
        borderRadius: BorderRadius.circular(10.0),
      ),
      navBarStyle: NavBarStyle.style10,
      navBarHeight: 80,
      items: [
        PersistentBottomNavBarItem(
          icon: Image.asset(
            Assets.dashboard,
            scale: 4,
          ),
          title: 'Home',
          activeColorSecondary: MyColors.white,
          opacity: 1.0,
          activeColorPrimary: MyColors.mainTheme,
          textStyle: TextStyle(fontFamily: MyFont.myFont, fontSize: 18),
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset(
            Assets.category,
            scale: 4,
          ),
          title: 'Category',
          textStyle: TextStyle(fontFamily: MyFont.myFont, fontSize: 18),
          activeColorPrimary: MyColors.mainTheme,
          activeColorSecondary: MyColors.white,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset(
            Assets.search,
            scale: 4,
          ),
          title: 'Search',
          textStyle: TextStyle(fontFamily: MyFont.myFont, fontSize: 18),
          activeColorPrimary: MyColors.mainTheme,
          activeColorSecondary: MyColors.white,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset(
            Assets.menu,
            scale: 4,
          ),
          title: 'Menu',
          textStyle: TextStyle(fontFamily: MyFont.myFont, fontSize: 18),
          activeColorPrimary: MyColors.mainTheme,
          activeColorSecondary: MyColors.white,
        ),
      ],
    );
  }
}
