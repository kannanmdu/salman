class CategoryModel {
  CategoryModel({
    this.orgId,
    this.code,
    this.name,
    this.isActive,
    this.sortOrder,
    this.createdBy,
    this.createdOn,
    this.changedBy,
    this.changedOn,
  });

  CategoryModel.fromJson(dynamic json) {
    orgId = json['OrgId'];
    code = json['Code'];
    name = json['Name'];
    isActive = json['IsActive'];
    sortOrder = json['SortOrder'];
    createdBy = json['CreatedBy'];
    createdOn = json['CreatedOn'];
    changedBy = json['ChangedBy'];
    changedOn = json['ChangedOn'];
  }
  int? orgId;
  String? code;
  String? name;
  bool? isActive;
  int? sortOrder;
  String? createdBy;
  String? createdOn;
  String? changedBy;
  String? changedOn;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['OrgId'] = orgId;
    map['Code'] = code;
    map['Name'] = name;
    map['IsActive'] = isActive;
    map['SortOrder'] = sortOrder;
    map['CreatedBy'] = createdBy;
    map['CreatedOn'] = createdOn;
    map['ChangedBy'] = changedBy;
    map['ChangedOn'] = changedOn;
    return map;
  }
}
