class AddressModel {
  AddressModel({
    this.orgId,
    this.deliveryId,
    this.customerId,
    this.name,
    this.addressLine1,
    this.addressLine2,
    this.addressLine3,
    this.countryId,
    this.postalCode,
    this.mobile,
    this.phone,
    this.fax,
    this.isDefault,
    this.isActive,
    this.createdBy,
    this.createdOn,
    this.changedBy,
    this.changedOn,
    this.floorNo,
    this.unitNo,
  });

  AddressModel.fromJson(dynamic json) {
    orgId = json['OrgId'];
    deliveryId = json['DeliveryId'];
    customerId = json['CustomerId'];
    name = json['Name'];
    addressLine1 = json['AddressLine1'];
    addressLine2 = json['AddressLine2'];
    addressLine3 = json['AddressLine3'];
    countryId = json['CountryId'];
    postalCode = json['PostalCode'];
    mobile = json['Mobile'];
    phone = json['Phone'];
    fax = json['Fax'];
    isDefault = json['IsDefault'];
    isActive = json['IsActive'];
    createdBy = json['CreatedBy'];
    createdOn = json['CreatedOn'];
    changedBy = json['ChangedBy'];
    changedOn = json['ChangedOn'];
    floorNo = json['FloorNo'];
    unitNo = json['UnitNo'];
  }
  int? orgId;
  int? deliveryId;
  String? customerId;
  String? name;
  String? addressLine1;
  String? addressLine2;
  String? addressLine3;
  String? countryId;
  String? postalCode;
  String? mobile;
  String? phone;
  String? fax;
  bool? isDefault;
  bool? isActive;
  String? createdBy;
  String? createdOn;
  String? changedBy;
  String? changedOn;
  String? floorNo;
  String? unitNo;

  bool? isSelected;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['OrgId'] = orgId;
    map['DeliveryId'] = deliveryId;
    map['CustomerId'] = customerId;
    map['Name'] = name;
    map['AddressLine1'] = addressLine1;
    map['AddressLine2'] = addressLine2;
    map['AddressLine3'] = addressLine3;
    map['CountryId'] = countryId;
    map['PostalCode'] = postalCode;
    map['Mobile'] = mobile;
    map['Phone'] = phone;
    map['Fax'] = fax;
    map['IsDefault'] = isDefault;
    map['IsActive'] = isActive;
    map['CreatedBy'] = createdBy;
    map['CreatedOn'] = createdOn;
    map['ChangedBy'] = changedBy;
    map['ChangedOn'] = changedOn;
    map['FloorNo'] = floorNo;
    map['UnitNo'] = unitNo;
    return map;
  }
}
