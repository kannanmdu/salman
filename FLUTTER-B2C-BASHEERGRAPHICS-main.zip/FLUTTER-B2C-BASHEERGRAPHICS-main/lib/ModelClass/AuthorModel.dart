class AuthorModel {
  AuthorModel({
      this.authorName,});

  AuthorModel.fromJson(dynamic json) {
    authorName = json['AuthorName'];
  }
  String? authorName;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['AuthorName'] = authorName;
    return map;
  }

  @override
  String toString() {
    return "$authorName";
  }
}