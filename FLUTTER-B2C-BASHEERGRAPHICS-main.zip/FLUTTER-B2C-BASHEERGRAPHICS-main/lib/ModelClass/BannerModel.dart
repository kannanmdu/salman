class BannerModel {
  BannerModel({
    this.orgId,
    this.branchCode,
    this.bannerId,
    this.title,
    this.description,
    this.additionalDesc,
    this.bannerImageFileName,
    this.bannerImageFilePath,
    this.bannerImgBase64String,
    this.banneImage,
    this.displayOrder,
    this.isActive,
    this.createdBy,
    this.createdOn,
    this.createdOnString,
    this.changedBy,
    this.changedOn,
    this.changedOnString,
  });

  BannerModel.fromJson(dynamic json) {
    orgId = json['OrgId'];
    branchCode = json['BranchCode'];
    bannerId = json['BannerId'];
    title = json['Title'];
    description = json['Description'];
    additionalDesc = json['AdditionalDesc'];
    bannerImageFileName = json['BannerImageFileName'];
    bannerImageFilePath = json['BannerImageFilePath'];
    bannerImgBase64String = json['BannerImg_Base64String'];
    banneImage = json['BanneImage'];
    displayOrder = json['DisplayOrder'];
    isActive = json['IsActive'];
    createdBy = json['CreatedBy'];
    createdOn = json['CreatedOn'];
    createdOnString = json['CreatedOnString'];
    changedBy = json['ChangedBy'];
    changedOn = json['ChangedOn'];
    changedOnString = json['ChangedOnString'];
  }
  int? orgId;
  String? branchCode;
  String? bannerId;
  String? title;
  String? description;
  String? additionalDesc;
  String? bannerImageFileName;
  String? bannerImageFilePath;
  dynamic bannerImgBase64String;
  dynamic banneImage;
  int? displayOrder;
  bool? isActive;
  String? createdBy;
  String? createdOn;
  String? createdOnString;
  String? changedBy;
  String? changedOn;
  String? changedOnString;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['OrgId'] = orgId;
    map['BranchCode'] = branchCode;
    map['BannerId'] = bannerId;
    map['Title'] = title;
    map['Description'] = description;
    map['AdditionalDesc'] = additionalDesc;
    map['BannerImageFileName'] = bannerImageFileName;
    map['BannerImageFilePath'] = bannerImageFilePath;
    map['BannerImg_Base64String'] = bannerImgBase64String;
    map['BanneImage'] = banneImage;
    map['DisplayOrder'] = displayOrder;
    map['IsActive'] = isActive;
    map['CreatedBy'] = createdBy;
    map['CreatedOn'] = createdOn;
    map['CreatedOnString'] = createdOnString;
    map['ChangedBy'] = changedBy;
    map['ChangedOn'] = changedOn;
    map['ChangedOnString'] = changedOnString;
    return map;
  }
}
