class B2cCustomerRegModel {
  B2cCustomerRegModel({
    this.orgId,
    this.branchCode,
    this.b2CCustomerId,
    this.b2CCustomerName,
    this.emailId,
    this.password,
    this.addressLine1,
    this.addressLine2,
    this.addressLine3,
    this.mobileNo,
    this.countryId,
    this.postalCode,
    this.isActive,
    this.isApproved,
    this.createdBy,
    this.createdOn,
    this.changedBy,
    this.changedOn,
    this.floorNo,
    this.unitNo,
  });

  B2cCustomerRegModel.fromJson(dynamic json) {
    orgId = json['OrgId'];
    branchCode = json['BranchCode'];
    b2CCustomerId = json['B2CCustomerId'];
    b2CCustomerName = json['B2CCustomerName'];
    emailId = json['EmailId'];
    password = json['Password'];
    addressLine1 = json['AddressLine1'];
    addressLine2 = json['AddressLine2'];
    addressLine3 = json['AddressLine3'];
    mobileNo = json['MobileNo'];
    countryId = json['CountryId'];
    postalCode = json['PostalCode'];
    isActive = json['IsActive'];
    isApproved = json['IsApproved'];
    createdBy = json['CreatedBy'];
    createdOn = json['CreatedOn'];
    changedBy = json['ChangedBy'];
    changedOn = json['ChangedOn'];
    floorNo = json['FloorNo'];
    unitNo = json['UnitNo'];
  }
  int? orgId;
  String? branchCode;
  String? b2CCustomerId;
  String? b2CCustomerName;
  String? emailId;
  String? password;
  String? addressLine1;
  String? addressLine2;
  String? addressLine3;
  String? mobileNo;
  String? countryId;
  String? postalCode;
  bool? isActive;
  bool? isApproved;
  String? createdBy;
  String? createdOn;
  String? changedBy;
  String? changedOn;
  String? floorNo;
  String? unitNo;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['OrgId'] = orgId;
    map['BranchCode'] = branchCode;
    map['B2CCustomerId'] = b2CCustomerId;
    map['B2CCustomerName'] = b2CCustomerName;
    map['EmailId'] = emailId;
    map['Password'] = password;
    map['AddressLine1'] = addressLine1;
    map['AddressLine2'] = addressLine2;
    map['AddressLine3'] = addressLine3;
    map['MobileNo'] = mobileNo;
    map['CountryId'] = countryId;
    map['PostalCode'] = postalCode;
    map['IsActive'] = isActive;
    map['IsApproved'] = isApproved;
    map['CreatedBy'] = createdBy;
    map['CreatedOn'] = createdOn;
    map['ChangedBy'] = changedBy;
    map['ChangedOn'] = changedOn;
    map['FloorNo'] = floorNo;
    map['UnitNo'] = unitNo;
    return map;
  }
}
