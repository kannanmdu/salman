class ProductModel {
  ProductModel({
    this.orgId,
    this.branchCode,
    this.uom,
    this.bookId,
    this.isbn13,
    this.isbn10,
    this.title,
    this.subTitle,
    this.authorName,
    this.detailDescription,
    this.categoryId,
    this.publisher,
    this.language,
    this.bindingType,
    this.costPrice,
    this.margin,
    this.salesPrice,
    this.length,
    this.breadth,
    this.width,
    this.height,
    this.publishDate,
    this.edition,
    this.totalPages,
    this.supplierId,
    this.createdBy,
    this.unitCost,
    this.sellingPrice,
    this.sellingPriceMargin,
    this.retailPrice,
    this.retailPriceMargin,
    this.b2CPrice,
    this.b2CPriceMargin,
    this.weight,
    this.isActive,
    this.isB2C,
    this.isPos,
    this.thickness,
    this.createdOn,
    this.changedBy,
    this.changedOn,
    this.createdOnString,
    this.changedOnString,
    this.publishDateString,
    this.bookImage,
    this.slNo,
    this.productImage,
    this.productImageURL,
    this.bookImageFilePath,
    this.bookImgBase64String,
    this.bookImg,
    this.bookImageFileName,
    this.isNetPrice,
    this.productTags,
    this.giftVoucherInfo,
  });

  ProductModel.fromJson(dynamic json, {bool forSharedPreference = false}) {
    orgId = json['OrgId'];
    branchCode = json['BranchCode'];
    uom = json['Uom'];
    bookId = json['BookId'];
    isbn13 = json['ISBN13'];
    isbn10 = json['ISBN10'];
    title = json['Title'];
    subTitle = json['SubTitle'];
    authorName = json['AuthorName'];
    detailDescription = json['DetailDescription'];
    categoryId = json['CategoryId'];
    publisher = json['Publisher'];
    language = json['Language'];
    bindingType = json['BindingType'];
    costPrice = json['CostPrice'];
    margin = json['Margin'];
    salesPrice = json['SalesPrice'];
    length = json['Length'];
    breadth = json['Breadth'];
    width = json['Width'];
    height = json['Height'];
    publishDate = json['PublishDate'];
    edition = json['Edition'];
    totalPages = json['TotalPages'];
    supplierId = json['SupplierId'];
    createdBy = json['CreatedBy'];
    unitCost = json['UnitCost'];
    sellingPrice = json['SellingPrice'];
    sellingPriceMargin = json['SellingPriceMargin'];
    retailPrice = json['RetailPrice'];
    retailPriceMargin = json['RetailPriceMargin'];
    b2CPrice = json['B2CPrice'];
    b2CPriceMargin = json['B2CPriceMargin'];
    weight = json['Weight'];
    isActive = json['IsActive'];
    isB2C = json['IsB2C'];
    isPos = json['IsPos'];
    thickness = json['Thickness'];
    createdOn = json['CreatedOn'];
    changedBy = json['ChangedBy'];
    changedOn = json['ChangedOn'];
    createdOnString = json['CreatedOnString'];
    changedOnString = json['ChangedOnString'];
    publishDateString = json['PublishDateString'];
    bookImage = json['BookImage'];
    slNo = json['SlNo'];
    productImage = json['ProductImage'];
    productImageURL = json['ProductImageURL'];
    bookImageFilePath = json['BookImageFilePath'];
    bookImgBase64String = json['BookImg_Base64String'];
    bookImg = json['BookImg'];
    bookImageFileName = json['BookImageFileName'];
    isNetPrice = json['IsNetPrice'];
    productTags = json['ProductTags'];
    giftVoucherInfo = json['GiftVoucherInfo'];
    if (forSharedPreference == true) {
      qtyCount = json['qtycount'] as int? ?? 0;
    }
  }
  int? orgId;
  String? branchCode;
  String? uom;
  String? bookId;
  String? isbn13;
  String? isbn10;
  String? title;
  String? subTitle;
  String? authorName;
  String? detailDescription;
  String? categoryId;
  String? publisher;
  String? language;
  String? bindingType;
  double? costPrice;
  double? margin;
  double? salesPrice;
  double? length;
  double? breadth;
  double? width;
  double? height;
  String? publishDate;
  int? edition;
  int? totalPages;
  String? supplierId;
  String? createdBy;
  double? unitCost;
  double? sellingPrice;
  double? sellingPriceMargin;
  double? retailPrice;
  double? retailPriceMargin;
  double? b2CPrice;
  double? b2CPriceMargin;
  dynamic weight;
  dynamic isActive;
  dynamic isB2C;
  dynamic isPos;
  double? thickness;
  String? createdOn;
  String? changedBy;
  String? changedOn;
  String? createdOnString;
  String? changedOnString;
  dynamic publishDateString;
  String? bookImage;
  String? slNo;
  String? productImage;
  String? productImageURL;
  dynamic bookImageFilePath;
  dynamic bookImgBase64String;
  dynamic bookImg;
  dynamic bookImageFileName;
  bool? isNetPrice;
  dynamic productTags;
  dynamic giftVoucherInfo;

  bool isFavourite = false;

  int qtyCount = 0;

  increment() {
    qtyCount++;
  }

  decrement() {
    if (qtyCount > 0) {
      qtyCount--;
    }
  }

  Map<String, dynamic> toJson({bool forSharedPreference = false}) {
    final map = <String, dynamic>{};
    map['OrgId'] = orgId;
    map['BranchCode'] = branchCode;
    map['Uom'] = uom;
    map['BookId'] = bookId;
    map['ISBN13'] = isbn13;
    map['ISBN10'] = isbn10;
    map['Title'] = title;
    map['SubTitle'] = subTitle;
    map['AuthorName'] = authorName;
    map['DetailDescription'] = detailDescription;
    map['CategoryId'] = categoryId;
    map['Publisher'] = publisher;
    map['Language'] = language;
    map['BindingType'] = bindingType;
    map['CostPrice'] = costPrice;
    map['Margin'] = margin;
    map['SalesPrice'] = salesPrice;
    map['Length'] = length;
    map['Breadth'] = breadth;
    map['Width'] = width;
    map['Height'] = height;
    map['PublishDate'] = publishDate;
    map['Edition'] = edition;
    map['TotalPages'] = totalPages;
    map['SupplierId'] = supplierId;
    map['CreatedBy'] = createdBy;
    map['UnitCost'] = unitCost;
    map['SellingPrice'] = sellingPrice;
    map['SellingPriceMargin'] = sellingPriceMargin;
    map['RetailPrice'] = retailPrice;
    map['RetailPriceMargin'] = retailPriceMargin;
    map['B2CPrice'] = b2CPrice;
    map['B2CPriceMargin'] = b2CPriceMargin;
    map['Weight'] = weight;
    map['IsActive'] = isActive;
    map['IsB2C'] = isB2C;
    map['IsPos'] = isPos;
    map['Thickness'] = thickness;
    map['CreatedOn'] = createdOn;
    map['ChangedBy'] = changedBy;
    map['ChangedOn'] = changedOn;
    map['CreatedOnString'] = createdOnString;
    map['ChangedOnString'] = changedOnString;
    map['PublishDateString'] = publishDateString;
    map['BookImage'] = bookImage;
    map['SlNo'] = slNo;
    map['ProductImage'] = productImage;
    map['ProductImageURL'] = productImageURL;
    map['BookImageFilePath'] = bookImageFilePath;
    map['BookImg_Base64String'] = bookImgBase64String;
    map['BookImg'] = bookImg;
    map['BookImageFileName'] = bookImageFileName;
    map['IsNetPrice'] = isNetPrice;
    map['ProductTags'] = productTags;
    map['GiftVoucherInfo'] = giftVoucherInfo;
    if (forSharedPreference == true) {
      map['qtycount'] = qtyCount;
    }
    return map;
  }
}
