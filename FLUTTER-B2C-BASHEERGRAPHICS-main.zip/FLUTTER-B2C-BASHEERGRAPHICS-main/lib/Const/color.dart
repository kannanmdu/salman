import 'package:flutter/material.dart';

class MyColors {
  static const Color mainTheme = Color.fromRGBO(0, 164, 224, 1.0);
  static const Color darkPurple = Color.fromRGBO(55, 36, 143, 1.0);
  static const Color lightPurple = Color.fromRGBO(213, 207, 241, 1.0);
  static const Color darkGreen = Color.fromRGBO(71, 150, 150, 1.0);
  static const Color green = Color.fromRGBO(28, 120, 1, 1.0);
  static const Color lightGreen = Color.fromRGBO(209, 245, 245, 1.0);
  static const Color darkOrange = Color.fromRGBO(255, 86, 72, 1.0);
  static const Color lightOrange = Color.fromRGBO(255, 233, 233, 1.0);
  static const Color pink = Color.fromRGBO(201, 63, 141, 1.0);
  static const Color lightPink = Color.fromRGBO(239, 210, 225, 1.0);
  static const Color brown = Color.fromRGBO(102, 82, 48, 1.0);
  static const Color lightBrown = Color.fromRGBO(249, 201, 117, 1.0);
  static const Color yellow = Color.fromRGBO(255, 162, 0, 1.0);
  static const Color white = Color.fromRGBO(255, 255, 255, 1.0);
  static const Color grey = Color.fromRGBO(157, 157, 157, 1.0);
  static const Color black = Color.fromRGBO(0, 0, 0, 1.0);
  static const Color blackOpacity = Color.fromRGBO(0, 0, 0, 0.8);
  static const Color blackOpacity2 =
      Color.fromRGBO(0, 0, 0, 0.7019607843137254);
  static const Color blackOpacity3 = Color.fromRGBO(0, 0, 0, 0.4);
  static const Color bars = Color.fromRGBO(21, 25, 44, 1.0);
  static const Color scaffold = Color.fromRGBO(37, 40, 54, 1.0);

  static const MaterialColor primaryCustom = MaterialColor(
    0xFF00A4E0,
    {
      50: Color.fromRGBO(0, 164, 224, 0.1),
      100: Color.fromRGBO(0, 164, 224, 0.2),
      200: Color.fromRGBO(0, 164, 224, 0.3),
      300: Color.fromRGBO(0, 164, 224, 0.4),
      400: Color.fromRGBO(0, 164, 224, 0.5),
      500: Color.fromRGBO(0, 164, 224, 0.6),
      600: Color.fromRGBO(0, 164, 224, 0.7),
      700: Color.fromRGBO(0, 164, 224, 0.8),
      800: Color.fromRGBO(0, 164, 224, 0.9),
      900: Color.fromRGBO(0, 164, 224, 1),
    },
  );
}
