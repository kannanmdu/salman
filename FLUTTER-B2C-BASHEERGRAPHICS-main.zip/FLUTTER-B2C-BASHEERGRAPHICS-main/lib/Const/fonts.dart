class MyFont {
  static String? myFont = "Manrope-Regular";
}
