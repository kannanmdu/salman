import 'package:get/get.dart';

import '../Screens/AddToCart/addtocartscreen.dart';
import '../Screens/BottomNavBar/bottonnavigationbar.dart';
import '../Screens/Category/ProductDetail/productdetailscreen.dart';
import '../Screens/Category/individualcategory/individualcategoryscreen.dart';
import '../Screens/DashBoard/bestsellerbooklistscreen.dart';
import '../Screens/DashBoard/comingsoonbooklist.dart';
import '../Screens/DashBoard/foryouscreen.dart';
import '../Screens/DashBoard/latestbooklistscreen.dart';
import '../Screens/ForgotPassword/forgotpasswordotpscreen.dart';
import '../Screens/ForgotPassword/forgotpasswordscreen.dart';
import '../Screens/ForgotPassword/newpasswordscreen.dart';
import '../Screens/GetStarted/getstartedscreen.dart';
import '../Screens/Login/loginscreen.dart';
import '../Screens/Menu/Address/addnewaddressscreen.dart';
import '../Screens/Menu/Address/addressscreen.dart';
import '../Screens/Menu/OrederList/orderdetailscreen.dart';
import '../Screens/Menu/ProfileEdit/profileeditscreen.dart';
import '../Screens/Menu/SavedBookList/savedbooklist.dart';
import '../Screens/Notification/notificationscreen.dart';
import '../Screens/Payment/paymentconfirmationscreen.dart';
import '../Screens/Payment/paymentscreen.dart';
import '../Screens/Registration/otpscreen.dart';
import '../Screens/Registration/registrationscreen.dart';
import '../Screens/Search/RecentSearch/recentsearchscreen.dart';
import '../Screens/SplashScreen/splashscreen.dart';

class Routes {
  static const String splashScreen = "/SplashScreen";
  static const String getStartedScreen = "/GetStartedScreen";
  static const String loginScreen = "/LoginScreen";
  static const String registrationScreen = "/RegistrationScreen";
  static const String oTPScreen = "/OTPScreen";
  static const String bottomNavBar = "/BottomNavBar";
  static const String forYouScreen = "/ForYouScreen";
  static const String individualCategoryScreen = "/IndividualCategoryScreen";
  static const String recentSearchScreen = "/RecentSearchScreen";
  static const String productDetailScreen = "/ProductDetailScreen";
  static const String addToCartScreen = "/AddToCartScreen";
  static const String paymentScreen = "/PaymentScreen";
  static const String paymentConfirmationScreen = "/PaymentConfirmationScreen";
  static const String addressListScreen = "/AddressListScreen";
  static const String savedBookListScreen = "/SavedBookListScreen";
  static const String notificationScreen = "/NotificationScreen";
  static const String addNewAddressScreen = "/AddNewAddressScreen";
  static const String profileEditScreen = "/ProfileEditScreen";
  static const String orderDetailScreen = "/OrderDetailScreen";
  static const String forgotPasswordScreen = "/ForgotPasswordScreen";
  static const String newPasswordScreen = "/NewPasswordScreen";
  static const String forgotPasswordOTPScreen = "/ForgotPasswordOTPScreen";
  static const String bestSellerBookScreen = "/BestSellerBookScreen";
  static const String latestBookListScreen = "/LatestBookListScreen";
  static const String comingSoonBookList = "/ComingSoonBookList";
}

final pages = [
  GetPage(name: Routes.splashScreen, page: () => const SplashScreen()),
  GetPage(name: Routes.getStartedScreen, page: () => const GetStartedScreen()),
  GetPage(name: Routes.loginScreen, page: () => const LoginScreen()),
  GetPage(
      name: Routes.newPasswordScreen, page: () => const NewPasswordScreen()),
  GetPage(
      name: Routes.registrationScreen, page: () => const RegistrationScreen()),
  GetPage(name: Routes.oTPScreen, page: () => const OTPScreen()),
  GetPage(name: Routes.bottomNavBar, page: () => const BottomNavBar()),
  GetPage(name: Routes.forYouScreen, page: () => const ForYouScreen()),
  GetPage(
      name: Routes.individualCategoryScreen,
      page: () => const IndividualCategoryScreen()),
  GetPage(
      name: Routes.recentSearchScreen, page: () => const RecentSearchScreen()),
  GetPage(
      name: Routes.productDetailScreen,
      page: () => const ProductDetailScreen()),
  GetPage(name: Routes.addToCartScreen, page: () => const AddToCartScreen()),
  GetPage(name: Routes.paymentScreen, page: () => const PaymentScreen()),
  GetPage(
      name: Routes.paymentConfirmationScreen,
      page: () => const PaymentConfirmationScreen()),
  GetPage(
      name: Routes.addressListScreen, page: () => const AddressListScreen()),
  GetPage(
      name: Routes.savedBookListScreen,
      page: () => const SavedBookListScreen()),
  GetPage(
      name: Routes.notificationScreen, page: () => const NotificationScreen()),
  GetPage(
      name: Routes.addNewAddressScreen,
      page: () => const AddNewAddressScreen()),
  GetPage(
      name: Routes.profileEditScreen, page: () => const ProfileEditScreen()),
  GetPage(
      name: Routes.orderDetailScreen, page: () => const OrderDetailScreen()),
  GetPage(
      name: Routes.forgotPasswordScreen,
      page: () => const ForgotPasswordScreen()),
  GetPage(
      name: Routes.forgotPasswordOTPScreen,
      page: () => const ForgotPasswordOTPScreen()),
  GetPage(
      name: Routes.bestSellerBookScreen,
      page: () => const BestSellerBookScreen()),
  GetPage(
      name: Routes.latestBookListScreen,
      page: () => const LatestBookListScreen()),
  GetPage(
      name: Routes.comingSoonBookList, page: () => const ComingSoonBookList()),
];
