import 'package:flutter/material.dart';

class HttpUrl {
  static const String base = 'https://bookapi.appxes-erp.in/';

  static const int org = 1;

  static String createCustomerRegister = '${base}B2CCustomerRegister/Create';

  static String exitingEmailRegister = '${base}B2CCustomerRegister/GetbyEmail?';

  static String login = '${base}B2CCustomerRegister/CustomerLogin';

  static String bannerImageGet = '${base}B2CBannerImage/GetAll?';

  static String addressGetAll = '${base}B2CCustomerDeliveryAddress/GetAll?';

  static String createAddress = '${base}B2CCustomerDeliveryAddress/Create';

  static String getAllCategory = '${base}Category/GetAll?';

  static String b2CCustomerFavCreateWishList =
      '${base}B2CCustomerWishList/Create';

  static String b2CCustomerUnFavCreateWishList =
      '${base}B2CCustomerWishList/Remove?';

  static String getAllProduct = '${base}Book/GetAllSearch?';

  static String productGetByCode = '${base}Book/GetByCode?';

  static String productWishListGetByCustomer =
      '${base}B2CCustomerWishList/GetByCustomer?';

  static String placeOrder = '${base}B2CCustomerOrder/Create';

  static String editProfile = '${base}B2CCustomerRegister/EditProfile';

  static String changePassword =
      '${base}B2CCustomerRegister/EditProfilePassword';

  static String b2cCustomerOrderListing =
      '${base}B2CCustomerOrder/GetHeaderSearch?';

  static String customerOrderGetByCode = '${base}B2CCustomerOrder/Getbycode';

  static String forgotPasswordApi = '${base}B2CCustomerRegister/ForgetPassword';

  static String verifyOtp = '${base}SendOTP/VerifyOTP';

  ///HOT CODE

  static String forYouBookList = '${base}Book/GetByTagCode?';

  static String authourList = '${base}Book/GetAllByAuthor?';
}
