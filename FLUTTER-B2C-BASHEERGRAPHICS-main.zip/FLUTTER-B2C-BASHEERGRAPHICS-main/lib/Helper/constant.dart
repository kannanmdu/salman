import 'package:google_fonts/google_fonts.dart';

class Constant {
  static const String apiVersion = "v1";
  static const bool showLog = true;
  static const bool appUpdate = true;
  static const String googleApiKey = "AIzaSyDrlH7s5ZmmOU14mjEYjccw65zN5nFmt90";
  static const String countryCode = "countryCode";
  static const String STRIPE_SECRET =
      "sk_test_51N00U8FFReMpJzWzW0k62c5BgKrjWNJaFnu3DHoO8PUOKie0XyHlJBwVKQaLPsORqJ9udcg2RDWNlbqExcrDxecF00uNWboKYU";
}
