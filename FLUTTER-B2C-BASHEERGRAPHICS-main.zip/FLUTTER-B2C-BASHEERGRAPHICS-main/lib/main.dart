import 'package:book/Const/fonts.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'Const/approute.dart';
import 'Const/color.dart';
import 'Helper/preferencehelper.dart';
import 'ModelClass/B2CCustomerLogin.dart';
import 'locator/locator.dart';

void main() {
  setupDependencies();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: MyColors.primaryCustom,
          scaffoldBackgroundColor: MyColors.scaffold,
          fontFamily: MyFont.myFont,
        ),
        themeMode: ThemeMode.dark,
        initialRoute: Routes.getStartedScreen,
        getPages: pages,
      ),
    );
  }
}
