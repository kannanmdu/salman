import React from 'react';
// import './About.css';

function About() {
  return (
    <div className="about">
      <h1>About Us</h1>
      {/* Add more content as needed */}
    </div>
  );
}

export default About;
