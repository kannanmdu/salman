// shopUtility.js

let Value = 0;

export const setValue = (value) => {
  Value = value;
};

export const getValue = () => {
  return Value;
};
