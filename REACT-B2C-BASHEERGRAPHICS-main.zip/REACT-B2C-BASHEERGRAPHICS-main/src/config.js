export const book = {
    baseUrl: 'https://bookapi.appxes-erp.in',
    OrgId: 1,
  };
  

// export const book = {
//       baseUrl: 'http://154.26.130.251:302',
//       OrgId: 1,
//     };
    